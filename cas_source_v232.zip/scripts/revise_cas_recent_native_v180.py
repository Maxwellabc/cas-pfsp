"""Explicit zero-call revision: include relative imports in the native snapshot."""
import ast
import shutil
from pathlib import Path
from datetime import datetime, timezone
from cas_augmented_witness_common_v100 import safe, read, sha, put

AREA = 'research/cas_recent_native_v180'


def local_import_closure(initial):
    pending = list(initial)
    found = set()

    def resolve(name):
        for root in ('src', 'scripts'):
            path = Path(root).joinpath(*name.split('.'))
            for candidate in (path.with_suffix('.py'), path / '__init__.py'):
                if safe(candidate.as_posix()).is_file():
                    return candidate.as_posix()

    while pending:
        path = pending.pop()
        if path in found:
            continue
        found.add(path)
        if not path.endswith('.py'):
            continue
        parts = Path(path).parts
        module = '.'.join(parts[1:]).removesuffix('.py')
        package = module.rsplit('.', 1)[0] if not path.endswith('/__init__.py') else module.removesuffix('.__init__')
        for node in ast.walk(ast.parse(safe(path).read_text())):
            names = []
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom):
                base = node.module or ''
                if node.level:
                    prefix = package.split('.')
                    prefix = prefix[:len(prefix) - node.level + 1]
                    base = '.'.join(prefix + ([base] if base else []))
                if base:
                    names.append(base)
                    names.extend(base + '.' + alias.name for alias in node.names if alias.name != '*')
            for name in names:
                resolved = resolve(name)
                if resolved and resolved not in found:
                    pending.append(resolved)
        parent = Path(path).parent
        while parent.as_posix() not in ('.', 'src', 'scripts'):
            init = (parent / '__init__.py').as_posix()
            if safe(init).is_file() and init not in found:
                pending.append(init)
            parent = parent.parent
    return found


def main():
    assert not any(safe(AREA + '/runs').iterdir())
    assert not any(safe(AREA + '/logs').iterdir())
    assert not safe(AREA + '/producer_terminal.json').exists()
    protocol = read(AREA + '/protocol_v180.json')
    old_digest = sha(AREA + '/protocol_v180.json')
    archive = safe(AREA + '/preexecution_r0')
    archive.mkdir(exist_ok=False)
    shutil.copyfile(safe(AREA + '/protocol_v180.json'), archive / 'protocol_v180.json')
    shutil.move(safe(AREA + '/source'), archive / 'source')
    found = local_import_closure(protocol['source_sha256'])
    added = sorted(found - set(protocol['source_sha256']))
    protocol.update(source_sha256={p: sha(p) for p in sorted(found)},
        revision='r1_relative_import_closure_before_any_optimizer_call',
        previous_protocol_sha256=old_digest,
        previous_protocol=AREA + '/preexecution_r0/protocol_v180.json',
        preexecution_revision_utc=datetime.now(timezone.utc).isoformat(),
        added_relative_import_dependency_files=added,
        optimizer_calls_before_revision=0)
    # Preserve the original bytes above; replacing this pointer is an explicit revision.
    safe(AREA + '/protocol_v180.json').write_text(__import__('json').dumps(protocol, indent=2) + '\n')
    for path in sorted(found | {AREA + '/protocol_v180.json'}):
        target = safe(AREA + '/source/' + path)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(safe(path), target)
    put(AREA + '/preexecution_revision_r1.json', dict(
        created_utc=datetime.now(timezone.utc).isoformat(),
        old_protocol_sha256=old_digest, new_protocol_sha256=sha(AREA + '/protocol_v180.json'),
        added_files=added, optimizer_calls_before_revision=0,
        old_snapshot_retained=True, optimizer_source_changed=False))
    print(dict(added=added, total_snapshot_files=len(found) + 1, optimizer_calls=0))


if __name__ == '__main__':
    main()
