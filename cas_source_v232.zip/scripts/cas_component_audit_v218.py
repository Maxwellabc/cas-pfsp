"""Stdlib-only independent serial recurrence and paid composition accounting.

Uses row-specific one-dimensional exterior bounds and direct full shared-load
differences. It does not import producer preparation, marginal, or DP kernels.
Two-row proofs receive accounting checks, not a new full mathematical proof.
"""
from fractions import Fraction as F
import itertools
from cas_joint_pilot_audit_core_v124 import gross,physics


def serial_minimum(ctx,anchor,row):
    powers=ctx['powers'];starts=anchor['starts'];order=anchor['permutation']
    n,m,h=len(powers),len(powers[0]),len(ctx['carbon'])
    lower=[];high=[];before=0
    for j in order:
        before=max([before]+[starts[j][a]+len(powers[j][a]) for a in range(row) if powers[j][a]])
        lower.append(before)
    after=h
    for j in reversed(order):
        after=min([after]+[starts[j][a] for a in range(row+1,m) if powers[j][a]])
        high.append(after)
    high.reverse()
    background=gross(ctx,starts)
    for j in order:
        for offset,p in enumerate(powers[j][row]):background[starts[j][row]+offset]-=p
    base=sum(c*max(0,q-r) for c,q,r in zip(ctx['carbon'],background,ctx['supply']))
    previous=None;duration=0;count=0;domains=[]
    for rank,j in enumerate(order):
        op=powers[j][row]
        if not op:continue
        lo,hi=lower[rank],high[rank]-len(op)
        domains.append(dict(operation=[j,row],lower=lo,upper=hi))
        current={};prefix={};best=None
        if previous is not None:
            for t in range(h+1):
                if t in previous:best=previous[t] if best is None else min(best,previous[t])
                prefix[t]=best
        for t in range(lo,hi+1):
            prior=0 if previous is None else prefix.get(t-duration)
            if prior is None:continue
            cost=sum(ctx['carbon'][t+u]*(max(0,background[t+u]+p-ctx['supply'][t+u])
                       - max(0,background[t+u]-ctx['supply'][t+u])) for u,p in enumerate(op))
            current[t]=prior+cost;count+=1
        assert current
        previous,duration=current,len(op)
    return base+(min(previous.values()) if previous is not None else 0),domains,count


def audit_composition(ctx,out,budget):
    ablation=out["ablation"]
    assert ablation in ("full", "no_serial", "no_pair", "lexicographic")
    assert out['algorithm_version']=='v218' and out['phase_fraction']==.6
    assert out['repair_slice_seconds']==.5 and not out['donated_initializer_or_external_cache']
    assert out['all_initialization_selection_model_scoring_registration_logging_charged']
    points=out['registered_attempts'];phase=out['phase_component'];verified=0
    if phase is None:
        assert not points and not out['repairs'];return 0
    assert phase['shared_root_physical_registry']
    begin,end=phase['physical_registry_attempt_range'];assert begin==0 and end<=len(points)
    best=None
    for i,p in enumerate(points[:end]):
        if p['eligible'] and (best is None or p['score_numerator']<points[best]['score_numerator']):best=i
    assert best==phase['best_registered_attempt_id']
    consumed=set(range(end));descriptors=set();ranks={};last_anchor=None
    for entry in out['ranking_builds']:
        assert entry['anchor_attempt_id'] not in ranks
        anchor=points[entry['anchor_attempt_id']]
        assert anchor['eligible'] and anchor['available_seconds']<=entry['ready_seconds']
        loads=[[0]*len(ctx['carbon']) for a in ctx['powers'][0]]
        for j,job in enumerate(ctx['powers']):
            for a,op in enumerate(job):
                for u,p in enumerate(op):loads[a][anchor['starts'][j][a]+u]+=p
        full=[sum(z) for z in zip(*loads)]
        active=[a for a in range(len(loads)) if any(ctx['powers'][j][a] for j in anchor['permutation'])]
        expected=[]
        for size in (1,2):
            if ablation == "no_serial" and size == 1: continue
            if ablation == "no_pair" and size == 2: continue
            for rs in itertools.combinations(active,size):
                score=sum(c*(max(0,q-r)-max(0,q-sum(loads[a][t] for a in rs)-r))
                    for t,(c,q,r) in enumerate(zip(ctx['carbon'],full,ctx['supply'])))
                expected.append(dict(machine_rows=list(rs),removal_score_numerator=score))
        expected.sort(key=lambda x:(len(x['machine_rows']),0 if ablation == 'lexicographic' else -x['removal_score_numerator'],x['machine_rows']))
        assert entry['groups']==expected
        ranks[entry['anchor_attempt_id']]=entry
    for ix,repair in enumerate(out['repairs']):
        assert repair['id']==ix and repair['anchor_attempt_id']==best
        anchor=points[best];chosen=repair['selected_machine_rows'];result=repair['result']
        assert anchor['eligible'] and anchor['available_seconds']<=repair['started_seconds']
        assert repair['slice_deadline_seconds']<=budget
        if chosen is not None:
            assert 1<=len(chosen)<=2 and chosen==sorted(set(chosen))
            exterior=[[j,a,anchor['starts'][j][a]] for j in anchor['permutation'] for a,op in enumerate(ctx['powers'][j]) if op and a not in chosen]
            descriptor=repair['descriptor']
            assert descriptor==dict(order=anchor['permutation'],machine_rows=chosen,fixed_positive_starts=exterior)
            key=tuple(anchor['permutation']),tuple(chosen),tuple(map(tuple,exterior))
            entry=ranks[repair['anchor_attempt_id']]
            expected_rows=None
            for group in entry['groups']:
                rs=group['machine_rows']
                fixed=tuple((j,a,anchor['starts'][j][a]) for j in anchor['permutation'] for a,op in enumerate(ctx['powers'][j]) if op and a not in rs)
                testkey=tuple(anchor['permutation']),tuple(rs),fixed
                if testkey not in descriptors:
                    expected_rows=rs;break
            assert chosen==expected_rows
            assert key not in descriptors;descriptors.add(key)
        if result is not None and chosen is not None and len(chosen)==1:
            minimum,domains,states=serial_minimum(ctx,anchor,chosen[0])
            assert result['score_numerator']==minimum and result['domains']==domains and result['DP_states']==states
            assert F(result['score_fraction'])==F(minimum,ctx['denominator'])
            verified+=1
        if repair['neighborhood_proved_optimal']:
            assert repair['started_seconds']<=repair['proof_ready_seconds']<repair['slice_deadline_seconds']<=budget
            assert result is not None and result['neighborhood_proved_optimal']
        for i in repair['registered_attempt_ids']:
            assert i==len(consumed) and i not in consumed;consumed.add(i)
            p=points[i]
            assert p['permutation']==anchor['permutation'] and p['origin']['repair']==ix
            assert p['registration_started_seconds']>=repair['started_seconds']
            assert p['score_numerator']<anchor['score_numerator']
            for j,job in enumerate(ctx['powers']):
                for a,op in enumerate(job):
                    if op and a not in chosen:assert p['starts'][j][a]==anchor['starts'][j][a]
            if p['eligible'] and (best is None or p['score_numerator']<points[best]['score_numerator']):best=i
        assert repair['best_after_attempt_id']==best
        assert repair['improved_global_best']==(points[best]['score_numerator']<anchor['score_numerator'])
    assert consumed==set(range(len(points)))
    return verified
