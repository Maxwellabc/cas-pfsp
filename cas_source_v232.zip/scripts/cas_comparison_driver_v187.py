"""Frozen nine-method short-budget study; inspect quality after all attempts/audit."""
import argparse, gzip, json, platform, sys, math
from datetime import datetime, timezone
from fractions import Fraction as F
from collections import defaultdict
from cas_augmented_witness_common_v100 import safe, read, sha, put

AREA = 'research/cas_short_comparison_v187'


def producer(stage):
    # All nine complete cores are imported before any method starts its root clock.
    from cas_pfsp_v186.search import run_file as competition
    from cas_pfsp_v179.search import run_file as cost
    from cas_pfsp_v186.joint_control import run_file as joint
    from cas_pfsp_v173r2.search import run_file as ordered
    from cas_pfsp_v76.search import run_search as phase
    from cas_pfsp_v93.search import run_search as wait
    from cas_pfsp_v153.search import run_file as alns
    from cas_pfsp_v178.learning import run_file as learning
    import numpy, random
    p = read(AREA + '/protocol_v187.json'); binding = sha(AREA + '/protocol_v187.json')
    for path, digest in p['source_sha256'].items(): assert sha(path) == digest
    if stage == 'public':
        marker = read(AREA + '/private/qa/independent_QA_v187.json')
        assert len(marker['rows']) == 18 and not marker['technical_failures']
    handlers = dict(competition_cost=lambda s: competition(s['input'], p['budget_seconds'], seed=s['seed']),
        cost_joint_ordered=lambda s: cost(s['input'], p['budget_seconds'], seed=s['seed']),
        joint_ordered=lambda s: joint(s['input'], p['budget_seconds'], seed=s['seed']),
        ordered=lambda s: ordered(s['input'], p['budget_seconds'], seed=s['seed']),
        phase_full=lambda s: phase(s['input'], 't1p1', s['seed'], p['budget_seconds']),
        local_wait_raw=lambda s: wait(s['input'], 'raw', s['seed'], p['budget_seconds']),
        adaptive_cp_alns=lambda s: alns(s['input'], p['budget_seconds'], seed=s['seed']),
        lg_ucb26=lambda s: learning(s['input'], p['budget_seconds'], s['seed']),
        cycle_control=lambda s: learning(s['input'], p['budget_seconds'], s['seed'], uniform=True))
    attempts = []
    for index in p[stage + '_execution_order']:
        spec = p[stage + '_trials'][index]
        py, np = random.getstate(), repr(numpy.random.get_state())
        try:
            result = handlers[spec['method']](spec)
            assert random.getstate() == py and repr(numpy.random.get_state()) == np
            record = dict(spec=spec, result=result, protocol_sha256=binding, Python=platform.python_version(),
                NumPy=numpy.__version__, platform=platform.platform(), all_nine_cores_preloaded=True,
                global_rng_unchanged=True)
            path = AREA + '/' + stage + '/runs/' + spec['id'] + '.json.gz'
            with gzip.open(safe(path), 'xt') as stream: json.dump(record, stream)
            attempts.append(dict(id=spec['id'], success=True, path=path, sha256=sha(path)))
        except Exception as error:
            attempts.append(dict(id=spec['id'], success=False, error=repr(error), optimizer_retry=False))
        print(dict(completed=spec['id'], stage=stage, success=attempts[-1]['success']), flush=True)
    put(AREA + '/' + stage + '/runs/all_attempts_terminal_v187.json', dict(
        created_utc=datetime.now(timezone.utc).isoformat(), protocol_sha256=binding,
        attempts=attempts, partial_quality_read=False, optimizer_retries=0))


def reward_replay(out):
    points = out['registered_attempts']; evaluations = {r['id']: r for r in out['evaluations']}
    controlled = [r for r in out['evaluations'] if r.get('move') is not None and 'operator' in r['move']]
    assert len(controlled) == len(out['controller_history'])
    groups = defaultdict(list)
    for ix, point in enumerate(points): groups[point['origin']['evaluation']].append(ix)
    best = None; before = {}; after = {}
    for ix, ev in sorted(evaluations.items()):
        before[ix] = best
        selected = [i for i in groups[ix] if points[i]['eligible']]
        selected = min(selected, key=lambda i: points[i]['score_numerator']) if selected else None
        if selected is not None:
            value = points[selected]['score_numerator']; best = value if best is None else min(best, value)
        after[ix] = best
        if ev.get('status') == 'evaluated':
            assert selected == ev['selected_attempt_id']
            current = ev['current_before_attempt_id']
            strict = selected is not None and (current is None or points[selected]['score_numerator'] < points[current]['score_numerator'])
            accepted = selected is not None and ev['decision_ready_seconds'] < out['budget_seconds'] and (strict or ev['reason'] == 'shake')
            assert accepted == ev['accepted'] and bool(accepted and strict) == ev['strict_improvement']
    for ev, event in zip(controlled, out['controller_history']):
        assert ev['move']['operator'] == event['arm'] and event['before'] == before[ev['id']] and event['after'] == after[ev['id']]
        reward = 3 if event['after'] is not None and (event['before'] is None or event['after'] < event['before']) else 1 if ev['accepted'] and event['arm'] != 3 else 0
        assert reward == event['reward'] and event['ready_seconds'] >= ev['returned_seconds']
    return len(controlled)


def auditor(stage):
    from audit_cas_cpsat_public_v117 import load_case
    from cas_joint_pilot_audit_core_v124 import context, physics
    p = read(AREA + '/protocol_v187.json'); binding = sha(AREA + '/protocol_v187.json')
    terminal = read(AREA + '/' + stage + '/runs/all_attempts_terminal_v187.json')
    assert terminal['protocol_sha256'] == binding
    done = {r['id']: r for r in terminal['attempts']}; specs = p[stage + '_trials']
    assert len(done) == len(specs) and set(done) == {s['id'] for s in specs}
    for path, digest in p['source_sha256'].items(): assert sha(path) == digest
    contexts = {}; checked = []; failures = []; total_rewards = 0
    for spec in specs:
        attempt = done[spec['id']]
        if not attempt['success']:
            failures.append(attempt); checked.append(dict(**spec, best_fraction=None, audit_passed=False)); continue
        assert sha(attempt['path']) == attempt['sha256']
        with gzip.open(safe(attempt['path']), 'rt') as stream: record = json.load(stream)
        assert record['spec'] == spec and record['protocol_sha256'] == binding and record['all_nine_cores_preloaded']
        assert record['Python'] == '3.10.19' and record['NumPy'] == '2.2.6' and record['global_rng_unchanged']
        if spec['input'] not in contexts:
            case, digest = load_case(spec['input']); assert digest == spec['input_sha256']
            contexts[spec['input']] = context(case)
        ctx = contexts[spec['input']]; out = record['result']; budget = p['budget_seconds']
        assert out['budget_seconds'] == budget and out['input_sha256'] == spec['input_sha256']
        best = None; value = None; cache = {}
        for point in out['registered_attempts']:
            score = physics(ctx, point, cache)
            assert 0 <= point['registration_started_seconds'] <= point['available_seconds'] <= out['algorithm_wall_seconds'] + 1e-6
            assert point['eligible'] == (point['available_seconds'] <= budget)
            strict = point['eligible'] and (value is None or score < value)
            assert point['strict_global_incumbent'] == strict
            if strict: best, value = point, score
        assert out['best_registered'] == best
        if spec['method'] in ['lg_ucb26', 'cycle_control']:
            counts = [0] * 4; sums = [0.] * 4
            for index, event in enumerate(out['controller_history']):
                expected = index % 4 if spec['method'] == 'cycle_control' or index < 20 else max(range(4),
                    key=lambda k: (sums[k] / counts[k] + .5 * math.sqrt(math.log(index + 1) / counts[k]), -k))
                assert event['arm'] == expected and event['reward'] in [0, 1, 3]
                counts[expected] += 1; sums[expected] += event['reward']
            assert counts == out['counts'] and not out['full_original_LgMOEA_reproduction']
            total_rewards += reward_replay(out)
        for repair in out.get('repairs', []):
            if repair.get('neighborhood_proved_optimal'):
                assert repair['proof_ready_seconds'] <= min(budget, repair['slice_deadline_seconds']) + 1e-7
        checked.append(dict(**spec, best_fraction=None if value is None else str(value), audit_passed=True,
            physical_registrations_checked=len(out['registered_attempts']), budget_seconds=budget,
            wall_seconds=out['algorithm_wall_seconds'], overshoot_seconds=max(0, out['algorithm_wall_seconds'] - budget),
            repair_calls=len(out.get('repairs', [])),
            competition_strict_strengthenings=sum((r.get('chain_DP') or {}).get('competition_strict_strengthenings', 0) for r in out.get('repairs', []))))
        print(dict(audited=spec['id'], stage=stage), flush=True)
    assert not any(n.startswith(('cas_pfsp_', 'numpy', 'ortools')) for n in sys.modules)
    put(AREA + '/' + stage + '/qa/independent_QA_v187.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
        status='all_registered_attempts_independently_accounted', stage=stage, rows=checked,
        technical_failures=failures, physical_registrations_checked=sum(r.get('physical_registrations_checked', 0) for r in checked),
        controller_rewards_replayed=total_rewards, protocol_sha256=binding,
        large_neighborhood_optima_independently_reproved=False, producer_model_numpy_CP_imported=False,
        protected270_contents_read=False, candidate_promoted=False))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--role', choices=['producer', 'auditor'], required=True)
    ap.add_argument('--stage', choices=['private', 'public'], required=True); args = ap.parse_args()
    producer(args.stage) if args.role == 'producer' else auditor(args.stage)
