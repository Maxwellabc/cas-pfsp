"""Frozen complete paired studies; no partial public quality inspection."""
import argparse, gzip, json, platform, sys, math, random
from datetime import datetime, timezone
from fractions import Fraction as F
from collections import defaultdict
from cas_augmented_witness_common_v100 import safe, read, sha, put

AREA = 'research/cas_component_comparison_v218'


def producer(stage,worker=0):
    from cas_pfsp_v194.search import run_file as accelerated
    from cas_pfsp_v197.search import run_file as serial
    from cas_pfsp_v76.search import run_search as phase
    from cas_pfsp_v93.search import run_search as wait
    from cas_pfsp_v173r2.search import run_file as ordered
    from cas_pfsp_v178.learning import run_file as learning
    from cas_pfsp_v218.search import run_file as component
    from cas_pfsp_v153.search import run_file as alns
    import numpy, ortools
    p = read(AREA + '/protocol_v218.json'); binding = sha(AREA + '/protocol_v218.json')
    for path, digest in p['source_sha256'].items(): assert sha(path) == digest
    if stage != 'private':
        marker=read(AREA+'/private/qa/independent_QA_v218.json')
        assert len(marker['rows'])==16 and not marker['technical_failures']
        assert read(AREA+'/private/qa/component_qualification_v218.json')['status']=='passed'
    b = p['stages'][stage]['budget_seconds']
    handlers = dict(serial_rows=lambda s: serial(s['input'], b, s['seed']),
        fast_wait=lambda s: accelerated(s['input'], b, s['seed']),
        local_wait_raw=lambda s: wait(s['input'], 'raw', s['seed'], b),
        no_serial=lambda s: component(s['input'],b,s['seed'],ablation='no_serial'),
        no_pair=lambda s: component(s['input'],b,s['seed'],ablation='no_pair'),
        lexicographic=lambda s: component(s['input'],b,s['seed'],ablation='lexicographic'),
        adaptive_cp_alns=lambda s: alns(s['input'],b,seed=s['seed']),
        lg_ucb26=lambda s: learning(s['input'], b, s['seed']))
    attempts = []
    for index in p['stages'][stage]['execution_order']:
        if p['stages'][stage]['trials'][index]['worker'] != worker: continue
        spec = p['stages'][stage]['trials'][index]
        py, np = random.getstate(), repr(numpy.random.get_state())
        path = AREA + '/' + stage + '/runs/' + spec['id'] + '.json.gz'
        # A saved cell is never silently rerun.
        assert not safe(path).exists()
        try:
            result = handlers[spec['method']](spec)
            assert random.getstate() == py and repr(numpy.random.get_state()) == np
            record = dict(spec=spec, result=result, protocol_sha256=binding,
                Python=platform.python_version(), NumPy=numpy.__version__, ORTools=ortools.__version__,
                platform=platform.platform(), all_eight_cores_preloaded=True, global_rng_unchanged=True)
            with gzip.open(safe(path), 'xt', compresslevel=1) as stream: json.dump(record, stream)
            attempts.append(dict(id=spec['id'], success=True, path=path, sha256=sha(path)))
        except Exception as error:
            attempts.append(dict(id=spec['id'], success=False, error=repr(error), optimizer_retry=False))
        print(dict(completed=spec['id'], stage=stage, success=attempts[-1]['success']), flush=True)
    put(AREA + '/' + stage + '/runs/worker_'+str(worker)+'_terminal_v218.json', dict(
        created_utc=datetime.now(timezone.utc).isoformat(), protocol_sha256=binding,
        attempts=attempts, partial_quality_read=False, optimizer_retries=0))


def auditor(stage):
    from audit_cas_cpsat_public_v117 import load_case
    from cas_joint_pilot_audit_core_v124 import context, physics
    from cas_comparison_driver_v187 import reward_replay
    p = read(AREA + '/protocol_v218.json'); binding = sha(AREA + '/protocol_v218.json')
    # Both public cohorts must be terminal before either is inspected.
    if stage != 'private':
        for name in ('public',):
            terminal = read(AREA + '/' + name + '/runs/all_attempts_terminal_v218.json')
            assert len(terminal['attempts']) == len(p['stages'][name]['trials'])
    terminal = read(AREA + '/' + stage + '/runs/all_attempts_terminal_v218.json')
    assert terminal['protocol_sha256'] == binding
    done = {r['id']: r for r in terminal['attempts']}; specs = p['stages'][stage]['trials']
    assert len(done) == len(specs) and set(done) == {s['id'] for s in specs}
    for path, digest in p['source_sha256'].items(): assert sha(path) == digest
    contexts, checked, failures = {}, [], []
    for spec in specs:
        attempt = done[spec['id']]
        if not attempt['success']:
            failures.append(attempt); checked.append(dict(**spec, best_fraction=None, audit_passed=False)); continue
        assert sha(attempt['path']) == attempt['sha256']
        with gzip.open(safe(attempt['path']), 'rt') as stream: record = json.load(stream)
        assert record['spec'] == spec and record['protocol_sha256'] == binding and record['all_eight_cores_preloaded']
        assert (record['Python'], record['NumPy'], record['ORTools']) == ('3.10.19', '2.2.6', '9.15.6755')
        assert record['global_rng_unchanged']
        if spec['input'] not in contexts:
            case, digest = load_case(spec['input']); assert digest == spec['input_sha256']
            contexts[spec['input']] = context(case)
        ctx = contexts[spec['input']]; out = record['result']; budget = p['stages'][stage]['budget_seconds']
        assert out['budget_seconds'] == budget and out['input_sha256'] == spec['input_sha256']
        best, value, cache = None, None, {}
        for point in out['registered_attempts']:
            score = physics(ctx, point, cache)
            assert 0 <= point['registration_started_seconds'] <= point['available_seconds'] <= out['algorithm_wall_seconds'] + 1e-6
            assert point['eligible'] == (point['available_seconds'] <= budget)
            strict = point['eligible'] and (value is None or score < value)
            assert point['strict_global_incumbent'] == strict
            if strict: best, value = point, score
        assert out['best_registered'] == best
        if spec['method'] == 'lg_ucb26':
            counts, sums = [0]*4, [0.]*4
            for index, event in enumerate(out['controller_history']):
                expected = index % 4 if index < 20 else max(range(4), key=lambda k:
                    (sums[k] / counts[k] + .5 * math.sqrt(math.log(index + 1) / counts[k]), -k))
                assert event['arm'] == expected and event['reward'] in [0, 1, 3]
                counts[expected] += 1; sums[expected] += event['reward']
            assert counts == out['counts'] and not out['full_original_LgMOEA_reproduction']
            reward_replay(out)
        candidate_phases = 0
        dominated_checked = 0
        if spec['method']=='fast_wait' or spec['method'] in ('serial_rows','no_serial','no_pair','lexicographic') and out['phase_component'] is not None:
            fast = out if spec['method']=='fast_wait' else {**out['phase_component'], 'registered_attempts':out['registered_attempts']}
            assert fast['exact_acceleration_version'] == 'v194' and fast['lazy_NEH']
            # Re-evaluate each consumed phase with plain arbitrary-size integers.
            for call in fast['phase_calls']:
                profile = call.get('profile', [])
                for t, v in call['phase_values']:
                    want = sum(ctx['carbon'][t+u] * max(q-ctx['supply'][t+u], 0) for u, q in enumerate(profile))
                    assert want == v
                    candidate_phases += 1
            for event in fast['dominated_registration_events']:
                point = fast['registered_attempts'][event['dominating_attempt_id']]
                assert point['eligible'] and point['origin']['evaluation'] == event['evaluation']
                assert point['available_seconds'] <= event['decided_seconds'] <= fast['algorithm_wall_seconds']
                assert point['score_numerator'] == event['dominating_score_numerator'] <= event['score_numerator']
                call = fast['phase_calls'][event['origin']['phase_call']]
                phase = event['origin']['phase']
                exact = sum(ctx['carbon'][phase+u] * max(q-ctx['supply'][phase+u], 0) for u,q in enumerate(call['profile']))
                assert exact == event['score_numerator']
                dominated_checked += 1
            assert dominated_checked == sum(bool(r.get('safely_dominated')) for c in fast['phase_calls'] for r in c['registrations'])
            # Fixed-clock qualification checks paths; this checks live decisions.
            for ev in fast['evaluations']:
                if ev.get('status') != 'evaluated': continue
                ids = [x['attempt_id'] for x in ev['witnesses'] if x['eligible']]
                for ix in ev['phase_calls']:
                    ids.extend(x['attempt_id'] for x in fast['phase_calls'][ix]['registrations'] if x['eligible'])
                selected = min(ids, key=lambda i: fast['registered_attempts'][i]['score_numerator']) if ids else None
                assert selected == ev['selected_attempt_id']
                old = ev['current_before_attempt_id']
                strict = selected is not None and (old is None or fast['registered_attempts'][selected]['score_numerator'] < fast['registered_attempts'][old]['score_numerator'])
                accept = selected is not None and ev['decision_ready_seconds'] < fast['budget_seconds'] and (strict or ev['reason'] == 'shake')
                assert ev['accepted'] == accept and ev['strict_improvement'] == bool(accept and strict)
        serial_verified = 0
        if spec['method']=='serial_rows':
            from cas_serial_audit_v198 import audit_composition
            serial_verified = audit_composition(ctx,out,budget)
        if spec['method'] in ('no_serial','no_pair','lexicographic'):
            from cas_component_audit_v218 import audit_composition as component_audit
            assert out['ablation']==spec['method']
            serial_verified=component_audit(ctx,out,budget)
        if spec['method']=='adaptive_cp_alns':
            assert not out['donated_initializer_or_external_model_cache']
            assert not out['original_published_source_code_reproduced']
            for w in out['windows']:
                if w['neighborhood_proved_optimal']:
                    assert w['returned_seconds']<=min(budget,w['slice_deadline_seconds'])+1e-7
        timely = [x for x in out['registered_attempts'] if x['eligible']]
        checked.append(dict(**spec, best_fraction=None if value is None else str(value), audit_passed=True,
            physical_registrations_checked=len(out['registered_attempts']), budget_seconds=budget,
            wall_seconds=out['algorithm_wall_seconds'], overshoot_seconds=max(0, out['algorithm_wall_seconds']-budget),
            first_feasible_seconds=timely[0]['available_seconds'] if timely else None,
            evaluations=len(out.get('evaluations', [])), candidate_phase_scores_checked=candidate_phases,
            dominated_registration_proofs_checked=dominated_checked,
            serial_row_optima_independently_recomputed=serial_verified))
        print(dict(audited=spec['id'], stage=stage), flush=True)
    assert not any(n.startswith(('cas_pfsp_', 'numpy', 'ortools')) for n in sys.modules)
    put(AREA + '/' + stage + '/qa/independent_QA_v218.json', dict(
        created_utc=datetime.now(timezone.utc).isoformat(), stage=stage, rows=checked,
        technical_failures=failures, protocol_sha256=binding,
        physical_registrations_checked=sum(r.get('physical_registrations_checked', 0) for r in checked),
        exact_candidate_phase_scores_checked=sum(r.get('candidate_phase_scores_checked', 0) for r in checked),
        dominated_registration_proofs_checked=sum(r.get('dominated_registration_proofs_checked', 0) for r in checked),
        serial_row_optima_independently_recomputed=sum(r.get('serial_row_optima_independently_recomputed',0) for r in checked),
        producer_model_numpy_CP_imported=False, protected270_contents_read=False,
        independent_external_human_replication=False))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--role', choices=['producer', 'auditor'], required=True)
    ap.add_argument('--stage', choices=['private', 'public'], required=True); ap.add_argument('--worker',type=int,default=0); args = ap.parse_args()
    producer(args.stage,args.worker) if args.role == 'producer' else auditor(args.stage)
