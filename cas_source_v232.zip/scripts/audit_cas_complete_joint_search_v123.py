"""Independent physics, selection, shared-registry and CP-prefix accounting."""
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib
import json
import math
from cas_augmented_witness_common_v100 import read, sha, put
from audit_cas_closure_certificate_v53 import enumerate_tiny
from audit_cas_cpsat_budget_v116 import physics
from audit_cas_cpsat_public_v117 import load_case as load_CSV

AREA = 'research/cas_complete_joint_v123'


def point_key(order, starts): return tuple(order), tuple(x for line in starts for x in line)


def gross(case, starts, operations):
    values = [F(0)]*len(case['carbon'])
    for j, a in operations:
        for k, power in enumerate(case['powers'][j][a]): values[starts[j][a]+k] += F(power)
    return values


def cost(case, load):
    return sum((F(c)*max(0, q-F(r))/4 for q, r, c in zip(load, case['renewable'], case['carbon'])), F(0))


def arithmetic(case, anchor, free):
    n, m, h = len(case['powers']), len(case['powers'][0]), len(case['carbon'])
    dp = math.lcm(1, *(F(x).denominator for job in case['powers'] for op in job for x in op))
    fixed = [(j, a) for j in range(n) for a in range(m) if (j, a) not in free]
    background = [x*dp for x in gross(case, anchor['starts'], fixed)]
    residual = [max(0, F(r)*dp-b) for b, r in zip(background, case['renewable'])]
    constant = 4*dp*cost(case, [b/dp for b in background])
    cap = sum(max((F(x)*dp for x in case['powers'][j][a]), default=0) for j, a in free)
    terms = [(constant, 1)] if constant else []
    for r, c in zip(residual, map(F, case['carbon'])):
        if r >= cap: continue
        a = r.numerator//r.denominator; f = r-a
        terms += [(c, cap-a)] if f == 0 else [(c, max(0, cap-a-1)), (c*(1-f), 1)]
    scale = math.lcm(1, *(c.denominator for c, _ in terms))
    upper = sum(int(c*scale)*int(u) for c, u in terms)
    mass = sum(int(u) for c, u in terms if c and u)
    k = max(1, min(20, (2**60//max(1, 2*mass)).bit_length()-1))
    return 4*dp*scale, 2**k, max(1, (upper.bit_length()+k-1)//k)


def best_prefix(attempts, end):
    eligible = [i for i, x in enumerate(attempts[:end]) if x['eligible']]
    return min(eligible, key=lambda i: (F(attempts[i]['score_fraction']), i)) if eligible else None


def main():
    p = read(AREA+'/protocol_v123.json'); out = read(AREA+'/run_r1/results_v123.json')
    for path, digest in p['source_sha256'].items(): assert sha(path) == digest, path
    assert out['protocol_sha256'] == sha(AREA+'/protocol_v123.json')
    assert out['runtime'] == {'Python': '3.10.19', 'ORTools': '9.15.6755', 'NumPy': '2.2.6', 'prefix': '/cpsat-env'}
    cases = {x['name']: x for x in read(AREA+'/cases_v123.json')}
    csv, csv_sha = load_CSV(p['private_CSV']); cases['__constructed_CSV__'] = csv
    truths = {}
    for name, case in cases.items():
        states, _ = enumerate_tiny(case)
        truths[name] = {point_key(order, starts): score for order, values in states.items() for starts, score in values}
    assert len(out['runs']) == p['planned_policy_calls'] == 92
    statuses = Counter(); real_default = 0; primitive = 0; checked = 0; phase_late_retained = 0; labels = {}
    for run in out['runs']:
        labels[run['label']] = run
        case = cases[run['case']]; truth = truths[run['case']]; result = run['result']; budget = result['budget_seconds']
        eps = 0 if run['clock_kind'] == 'event_ticks_not_wall_performance' else 1e-7
        expected_sha = csv_sha if run['case'] == '__constructed_CSV__' else hashlib.sha256(json.dumps(case, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        assert result['input_sha256'] in (None, expected_sha)
        elapsed = result['algorithm_wall_seconds']; assert elapsed >= 0 and result['overshoot_seconds'] == max(0., elapsed-budget)
        assert result['shared_root_eligibility'] == 'available_seconds<=budget_seconds'
        assert result['global_Python_RNG_unchanged'] and not result['donated_initializer_or_external_cache']
        assert not result['positive_global_optimum_claim'] and not result['hard_return_deadline_guaranteed']
        attempts = result['registered_attempts']; best = None; best_value = None
        for i, point in enumerate(attempts):
            value = physics(case, point); checked += 1
            assert point_key(point['permutation'], point['starts']) in truth
            assert value == truth[point_key(point['permutation'], point['starts'])]
            assert 0 <= point['registration_started_seconds'] <= point['available_seconds'] <= elapsed+eps
            if point['eligible']: assert point['available_seconds'] <= budget+eps
            else: assert point['available_seconds'] > budget-eps
            strict = point['eligible'] and (best_value is None or value < best_value)
            assert point['strict_global_incumbent'] == bool(strict)
            if strict: best, best_value = point, value
        assert result['best_registered'] == best
        zero = best is not None and best_value == 0
        assert result['status'] == ('OPTIMAL' if zero else 'FEASIBLE' if best else 'UNKNOWN')
        assert result['zero_global_objective_certified'] == zero
        phase = result['phase_component']; phase_count = 0
        if phase is not None:
            assert phase['shared_root_physical_registry'] and phase['policy'] == 't1p1' and phase['seed'] == result['seed']
            begin, phase_count = phase['physical_registry_attempt_range']; assert begin == 0 and phase_count <= len(attempts)
            assert phase['best_registered_attempt_id'] == best_prefix(attempts, phase_count)
            assert abs(phase['budget_seconds']-result['phase_fraction']*budget) <= eps+1e-9
            for evaluation in phase['evaluations']:
                if evaluation['accepted']: assert evaluation['decision_ready_seconds'] < result['phase_fraction']*budget+eps
            for point in attempts[:phase_count]:
                if point['eligible'] and point['available_seconds'] > result['phase_fraction']*budget+eps: phase_late_retained += 1
        assert not result['repairs'] or phase is not None
        paid = set(range(phase_count)); attempted = set(); previous_end = phase_count
        for number, repair in enumerate(result['repairs']):
            assert repair['id'] == number and repair['registration_attempts_before'] == previous_end
            before, after = previous_end, repair['registration_attempts_after']; previous_end = after
            assert 0 <= before <= after <= len(attempts)
            anchor_id = repair['anchor_attempt_id']; assert anchor_id == best_prefix(attempts, before)
            anchor = attempts[anchor_id]
            assert anchor['available_seconds'] <= repair['started_seconds']+eps
            assert repair['slice_deadline_seconds'] <= budget+eps
            assert abs(repair['slice_deadline_seconds']-min(budget, repair['started_seconds']+result['repair_slice_seconds'])) <= eps+1e-9
            assert repair['returned_seconds'] <= elapsed+eps
            assert repair['best_after_attempt_id'] == best_prefix(attempts, after)
            after_value = F(attempts[repair['best_after_attempt_id']]['score_fraction'])
            assert repair['improved_global_best'] == (after_value < F(anchor['score_fraction']))
            n, m = len(case['powers']), len(case['powers'][0]); all_ops = [(j, a) for j in range(n) for a in range(m)]
            positive = [op for op in all_ops if case['powers'][op[0]][op[1]]]; zero_ops = set(all_ops)-set(positive)
            ranking = []
            load = gross(case, anchor['starts'], all_ops)
            for j, a in positive:
                removed = list(load)
                for k, power in enumerate(case['powers'][j][a]): removed[anchor['starts'][j][a]+k] -= F(power)
                ranking.append(((j, a), cost(case, load)-cost(case, removed)))
            ranking.sort(key=lambda x: (-x[1], x[0]))
            expected_ranking = [{'operation': list(op), 'removal_score_fraction': str(v)} for op, v in ranking]
            if repair['ranking']: assert repair['ranking'] == expected_ranking
            selected = repair['selected_positive_operations']
            if selected is None:
                assert after == before and not repair['stages']; continue
            assert repair['ranking'] == expected_ranking
            operations = [op for op, _ in ranking]; expected = None
            for size in reversed(range(1, min(result['max_positive_free'], len(operations))+1)):
                for offset in range(len(operations)):
                    chosen = tuple(sorted(operations[(offset+k)%len(operations)] for k in range(size)))
                    exterior = tuple((j, a, anchor['starts'][j][a]) for j, a in sorted(operations) if (j, a) not in chosen)
                    key = tuple(anchor['permutation']), chosen, exterior
                    if key not in attempted: expected = key; break
                if expected is not None: break
            assert expected is not None and tuple(map(tuple, selected)) == expected[1]; attempted.add(expected)
            free = set(map(tuple, repair['free_operations']))
            assert free == zero_ops | set(map(tuple, selected))
            restricted = {k: v for k, v in truth.items() if k[0] == tuple(anchor['permutation']) and
                all(k[1][j*m+a] == anchor['starts'][j][a] for j, a in all_ops if (j, a) not in free)}
            assert restricted
            for point in attempts[before:after]: assert point_key(point['permutation'], point['starts']) in restricted
            den, base, digits = arithmetic(case, anchor, free)
            if repair['stages']:
                assert int(repair['objective_denominator']) == den and repair['objective_base'] == base and repair['objective_digits'] == digits
            remaining = [int(v*den) for v in restricted.values()]
            assert all((v*den).denominator == 1 for v in restricted.values())
            proofs = []
            for index, stage in enumerate(repair['stages']):
                primitive += 1; assert stage['digit'] == digits-index-1
                assert 0 <= stage['call_started_seconds'] < repair['slice_deadline_seconds']+eps
                assert abs(stage['native_time_limit_seconds']-(repair['slice_deadline_seconds']-stage['call_started_seconds'])) <= eps+1e-9
                assert stage['call_started_seconds'] <= stage['returned_seconds'] <= repair['returned_seconds']+eps
                for event in stage['events']:
                    aid = event['attempt_id']; assert 0 <= aid < after
                    assert event['paid_within_run_cache_hit'] == (aid in paid); paid.add(aid)
                    point = attempts[aid]; assert point_key(point['permutation'], point['starts']) in restricted
                    assert event['reference_ready_seconds'] >= point['available_seconds']-eps
                    assert event['referenced_registration_eligible'] == point['eligible']
                if stage['proof_used']:
                    assert stage['native_status'] == 'OPTIMAL' and stage['proof_ready_seconds'] <= repair['slice_deadline_seconds']+eps
                    level, value = stage['digit'], stage['optimal_digit_value']
                    assert value == min(x//base**level%base for x in remaining)
                    remaining = [x for x in remaining if x//base**level%base == value]
                    proofs.append({'digit': level, 'value': value, 'ready_seconds': stage['proof_ready_seconds']})
            assert proofs == repair['proved_optimal_prefix']
            complete = len(proofs) == digits
            assert repair['neighborhood_proved_optimal'] == complete
            if complete: assert after_value == min(restricted.values())
        assert paid == set(range(len(attempts)))
        if run['label'] == 'complete_real':
            real_default += 1
            assert result['phase_max_evaluations'] is None and result['max_repairs'] is None
            if truth: assert best is not None
            else: assert best is None and result['status'] == 'UNKNOWN'
        statuses[result['status']] += 1
    assert real_default == 72
    boundary = out['diagnostic_tick_boundaries']
    for prefix, expected_time in [('phase_registration_', boundary['first_phase_availability']), ('CP_registration_', boundary['first_useful_CP_availability'])]:
        for suffix, eligible in [('before', False), ('exact', True), ('after', True)]:
            result = labels[prefix+suffix]['result']
            matches = [a for a in result['registered_attempts'] if a['available_seconds'] == expected_time]
            assert matches and matches[0]['eligible'] == eligible
            if suffix == 'exact': assert result['budget_seconds'] == expected_time
    for suffix, count in [('before', 0), ('exact', 1), ('after', 1)]:
        r = labels['CP_prefix_'+suffix]['result']
        assert r['status'] == 'FEASIBLE' and len(r['repairs'][0]['proved_optimal_prefix']) == count
        assert not r['repairs'][0]['neighborhood_proved_optimal']
    retained = labels['shared_registry_local_phase_overrun']['result']
    assert any(a['eligible'] and a['available_seconds'] > retained['phase_fraction']*retained['budget_seconds'] for a in retained['registered_attempts'])
    assert phase_late_retained > 0
    for label in ['before_load_expiry', 'CSV_before_load_expiry']:
        r = labels[label]['result']; assert r['input_sha256'] is None and r['best_registered'] is None
    assert labels['paid_loader_expiry']['result']['algorithm_wall_seconds'] >= .02
    assert len(out['invalid']) == 7
    put('research/qa/cas_complete_joint_independent_v123.json', {'created_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'private_paid_complete_phase_CP_search_physics_selection_prefix_and_global_deadline_accounting_verified_v123',
        'protocol_sha256': sha(AREA+'/protocol_v123.json'), 'results_sha256': sha(AREA+'/run_r1/results_v123.json'),
        'private_policy_calls': len(out['runs']), 'real_default_complete_calls': real_default,
        'primitive_real_CP_calls': primitive, 'physical_registration_attempts_checked': checked,
        'status_counts': dict(statuses), 'timely_global_points_beyond_local_phase_cap': phase_late_retained,
        'phase_and_CP_exact_global_registration_boundary_checked': True, 'incomplete_prefix_not_global_optimality': True,
        'selection_and_background_model_scope_checked': True, 'private_diagnostic_quotas_not_performance_samples': True,
        'whole_positive_optimum_or_public_quality_or_priority_qualified': False,
        'CP_model_or_producer_imported_by_auditor': False, 'public_quality_calls': 0,
        'candidate_promoted': False, 'goal_complete': False})
    print({'private_policy_calls': len(out['runs']), 'physical_registrations': checked,
        'primitive_real_CP_calls': primitive, 'independent_audit': 'passed'}, flush=True)


if __name__ == '__main__':
    main()
