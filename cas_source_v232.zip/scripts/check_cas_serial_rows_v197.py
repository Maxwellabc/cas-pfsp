"""Constructed exhaustive row optima and complete paid-clock qualification."""
import argparse
import itertools
import random
from datetime import datetime,timezone
from fractions import Fraction as F
from cas_augmented_witness_common_v100 import put,sha
from cas_pfsp_v45.model import Instance
from cas_pfsp_v53.minimum_closure import temporal_grid
from cas_pfsp_v69.projection import matrix
from cas_pfsp_v49.timing_pairs import lift_zero_operations
from cas_pfsp_v172.two_chain import PreparedInput,ViableChainTiming
from cas_pfsp_v197.serial import serial_response
from cas_pfsp_v197.search import run_budgeted


def physics(ctx,order,starts):
    h=ctx.horizon;gross=[0]*h
    assert sorted(order)==list(range(len(ctx.durations)))
    for j in order:
        for a,profile in enumerate(ctx.powers[j]):
            s=starts[j][a];d=len(profile)
            assert type(s) is int and 0<=s<=h-d
            assert a==0 or s>=starts[j][a-1]+ctx.durations[j][a-1]
            for u,p in enumerate(profile):gross[s+u]+=p
    for j,k in zip(order,order[1:]):
        assert all(starts[k][a]>=starts[j][a]+d for a,d in enumerate(ctx.durations[j]))
    return sum(c*max(0,g-r) for c,g,r in zip(ctx.carbon,gross,ctx.renewable))


class Tick:
    def __init__(self):self.value=-1
    def __call__(self):self.value+=1;return self.value


def validate(out,instance):
    ctx=PreparedInput(instance).context
    best=None;value=None;eligible=[]
    for i,p in enumerate(out['registered_attempts']):
        got=physics(ctx,p['permutation'],p['starts'])
        assert got==p['score_numerator'] and F(p['score_fraction'])==F(got,ctx.denominator)
        assert p['eligible']==(p['available_seconds']<=out['budget_seconds'])
        strict=p['eligible'] and (value is None or got<value)
        assert p['strict_global_incumbent']==strict
        if strict:best,value=p,got
        if p['eligible']:eligible.append(i)
    assert out['best_registered']==best
    for r in out['repairs']:
        assert out['registered_attempts'][r['anchor_attempt_id']]['eligible']
        if r['neighborhood_proved_optimal']:
            assert r['proof_ready_seconds']<r['slice_deadline_seconds']
            assert r['proof_ready_seconds']<out['budget_seconds']
        for i in r['registered_attempt_ids']:
            assert out['registered_attempts'][i]['score_numerator']<out['registered_attempts'][r['anchor_attempt_id']]['score_numerator']
    return len(out['registered_attempts'])


def main(output):
    rng=random.Random(19720261026)
    checked=brute=points=0;rows=[];fixtures=[];abort_checks=0
    for ix in range(120):
        n,m=rng.randint(1,3),rng.randint(1,3);h=9
        while True:
            powers=tuple(tuple(tuple(rng.randrange(8) for _ in range(rng.randrange(3))) for _ in range(m)) for _ in range(n))
            if sum(len(op) for job in powers for op in job)<=6:break
        scale=10**40 if ix%7==0 else 1
        powers=tuple(tuple(tuple(p*scale for p in op) for op in job) for job in powers)
        carbon_scale=10**30 if ix%13==0 else 1
        instance=Instance('constructed_v197_'+str(ix),powers,
            tuple(rng.randrange(12)*scale for _ in range(h)),
            tuple(rng.randrange(6)*carbon_scale for _ in range(h)))
        fixtures.append(instance)
        prepared=PreparedInput(instance);ctx=prepared.context
        order=list(range(n));rng.shuffle(order)
        grid=temporal_grid(ctx.durations,order,h)
        initial=matrix(grid,grid.lower)
        slack=h-max(initial[j][a]+d for j in order for a,d in enumerate(ctx.durations[j]))
        shift=rng.randrange(slack+1)
        initial=[[s+shift for s in row] for row in initial]
        owned=prepared.anchor(order,initial)
        for a in range(m):
            result=serial_response(prepared,owned,a,capture_certificate=True)
            reference=ViableChainTiming(prepared,order,owned,[a]).run()
            assert result['score_numerator']==reference['best']['score_numerator']
            assert physics(ctx,order,result['starts'])==result['score_numerator']
            free=[j for j in order if ctx.durations[j][a]]
            minimum=None;feasible=0
            for ts in itertools.product(*(range(h-ctx.durations[j][a]+1) for j in free)):
                candidate=[list(row) for row in initial]
                for j,t in zip(free,ts):candidate[j][a]=t
                lifted=lift_zero_operations(ctx,order,candidate)
                brute+=1
                if lifted is None:continue
                value=physics(ctx,order,lifted);feasible+=1
                minimum=value if minimum is None else min(minimum,value)
            assert feasible and minimum==result['score_numerator']
            checked+=1
            rows.append(dict(case=ix,row=a,free_positive_operations=len(free),
                feasible_assignments=feasible,DP_states=result['DP_states'],
                exact_score_numerator=result['score_numerator']))
            if ix<8:
                phases=[]
                serial_response(prepared,owned,a,checkpoint=phases.append)
                for phase in sorted(set(phases)):
                    def cut(p):
                        if p==phase:raise TimeoutError('constructed event cut')
                    try:serial_response(prepared,owned,a,checkpoint=cut)
                    except TimeoutError:abort_checks+=1
                    else:raise AssertionError('Interrupted response returned a proof')
    complete=[]
    for ix,instance in enumerate(fixtures[:36]):
        opts=dict(phase_max_evaluations=12,max_repairs=30,repair_slice_seconds=100000.)
        state=random.getstate()
        out=run_budgeted(lambda:instance,1000000.,ix,clock=lambda:0.,**opts)
        assert random.getstate()==state
        points+=validate(out,instance)
        complete.append(dict(case=ix,registrations=len(out['registered_attempts']),
            repairs=len(out['repairs']),ranking_builds=len(out['ranking_builds']),
            ranking_cache_hits=sum(r['ranking_cache_hit'] for r in out['repairs']),
            serial_improvements=sum(r['improved_global_best'] for r in out['repairs'] if r['selected_machine_rows'] and len(r['selected_machine_rows'])==1)))
    boundaries=[]
    for ix,instance in enumerate(fixtures[:8]):
        opts=dict(phase_max_evaluations=2,max_repairs=12,repair_slice_seconds=100000.)
        full=run_budgeted(lambda:instance,1000000.,ix,clock=Tick(),**opts)
        points+=validate(full,instance)
        cutoffs={1.,10.,50.,100.,200.}
        cutoffs.update(p['available_seconds']+d for p in full['registered_attempts'][:3] for d in (-.5,0,.5))
        cutoffs.update(r['proof_ready_seconds']+d for r in full['repairs'] if r['neighborhood_proved_optimal'] for d in (-.5,0,.5))
        for cutoff in sorted(cutoffs):
            if cutoff<=0:continue
            out=run_budgeted(lambda:instance,cutoff,ix,clock=Tick(),**opts)
            points+=validate(out,instance)
            boundaries.append(dict(case=ix,cutoff=cutoff,status=out['status']))
    put(output,dict(created_utc=datetime.now(timezone.utc).isoformat(),status='passed',
        constructed_instances=120,serial_rows_checked=checked,brute_assignments_checked=brute,
        original_one_row_DP_values_equal=True,all_zero_nodes_free=True,
        exact_above_64bit_powers_and_carbon=True,interruption_checks=abort_checks,
        complete_fixed_work_paths=complete,event_clock_cuts=boundaries,
        independently_recomputed_physical_points=points,rows=rows,
        public_optimizer_calls=0,protected270_contents_read=False,
        source_sha256={p:sha(p) for p in ['src/cas_pfsp_v197/serial.py','src/cas_pfsp_v197/search.py','src/cas_pfsp_v197/runtime.py','scripts/check_cas_serial_rows_v197.py']},
        design_sha256=sha('research/cas_serial_rows_v197/design_before_qualification_v197.json')))
    print(dict(status='passed',serial_rows=checked,brute_assignments=brute,
        interruption_checks=abort_checks,complete_paths=36,event_clock_cuts=len(boundaries),physical_points=points))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True)
    main(parser.parse_args().output)
