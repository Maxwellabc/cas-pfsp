"""Frozen same-budget controls and direct component deletions, with no partial quality access."""
import argparse, os, shutil, subprocess, traceback
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from random import Random
from cas_augmented_witness_common_v100 import safe, read, sha, put
from revise_cas_recent_native_v180 import local_import_closure

AREA='research/cas_component_comparison_v218'
METHODS=['serial_rows','no_serial','no_pair','lexicographic','fast_wait','local_wait_raw','adaptive_cp_alns','lg_ucb26']

def prepare():
    old=read('research/cas_serial_confirmation_v210/protocol_v210.json')
    for path,digest in old['source_sha256'].items():assert sha(path)==digest,path
    safe(AREA).mkdir(exist_ok=False)
    p=dict(created_utc=datetime.now(timezone.utc).isoformat(),methods=METHODS,stages={},
        input_allowlist=old['input_allowlist'],roots=[2026102903,2026102917,2026102939],budget_seconds=5.,
        purpose='Direct equal-budget component deletions and contemporaneous recent literature mechanism controls',
        unchanged_full_candidate='v197r1',phase_fraction=.6,repair_slice_seconds=.5,
        deletion_contract={'no_serial':'Remove one-row groups; keep initializer, paired kernel and scoring',
            'no_pair':'Remove two-row groups; keep initializer, serial kernel and scoring',
            'lexicographic':'Keep both kernels and all scoring work; select groups lexicographically within size'},
        no_deletion_claim_for_older_ordered_policy=True,
        literature_controls={'adaptive_cp_alns':'EJOR 2025 Kasapidis framework mechanism adaptation, v153 unchanged',
            'lg_ucb26':'Information Sciences 2026 LgMOEA UCBx mechanism adaptation, v178 unchanged'},
        author_source_full_algorithm_reproductions=0,public_quality_read_before_freeze=False,
        partial_quality_policy='No public objective inspection before all 720 attempts and independent audit terminate',
        optimizer_retries=0,attempted_cells_never_rerun=True,cohorts_not_pooled=True,
        analysis='Exact three-root input means; percentage and absolute differences, W/T/L, paired-root losses, family summaries; descriptive only',
        ablation_hypotheses='Positive full-minus-deletion gains support that component under this allocation; adverse or zero effects must be reported',
        candidate_or_parameters_selected_from_this_cohort=False,significance_claim=False,
        protected270_contents_read=False,host_exclusive=False,workers=3,container_CPU_quota=1,
        worker_cpu_pinning=[0,1,2],container_memory='2g',
        assignment='All methods for one input/root share a worker; each input distributes its three roots over all workers',
        source_read_only=True,network='none',imports_preloaded=True,
        all_root_setup_selection_scoring_registration_inmemory_logging_charged=True,
        post_root_serialization_excluded=True,public_calls=720,private_calls=16)
    for key in ('base_image_id','CP_environment','CP_environment_manifest','CP_environment_manifest_sha256',
        'auditor_only_tomllib_adapter','auditor_adapter_destination'):p[key]=old[key]
    private=list({s['input']:s for s in old['stages']['private']['trials']}.values())
    for stage,inputs,roots,budget in [('private',private,[0],2.),('public',p['input_allowlist'],p['roots'],5.)]:
        for sub in ('runs','qa','logs'):safe(AREA+'/'+stage+'/'+sub).mkdir(parents=True)
        trials=[]
        for ci,case in enumerate(inputs):
            for ri,seed in enumerate(roots):
                for method in METHODS:
                    trials.append(dict(id=f'{stage}_{len(trials):04d}',input=case['input'],input_sha256=case['input_sha256'],
                        case=case['case'],family=case['family'],method=method,seed=seed,
                        worker=(ci+ri)%3 if stage=='public' else 0))
        order=list(range(len(trials)));Random(21820261026+len(trials)).shuffle(order)
        p['stages'][stage]=dict(trials=trials,execution_order=order,budget_seconds=budget)
    found=local_import_closure(['scripts/cas_component_driver_v218.py','scripts/cas_component_study_v218.py',
        'scripts/check_cas_components_v218.py'])
    found.update(c['input'] for c in p['input_allowlist']);found.update(c['input'] for c in private)
    p['source_sha256']={path:sha(path) for path in sorted(found)}
    put(AREA+'/protocol_v218.json',p)
    for path in sorted(found|{AREA+'/protocol_v218.json'}):
        dst=safe(AREA+'/source/'+path);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(safe(path),dst)
    for stage in ('private','public'):
        for sub in ('runs','qa'):safe(AREA+'/source/'+AREA+'/'+stage+'/'+sub).mkdir(parents=True)
    print(dict(frozen_calls=720,private_calls=16,files=len(found),protocol_sha256=sha(AREA+'/protocol_v218.json')))

def execute():
    p=read(AREA+'/protocol_v218.json')
    for path,digest in p['source_sha256'].items():assert sha(path)==sha(AREA+'/source/'+path)==digest,path
    assert sha(p['CP_environment_manifest'])==p['CP_environment_manifest_sha256']
    put(AREA+'/launch_v218.json',dict(created_utc=datetime.now(timezone.utc).isoformat(),pid=os.getpid()))
    def run(stage,role,worker=0):
        assert shutil.disk_usage(safe('.')).free>6_000_000_000
        cmd=['docker','run','--name',f'ijpe-cas-v218-{stage}-{role}-{worker}','--pull=never','--platform','linux/arm64',
            '--read-only','--network','none','--cpus','1','--cpuset-cpus',str(worker),'--memory','2g',
            '--tmpfs','/tmp:rw,size=256m','--workdir','/source','--env','PYTHONPATH=/source/src:/source/scripts',
            '--env','OPENBLAS_NUM_THREADS=1','--env','OMP_NUM_THREADS=1','--env','MKL_NUM_THREADS=1',
            '--mount',f'type=bind,source={safe(AREA+"/source")},target=/source,readonly']
        for name in ('private','public'):
            cmd+=['--mount',f'type=bind,source={safe(AREA+"/"+name+"/runs")},target=/source/{AREA}/{name}/runs'+
                ('' if role=='producer' and name==stage else ',readonly')]
            if name==stage and role in ('component','auditor'):
                cmd+=['--mount',f'type=bind,source={safe(AREA+"/"+name+"/qa")},target=/source/{AREA}/{name}/qa']
            elif name=='private':
                cmd+=['--mount',f'type=bind,source={safe(AREA+"/private/qa")},target=/source/{AREA}/private/qa,readonly']
        producing=role in ('component','producer')
        if producing:cmd+=['--mount',f'type=bind,source={safe(p["CP_environment"])},target=/cpsat-env,readonly']
        else:cmd+=['--mount',f'type=bind,source={safe(p["auditor_only_tomllib_adapter"])},target={p["auditor_adapter_destination"]},readonly']
        cmd += [p['base_image_id'],'/cpsat-env/bin/python' if producing else 'python','-B','-u']
        if role=='component':cmd+=['/source/scripts/check_cas_components_v218.py']
        else:cmd+=['/source/scripts/cas_component_driver_v218.py','--stage',stage,'--role',role,'--worker',str(worker)]
        prefix=AREA+'/'+stage+'/logs/'+role+'_'+str(worker)
        with safe(prefix+'_stdout.txt').open('x') as stdout,safe(prefix+'_stderr.txt').open('x') as stderr:
            rc=subprocess.run(cmd,stdout=stdout,stderr=stderr,timeout=10000).returncode
        put(prefix+'_terminal.json',dict(returncode=rc,command=cmd,created_utc=datetime.now(timezone.utc).isoformat()))
        assert rc==0,(stage,role,worker)
    def combine(stage,n):
        attempts=[]
        for w in range(n):attempts+=read(AREA+'/'+stage+'/runs/worker_'+str(w)+'_terminal_v218.json')['attempts']
        assert len(attempts)==len(p['stages'][stage]['trials']) and len({a['id'] for a in attempts})==len(attempts)
        put(AREA+'/'+stage+'/runs/all_attempts_terminal_v218.json',dict(protocol_sha256=sha(AREA+'/protocol_v218.json'),
            attempts=attempts,partial_quality_read=False,optimizer_retries=0))
    try:
        run('private','component');run('private','producer');combine('private',1);run('private','auditor')
        assert not read(AREA+'/private/qa/independent_QA_v218.json')['technical_failures']
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures=[pool.submit(run,'public','producer',w) for w in range(3)]
            for f in futures:f.result()
        combine('public',3);run('public','auditor')
        put(AREA+'/terminal_v218.json',dict(status='all720_attempted_and_independently_audited',
            created_utc=datetime.now(timezone.utc).isoformat(),optimizer_retries=0,protected270_contents_read=False))
    except Exception as e:
        put(AREA+'/failure_v218.json',dict(error=repr(e),traceback=traceback.format_exc(),optimizer_retry=False));raise

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['prepare','execute'],required=True)
    prepare() if ap.parse_args().mode=='prepare' else execute()
