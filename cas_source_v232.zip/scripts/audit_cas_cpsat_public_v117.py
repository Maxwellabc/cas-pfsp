"""Independent public incumbent physics and clock audit; no solver imports."""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
from fractions import Fraction as F
import gzip
import hashlib
import json
import math
from cas_augmented_witness_common_v100 import safe, read, sha, put
from audit_cas_cpsat_budget_v116 import objective

AREA = 'research/cas_cpsat_public_v117'


def load_case(path):
    raw = safe(path).read_bytes()
    rows = [x for x in csv.reader(raw.decode('utf-8-sig').splitlines()) if x and any(y.strip() for y in x)]
    assert len(rows[0]) == 12
    header = list(map(F, rows[0])); m, days, n = map(int, header[:3])
    assert header[:3] == [m, days, n] and min(m, days, n) > 0
    assert len(rows) in (n*m+3, n*m+4)
    powers = [[None]*m for _ in range(n)]
    for index, row in enumerate(rows[1:n*m+1]):
        j, a = divmod(index, m)
        if m > 1:
            assert list(map(F, row[:2])) == [j, a]
            row = row[2:]
            if row == ['']: row = []
        powers[j][a] = list(map(F, row))
    renewable, carbon = [list(map(F, x)) for x in rows[n*m+1:n*m+3]]
    assert len(renewable) == len(carbon) == 96*days
    assert sum(len(op) for job in powers for op in job) == header[3]
    assert sum(sum(op) for job in powers for op in job) == header[4]
    assert all(x >= 0 for job in powers for op in job for x in op)
    assert all(x >= 0 for x in renewable + carbon)
    if len(rows) == n*m+4: assert len(rows[-1]) == 96*days
    return {'powers': powers, 'renewable': renewable, 'carbon': carbon}, hashlib.sha256(raw).hexdigest()


def physical(case, point):
    powers = case['powers']; n, m, h = len(powers), len(powers[0]), len(case['carbon'])
    order, starts = point['permutation'], point['starts']
    assert len(order) == n and all(type(x) is int for x in order) and sorted(order) == list(range(n))
    assert len(starts) == n and all(len(row) == m for row in starts)
    durations = [[len(op) for op in job] for job in powers]
    gross = [F(0) for _ in range(h)]
    for j in range(n):
        for a in range(m):
            start = starts[j][a]
            assert type(start) is int and 0 <= start <= h - durations[j][a]
            if a: assert starts[j][a-1] + durations[j][a-1] <= start
            for offset, value in enumerate(powers[j][a]): gross[start+offset] += value
    for before, after in zip(order, order[1:]):
        assert all(starts[before][a]+durations[before][a] <= starts[after][a] for a in range(m))
    value = sum((c*max(0, q-r)/4 for c, q, r in zip(case['carbon'], gross, case['renewable'])), F(0))
    assert value == F(point['score_fraction'])
    dp = math.lcm(1, *(x.denominator for job in powers for op in job for x in op), *(x.denominator for x in case['renewable']))
    dc = math.lcm(1, *(x.denominator for x in case['carbon']))
    assert value*4*dp*dc == point['score_numerator']
    return value


def check_record(spec, record, budget, protocol_sha):
    assert record['trial'] == spec and record['protocol_sha256'] == protocol_sha
    runtime = record['runtime']
    assert runtime['Python'] == '3.10.19' and runtime['NumPy'] == '2.2.6'
    assert runtime['ORTools'] == '9.15.6755' and runtime['prefix'] == '/cpsat-env'
    case, inputsha = load_case(spec['input'])
    assert inputsha == spec['input_sha256']
    result = record['result']; eps = 1e-7
    assert result['budget_seconds'] == budget and result['presolve'] is True
    assert result['input_sha256'] in (None, inputsha)
    assert result['eligibility_rule'] == 'available_seconds<=budget_seconds'
    assert result['input_context_model_callbacks_registration_and_policy_charged']
    assert result['module_loading_excluded_from_core'] and result['JSON_serialization_after_core']
    assert not result['unpaid_initializer_or_external_cache'] and not result['hard_return_deadline_guaranteed']
    elapsed = result['algorithm_wall_seconds']
    assert elapsed >= 0 and result['overshoot_seconds'] == max(0., elapsed-budget)
    best, value = None, None
    for attempt in result['registered_attempts']:
        score = physical(case, attempt)
        assert 0 <= attempt['registration_started_seconds'] <= attempt['available_seconds'] <= elapsed+eps
        if attempt['eligible']: assert attempt['available_seconds'] <= budget+eps
        else: assert attempt['available_seconds'] > budget-eps
        strict = attempt['eligible'] and (value is None or score < value)
        assert attempt['strict_global_incumbent'] == bool(strict)
        if strict: best, value = attempt, score
    assert result['best_registered'] == best
    den, base, digits = objective(case)
    if result['objective_digits'] is not None:
        assert result['objective_digits'] == digits and int(result['objective_denominator']) == den
    seen = set(); proofs = []
    for number, stage in enumerate(result['stages']):
        assert stage['digit'] == digits-number-1
        assert 0 <= stage['call_started_seconds'] < budget+eps
        assert abs(stage['native_time_limit_seconds']-(budget-stage['call_started_seconds'])) < eps
        assert stage['call_started_seconds'] <= stage['returned_seconds'] <= elapsed+eps
        for event in stage['events']:
            index = event['attempt_id']; assert 0 <= index < len(result['registered_attempts'])
            attempt = result['registered_attempts'][index]
            assert event['paid_within_run_cache_hit'] == (index in seen)
            seen.add(index)
            assert event['reference_ready_seconds'] >= attempt['available_seconds']-eps
            assert event['referenced_registration_eligible'] == attempt['eligible']
            if not event['paid_within_run_cache_hit']:
                integer = int(attempt['origin']['scaled_integer_objective'])
                assert F(integer, den) == F(attempt['score_fraction'])
        assert stage['native_status'] in ('OPTIMAL', 'FEASIBLE', 'UNKNOWN', 'INFEASIBLE')
        if stage['proof_used']:
            # Global optimality is solver-reported, not an independently verified
            # public mathematical proof; the budget/prefix bookkeeping is checked.
            assert stage['native_status'] == 'OPTIMAL'
            assert stage['proof_ready_seconds'] <= budget+eps
            proofs.append({'digit': stage['digit'], 'value': stage['optimal_digit_value'], 'ready_seconds': stage['proof_ready_seconds']})
    assert seen == set(range(len(result['registered_attempts']))) and proofs == result['proved_optimal_prefix']
    complete = len(proofs) == digits
    assert result['status'] == ('OPTIMAL' if complete else 'FEASIBLE' if best else 'UNKNOWN')
    assert result['all_digits_proved_within_budget'] == complete
    if complete:
        assert best is not None
        integer = F(best['score_fraction'])*den
        assert integer.denominator == 1
        assert all(int(integer)//base**p['digit']%base == p['value'] for p in proofs)
    return {'id': spec['id'], 'case': spec['case'], 'status': result['status'],
        'eligible_incumbent': best is not None, 'best_score_fraction': None if best is None else str(value),
        'physical_registrations': len(result['registered_attempts']), 'CP_calls': len(result['stages']),
        'model_ready_seconds': result['setup'].get('model_ready_seconds'),
        'algorithm_wall_seconds': elapsed, 'overshoot_seconds': result['overshoot_seconds'],
        'stop_reason': result['stop_reason'], 'solver_reported_global_optimality': complete}


def read_record(out, stem):
    receipt = read(out+'/'+stem+'_receipt.json')
    path = out+'/'+stem+'.json.gz'
    assert sha(path) == receipt['compressed_sha256']
    raw = gzip.decompress(safe(path).read_bytes())
    assert hashlib.sha256(raw).hexdigest() == receipt['uncompressed_json_sha256']
    return json.loads(raw)


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--private-preflight', action='store_true'); args = parser.parse_args()
    path = AREA+'/protocol_v117.json'; protocol = read(path)
    if args.private_preflight:
        row = check_record(protocol['private_preflight'], read_record(AREA+'/preflight_r1', 'private'), 5., sha(path))
        assert row['status'] == 'OPTIMAL' and F(row['best_score_fraction']) == F(1, 2)
        put(AREA+'/preflight_r1/independent_qa_v117.json', {'created_utc': datetime.now(timezone.utc).isoformat(),
            'status': 'private_actual_entry_export_and_independent_physics_passed_v117',
            'protocol_sha256': sha(path), 'row': row, 'public_calls': 0})
        print({'private_preflight': 'passed'}); return
    out = AREA+'/execution_r1'
    terminals = read(out+'/execution_terminal_v117.json')
    assert terminals['protocol_sha256'] == sha(path) and len(terminals['trials']) == 30
    rows = []
    for spec, terminal in zip(protocol['trials'], terminals['trials']):
        assert terminal['id'] == spec['id'] and terminal['returncode'] == 0 and not terminal['timed_out']
        stem = f"trial_{spec['id']:03d}"
        assert sha(out+'/'+stem+'.json.gz') == terminal['compressed_sha256']
        rows.append(check_record(spec, read_record(out, stem), protocol['core_budget_seconds'], sha(path)))
    assert len(rows) == 30 and len({x['case'] for x in rows}) == 30
    put(out+'/independent_qa_v117.json', {'created_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'all30_standard_reference_incumbent_physics_and_budget_records_audited_v117',
        'protocol_sha256': sha(path), 'rows': rows, 'status_counts': dict(Counter(x['status'] for x in rows)),
        'eligible_incumbent_count': sum(x['eligible_incumbent'] for x in rows),
        'public_global_optimality_independently_proved': False,
        'solver_imported_by_auditor': False, 'candidate_promoted': False, 'goal_complete': False})
    print({'all30_reference_audit': 'passed', 'eligible_incumbents': sum(x['eligible_incumbent'] for x in rows)})


if __name__ == '__main__':
    main()
