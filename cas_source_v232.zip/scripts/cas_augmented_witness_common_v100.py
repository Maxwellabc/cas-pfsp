"""Paths and IO for an offline private witness-set diagnostic."""
from pathlib import Path
import gzip,hashlib,json

ROOT=Path(__file__).resolve().parents[1]
AREA='research/cas_augmented_witness_v100'
OLD='research/cas_relative_inheritance_v92/results_stdlib_v92.json.gz'
FIXTURES='research/cas_energy_flow_v91/fixtures_v91.json'
OLD_QA='research/qa/cas_relative_inheritance_independent_v92.json'
BASE=('earliest','latest','ordinary_target','absolute_target')
EXTRAS=('normalized_target','raw_local_wait','normalized_local_wait')
SCOPES=('all_transitions','changed_order_only','source_orbit_optimal','changed_order_and_source_orbit_optimal')
PAIRS=(('primary_target_vs_normalized_wait','normalized_target','normalized_local_wait'),
       ('target_vs_raw_wait','normalized_target','raw_local_wait'),
       ('normalized_vs_raw_wait','normalized_local_wait','raw_local_wait'),
       ('target_increment','normalized_target','base4'),('raw_wait_increment','raw_local_wait','base4'),
       ('normalized_wait_increment','normalized_local_wait','base4'))


def safe(rel):
    p=(ROOT/rel).resolve()
    if not p.is_relative_to(ROOT) or 'neso_' in str(p).lower():raise ValueError('Disallowed path before content access')
    return p


def sha(rel):return hashlib.sha256(safe(rel).read_bytes()).hexdigest()
def read(rel):return json.loads(safe(rel).read_bytes())
def read_gz(rel):
    with gzip.open(safe(rel),'rt') as f:return json.load(f)
def put(rel,data):
    with safe(rel).open('x') as f:json.dump(data,f,indent=2,allow_nan=False);f.write('\n')


def in_scope(old,scope):
    changed=old['source_order']!=old['destination_order'];optimal=old['source_at_own_orbit_minimum']
    return {'all_transitions':True,'changed_order_only':changed,'source_orbit_optimal':optimal,
        'changed_order_and_source_orbit_optimal':changed and optimal}[scope]
