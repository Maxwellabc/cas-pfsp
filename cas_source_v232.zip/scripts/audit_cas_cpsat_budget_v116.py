"""Independent physics, exact-prefix truth, clock and eligibility accounting."""
from datetime import datetime,timezone
from fractions import Fraction as F
from collections import Counter
import math
from audit_cas_closure_certificate_v53 import enumerate_tiny
from cas_augmented_witness_common_v100 import read,sha,put

AREA='research/cas_cpsat_budget_v116'


def objective(case):
    powers=[[[F(x) for x in op] for op in job] for job in case['powers']]
    dp=math.lcm(1,*(x.denominator for job in powers for op in job for x in op))
    cap=sum(int(max(op,default=0)*dp) for job in powers for op in job)
    terms=[]
    for r,c in zip(map(F,case['renewable']),map(F,case['carbon'])):
        r*=dp
        if r>=cap:continue
        a=r.numerator//r.denominator;f=r-a
        terms += [(c,cap-a)] if f==0 else [(c,max(0,cap-a-1)),(c*(1-f),1)]
    scale=math.lcm(1,*(c.denominator for c,u in terms));upper=sum(int(c*scale)*u for c,u in terms)
    mass=sum(u for c,u in terms if c and u);base=2
    while base*2<=2**20 and 2*mass*base*2<=2**60:base*=2
    count=1
    while base**count<=upper:count+=1
    return 4*dp*scale,base,count


def physics(case,record):
    order,starts=record['permutation'],record['starts'];p=case['powers']
    n,m,h=len(p),len(p[0]),len(case['carbon']);d=[[len(x) for x in job] for job in p]
    assert sorted(order)==list(range(n)) and len(starts)==n
    assert all(len(x)==m for x in starts)
    for j in range(n):
        for a in range(m):
            assert type(starts[j][a]) is int and 0<=starts[j][a]<=h-d[j][a]
            if a:assert starts[j][a]>=starts[j][a-1]+d[j][a-1]
    for i,j in zip(order,order[1:]):
        for a in range(m):assert starts[j][a]>=starts[i][a]+d[i][a]
    total=F(0)
    for t in range(h):
        q=sum((F(op[t-starts[j][a]]) for j,job in enumerate(p) for a,op in enumerate(job)
               if 0<=t-starts[j][a]<len(op)),F(0))
        total+=F(case['carbon'][t])*max(0,q-F(case['renewable'][t]))/4
    assert total==F(record['score_fraction'])
    return total


def main():
    auditplan=read(AREA+'/audit_plan_v116.json')
    for rel,digest in auditplan['sources_sha256'].items():assert sha(rel)==digest
    p=read(AREA+'/protocol_v116.json');out=read(AREA+'/run_r1/results_v116.json')
    extra=read(AREA+'/run_r1/setup_extension_results_v116.json')
    assert out['protocol_sha256']==sha(AREA+'/protocol_v116.json')
    assert extra['plan_sha256']==sha(AREA+'/setup_extension_plan_v116.json')
    assert len(out['runs'])==77 and len(extra['runs'])==4
    assert len(out['constructor_parity'])==32 and all(x['mathematical_model_proto_text_identical'] for x in out['constructor_parity'])
    truths={};complete_count=0;attempts_checked=0;native_calls=0;labels={};statuses=Counter()
    for casefile in p['private_case_files']:
        case=read(casefile);states,_=enumerate_tiny(case)
        truth=[score for values in states.values() for _,score in values]
        truths[casefile]=truth
    runs=out['runs']+extra['runs']
    for run in runs:
        label=run['label'];labels[label]=run
        case=read(run['case_file']);assert sha(run['case_file'])==run['case_sha256']
        r=run['result'];budget=r['budget_seconds'];tick=run['clock_kind']=='artificial_event_ticks_not_wall_seconds'
        # Real relative timestamps can lose less than a clock ULP at a large
        # absolute origin. Tick-boundary checks are exact, without tolerance.
        eps=0 if tick else 1e-7
        assert r['algorithm_wall_seconds']>=0 and r['overshoot_seconds']==max(0.,r['algorithm_wall_seconds']-budget)
        assert r['eligibility_rule']=='available_seconds<=budget_seconds'
        best=None;best_value=None
        for rec in r['registered_attempts']:
            value=physics(case,rec);attempts_checked+=1
            assert 0<=rec['registration_started_seconds']<=rec['available_seconds']<=r['algorithm_wall_seconds']+eps
            if rec['eligible']:assert rec['available_seconds']<=budget+eps
            else:assert rec['available_seconds']>budget-eps
            strict=rec['eligible'] and (best_value is None or value<best_value)
            assert bool(rec['strict_global_incumbent'])==bool(strict)
            if strict:best,best_value=rec,value
        assert r['best_registered']==best
        assert r['unpaid_initializer_or_external_cache'] is False
        seen=set();proofs=[];native_calls+=len(r['stages'])
        den,base,digits=objective(case)
        truth=truths.get(run['case_file'])
        remaining_truth=None if truth is None else [int(x*den) for x in truth]
        if truth is not None:assert all((x*den).denominator==1 for x in truth)
        for number,stage in enumerate(r['stages']):
            assert stage['digit']==digits-number-1
            assert 0<=stage['call_started_seconds']<budget+eps
            assert abs(stage['native_time_limit_seconds']-(budget-stage['call_started_seconds']))<=eps+1e-9
            assert stage['returned_seconds']>=stage['call_started_seconds'] and stage['returned_seconds']<=r['algorithm_wall_seconds']+eps
            for event in stage['events']:
                ix=event['attempt_id'];assert 0<=ix<len(r['registered_attempts'])
                assert event['paid_within_run_cache_hit']==(ix in seen)
                seen.add(ix);rec=r['registered_attempts'][ix]
                assert event['reference_ready_seconds']>=rec['available_seconds']-eps
                assert event['referenced_registration_eligible']==rec['eligible']
            if stage['proof_used']:
                assert stage['proof_ready_seconds']<=budget+eps
                if stage['native_status']=='INFEASIBLE':
                    assert truth==[] and best is None
                else:
                    assert stage['native_status']=='OPTIMAL' and remaining_truth
                    value=stage['optimal_digit_value'];level=stage['digit']
                    expected=min((x//base**level)%base for x in remaining_truth)
                    assert value==expected
                    remaining_truth=[x for x in remaining_truth if x//base**level%base==value]
                    proofs.append({'digit':level,'value':value,'ready_seconds':stage['proof_ready_seconds']})
        assert seen==set(range(len(r['registered_attempts'])))
        assert proofs==r['proved_optimal_prefix']
        complete=len(proofs)==digits
        infeasible=any(x['native_status']=='INFEASIBLE' and x['proof_used'] for x in r['stages'])
        expected_status='OPTIMAL' if complete else 'FEASIBLE' if best else 'INFEASIBLE' if infeasible else 'UNKNOWN'
        assert r['status']==expected_status and r['all_digits_proved_within_budget']==complete
        if complete:
            assert truth and best_value==min(truth)
        if label=='complete_private':
            assert r['status']==('OPTIMAL' if truth else 'INFEASIBLE')
            complete_count+=1
        statuses[r['status']]+=1
    assert complete_count==64
    for suffix,eligible in [('before',False),('exact',True),('after',True)]:
        run=labels['registration_'+suffix];r=run['result'];rec=r['registered_attempts'][0]
        assert rec['eligible']==eligible
        assert rec['available_seconds']==out['diagnostic_boundary_reference']['first_physical_availability']
        assert r['status']!='OPTIMAL'
    assert labels['registration_exact']['result']['registered_attempts'][0]['available_seconds']==labels['registration_exact']['result']['budget_seconds']
    for suffix,count in [('before',0),('exact',1),('after',1)]:
        r=labels['prefix_'+suffix]['result'];assert len(r['proved_optimal_prefix'])==count and r['status']=='FEASIBLE'
    assert labels['expired_before_load']['result']['input_sha256'] is None
    paid=labels['paid_loader_expiry']['result'];assert paid['input_sha256'] is not None and not paid['stages'] and paid['best_registered'] is None
    assert paid['algorithm_wall_seconds']>=0.02
    setup=[x['result'] for x in extra['runs']]
    assert all(not x['stages'] and x['best_registered'] is None and x['status']=='UNKNOWN' for x in setup)
    assert any(x['stop_reason']=='budget_at_before_input_load' for x in setup)
    assert any(x['stop_reason']=='budget_at_after_context' for x in setup)
    assert any(x['last_checkpoint'] in ('operation_start_choices','load_slot','objective_digit','model_validation','model_complete') for x in setup)
    assert [x['kind'] for x in out['invalid_budgets']]==['zero','negative','nonfinite']
    assert all('Positive finite core budget' in x['error'] for x in out['invalid_budgets'])
    put('research/qa/cas_cpsat_budget_independent_v116.json',{'created_utc':datetime.now(timezone.utc).isoformat(),
        'status':'same_constructor_models_private_optima_eligible_callbacks_boundary_equality_prefix_and_setup_expiry_checked_v116',
        'protocol_sha256':sha(AREA+'/protocol_v116.json'),'results_sha256':sha(AREA+'/run_r1/results_v116.json'),
        'setup_extension_results_sha256':sha(AREA+'/run_r1/setup_extension_results_v116.json'),
        'constructor_private_cases_matching_parent_proto':32,'complete_real_private_calls':64,
        'total_policy_invocations':81,'primitive_real_CP_calls':native_calls,'physical_registration_attempts_checked':attempts_checked,
        'status_counts':dict(statuses),'exact_registration_boundary_equality_checked':True,
        'partial_prefix_never_promoted_to_global_optimum':True,'paid_input_context_and_model_expiry_checked':True,
        'event_tick_diagnostics_distinguished_from_wall_time':True,'real_relative_timestamp_audit_tolerance_seconds':1e-7,
        'CP_solver_model_or_producer_imported_by_auditor':False,'native_CP_solver_faked':False,
        'public_quality_calls':0,'hard_return_latency_or_general_performance_qualified':False,
        'candidate_promoted':False,'goal_complete':False})
    print({'calls':81,'real_CP_calls':native_calls,'registrations':attempts_checked,'statuses':dict(statuses)},flush=True)


if __name__=='__main__':main()
