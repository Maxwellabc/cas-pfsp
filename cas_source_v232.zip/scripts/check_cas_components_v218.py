"""Constructed path equivalence, component selection, and charged cutoff checks."""
from datetime import datetime, timezone
import random
from cas_augmented_witness_common_v100 import put
from cas_pfsp_v45.model import Instance
from cas_pfsp_v197.search import run_budgeted as original
from cas_pfsp_v218.search import run_budgeted as variant
from check_cas_serial_rows_v197 import Tick, validate

AREA='research/cas_component_comparison_v218'

def cleaned(out):
    return {k:v for k,v in out.items() if k not in ('algorithm_version','ablation','algorithm_cpu_seconds')}

def main():
    rng=random.Random(21820261026); paths=[]; cuts=[]; points=0
    for ix in range(8):
        n,m,h=4,3,22
        powers=tuple(tuple(tuple(rng.randrange(1,10) for _ in range(rng.randrange(3))) for _ in range(m)) for _ in range(n))
        ins=Instance('constructed_component218_'+str(ix),powers,
            tuple(rng.randrange(3) for _ in range(h)),tuple(rng.randrange(1,10) for _ in range(h)))
        kw=dict(phase_max_evaluations=5,max_repairs=24,repair_slice_seconds=100000.,clock=lambda:0.)
        ref=original(lambda:ins,1000000.,ix,**kw)
        full=variant(lambda:ins,1000000.,ix,**kw)
        assert cleaned(full)==cleaned(ref)
        # validate recomputes every point; independent composition replay is applied by the stdlib auditor.
        for name in ('full','no_serial','no_pair','lexicographic'):
            out=full if name=='full' else variant(lambda:ins,1000000.,ix,ablation=name,**kw)
            points+=validate(out,ins)
            sizes=[len(r['selected_machine_rows']) for r in out['repairs'] if r['selected_machine_rows']]
            assert name!='no_serial' or all(s==2 for s in sizes)
            assert name!='no_pair' or all(s==1 for s in sizes)
            assert out['phase_fraction']==.6 and out['repair_slice_seconds']==100000.
            paths.append(dict(case=ix,variant=name,repairs=len(sizes),sizes=sizes))
            for limit in (1.,50.,200.,1000.):
                cut=variant(lambda:ins,limit,ix,ablation=name,clock=Tick(),phase_max_evaluations=2,max_repairs=10)
                points+=validate(cut,ins)
                cuts.append(dict(case=ix,variant=name,cutoff=limit,status=cut['status']))
    put(AREA+'/private/qa/component_qualification_v218.json',dict(status='passed',
        created_utc=datetime.now(timezone.utc).isoformat(),full_clone_paths_equal_to_frozen_v197=8,
        constructed_paths=paths,cutoff_checks=cuts,physical_points_recomputed=points,
        public_calls=0,protected270_contents_read=False))
    print(dict(status='passed',paths=len(paths),cutoffs=len(cuts),physical_points=points),flush=True)

if __name__=='__main__':main()
