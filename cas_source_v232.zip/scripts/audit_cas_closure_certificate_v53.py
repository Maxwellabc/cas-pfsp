"""Standalone exact flow/cut and CAS bound checker; no production solver imports."""
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
import itertools
import math


def exact_context(powers,supply,carbon):
    ps=math.lcm(*(F(x).denominator for x in itertools.chain(supply,*(op for job in powers for op in job))))
    cs=math.lcm(*(F(x).denominator for x in carbon))
    return {'powers':[[[int(F(x)*ps) for x in op] for op in job] for job in powers],
            'supply':[int(F(x)*ps) for x in supply],'carbon':[int(F(x)*cs) for x in carbon],
            'denominator':4*ps*cs}


def check_timing(durations,order,horizon,starts):
    n=len(durations);m=len(durations[0])
    assert sorted(order)==list(range(n)) and len(starts)==n and all(len(row)==m for row in starts)
    for j in range(n):
        for a in range(m):
            assert type(starts[j][a]) is int and 0<=starts[j][a]<=horizon-durations[j][a]
            assert all(starts[j][b]+durations[j][b]<=starts[j][a] for b in range(a))
    for p,q in itertools.combinations(range(n),2):
        assert all(starts[order[p]][a]+durations[order[p]][a]<=starts[order[q]][a] for a in range(m))


def independent_windows(durations,order,horizon):
    pos={j:k for k,j in enumerate(order)};m=len(durations[0]);n=len(order)
    @lru_cache(None)
    def distance_before(r,a):
        return max(distance_before(r-1,a)+durations[order[r-1]][a] if r else 0,
                   distance_before(r,a-1)+durations[order[r]][a-1] if a else 0)
    @lru_cache(None)
    def distance_after(r,a):
        return durations[order[r]][a]+max(distance_after(r+1,a) if r+1<n else 0,
                                         distance_after(r,a+1) if a+1<m else 0)
    bounds={(j,a):(distance_before(pos[j],a),horizon-distance_after(pos[j],a))
            for j in order for a in range(m)}
    assert all(lo<=hi for lo,hi in bounds.values())
    return bounds


def check_unary_certificate(durations,order,horizon,costs,result):
    check_timing(durations,order,horizon,result['starts'])
    bounds=independent_windows(durations,order,horizon)
    nodes=[(j,a) for j in order for a in range(len(durations[0]))]
    labels=[(j,a,t) for j,a in nodes for t in range(bounds[j,a][0]+1,bounds[j,a][1]+1)]
    ids={label:k for k,label in enumerate(labels)};s=len(labels);sink=s+1
    weights=[costs[j,a][t]-costs[j,a][t-1] for j,a,t in labels]
    inf=1+sum(abs(w) for w in weights);expected=[]
    for k,w in enumerate(weights):
        if w>0:expected.append((k,sink,w))
        if w<0:expected.append((s,k,-w))
    pos={j:r for r,j in enumerate(order)}
    for j,a,t in labels:
        x=ids[j,a,t];lo=bounds[j,a][0]
        if t>lo+1:expected.append((x,ids[j,a,t-1],inf))
        after=[]
        if pos[j]+1<len(order):after.append((order[pos[j]+1],a))
        if a+1<len(durations[0]):after.append((j,a+1))
        for q,b in after:
            target=t+durations[j][a]
            if target>bounds[q,b][0]:expected.append((x,ids[q,b,target],inf))
    c=result['certificate'];assert c['threshold_labels']==[list(x) for x in labels]
    assert c['source']==s and c['sink']==sink and c['infinite_capacity']==inf
    edges=c['edges_capacity_flow']
    assert Counter(tuple(row[:3]) for row in edges)==Counter(expected)
    balance=[0]*(sink+1)
    for u,v,cap,flow in edges:
        assert all(type(x) is int for x in (u,v,cap,flow)) and 0<=flow<=cap
        balance[u]+=flow;balance[v]-=flow
    assert balance[s]==result['flow_value']==-balance[sink]
    assert not any(balance[:s])
    side=set(c['source_side']);assert len(side)==len(c['source_side']) and s in side and sink not in side
    assert all(type(x) is int and 0<=x<=sink for x in side)
    cut=sum(cap for u,v,cap,_ in edges if u in side and v not in side)
    assert cut==result['flow_value']
    assert all((k in side)==(result['starts'][j][a]>=t) for k,(j,a,t) in enumerate(labels))
    offset=sum(costs[j,a][bounds[j,a][0]] for j,a in nodes)+sum(w for w in weights if w<0)
    actual=sum(costs[j,a][result['starts'][j][a]] for j,a in nodes)
    assert actual==result['unary_optimum']==result['objective_offset']+cut==offset+cut
    assert result['threshold_nodes']==s and result['network_edges']==len(edges)
    return {'threshold_nodes':s,'network_edges':len(edges),'unary_optimum':actual}


def check_bound(ctx,order,result):
    p=ctx['powers'];a=ctx['supply'];c=ctx['carbon'];h=len(c)
    d=[[len(op) for op in job] for job in p];lam=result['lambdas']
    assert len(lam)==h and all(type(l) is int and 0<=l<=ct for l,ct in zip(lam,c))
    # Direct dot products, no production table builder or optimization.
    costs={(j,b):[sum(p[j][b][t-start]*lam[t] for t in range(start,start+d[j][b]))
                   for start in range(h-d[j][b]+1)] for j in range(len(p)) for b in range(len(p[0]))}
    cert=check_unary_certificate(d,order,h,costs,result)
    starts=result['starts']
    gross=[sum(p[j][b][t-starts[j][b]] for j in range(len(p)) for b in range(len(p[0]))
               if 0<=t-starts[j][b]<d[j][b]) for t in range(h)]
    true=sum(ct*max(q-at,0) for q,at,ct in zip(gross,a,c))
    raw=result['unary_optimum']-sum(at*l for at,l in zip(a,lam))
    assert result['raw_dual_numerator']==raw and result['lower_bound_numerator']==max(0,raw)<=true
    assert result['candidate_score_numerator']==true and result['gross']==gross
    assert result['denominator']==ctx['denominator'] and result['bound_scope']=='fixed_permutation_only'
    return cert


def enumerate_tiny(case):
    p=case['powers'];h=len(case['carbon']);n=len(p);m=len(p[0]);d=[[len(op) for op in job] for job in p]
    out={order:[] for order in itertools.permutations(range(n))};assignments=0
    for flat in itertools.product(*(range(max(0,h-x+1)) for row in d for x in row)):
        assignments+=1;starts=[list(flat[j*m:(j+1)*m]) for j in range(n)]
        if any(starts[j][a]<starts[j][b]+d[j][b] for j in range(n) for a in range(m) for b in range(a)):continue
        for order in out:
            if any(starts[order[q]][a]<starts[order[r]][a]+d[order[r]][a] for r in range(n) for q in range(r+1,n) for a in range(m)):continue
            gross=[sum(F(p[j][a][t-starts[j][a]]) for j in range(n) for a in range(m)
                       if 0<=t-starts[j][a]<d[j][a]) for t in range(h)]
            score=sum(F(ct)*max(q-F(at),0)/4 for q,at,ct in zip(gross,case['renewable'],case['carbon']))
            out[order].append((starts,score))
    return out,assignments
