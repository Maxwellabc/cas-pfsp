"""Independent public physics/accounting and exact six-input pilot statistics.

No producer, scheduling model, heuristic or CP backend imports. Solver-reported
public neighborhood proofs are checked for bookkeeping, not independently
certified mathematical optimality.
"""
from fractions import Fraction as F
import math
from audit_cas_cpsat_public_v117 import load_case
from audit_cas_complete_joint_search_v123 import arithmetic

METHODS = ('phase_full', 'joint_pair', 'joint_triple')


def context(case):
    ps = math.lcm(1, *(F(v).denominator for job in case['powers'] for op in job for v in op),
        *(F(v).denominator for v in case['renewable']))
    cs = math.lcm(1, *(F(v).denominator for v in case['carbon']))
    powers = [[[int(F(v)*ps) for v in op] for op in job] for job in case['powers']]
    return {'powers': powers, 'supply': [int(F(v)*ps) for v in case['renewable']],
        'carbon': [int(F(v)*cs) for v in case['carbon']], 'denominator': 4*ps*cs}


def gross(ctx, starts):
    values = [0]*len(ctx['carbon'])
    for j, job in enumerate(ctx['powers']):
        for a, op in enumerate(job):
            for k, power in enumerate(op): values[starts[j][a]+k] += power
    return values


def numerator(ctx, values):
    return sum(c*max(0, q-r) for q, r, c in zip(values, ctx['supply'], ctx['carbon']))


def key(point): return tuple(point['permutation']), tuple(x for row in point['starts'] for x in row)


def physics(ctx, point, cache):
    k = key(point)
    p = ctx['powers']; n, m, h = len(p), len(p[0]), len(ctx['carbon'])
    order, starts = point['permutation'], point['starts']
    assert len(order) == n and all(type(j) is int for j in order) and sorted(order) == list(range(n))
    assert len(starts) == n and all(len(row) == m for row in starts)
    for j in range(n):
        for a in range(m):
            assert type(starts[j][a]) is int and 0 <= starts[j][a] <= h-len(p[j][a])
            if a: assert starts[j][a] >= starts[j][a-1]+len(p[j][a-1])
    for before, after in zip(order, order[1:]):
        assert all(starts[after][a] >= starts[before][a]+len(p[before][a]) for a in range(m))
    if k not in cache: cache[k] = numerator(ctx, gross(ctx, starts))
    value = cache[k]
    assert type(point['score_numerator']) is int and value == point['score_numerator']
    assert F(value, ctx['denominator']) == F(point['score_fraction'])
    return F(value, ctx['denominator'])


def best_prefix(points, end):
    ids = [i for i, p in enumerate(points[:end]) if p['eligible']]
    return min(ids, key=lambda i: (F(points[i]['score_fraction']), i)) if ids else None


def validate(record, spec, protocol, case, inputsha, cache, budget):
    assert record['trial'] == spec and record['protocol_sha256'] == protocol['protocol_sha256_for_audit']
    assert inputsha == spec['input_sha256']
    rt = record['runtime']
    assert (rt['Python'], rt['NumPy'], rt['ORTools'], rt['prefix']) == ('3.10.19', '2.2.6', '9.15.6755', '/cpsat-env')
    assert record['global_Python_and_NumPy_RNG_unchanged']
    result = record['result']; eps = 1e-7
    assert result['input_sha256'] in (None, inputsha) and result['seed'] == spec['seed']
    assert abs(result['budget_seconds']-budget) <= eps
    elapsed = result['algorithm_wall_seconds']; assert elapsed >= 0
    ctx = context(case); points = result['registered_attempts']; best = None; bestvalue = None
    if result['input_sha256'] is None: assert not points
    for point in points:
        value = physics(ctx, point, cache)
        assert 0 <= point['registration_started_seconds'] <= point['available_seconds'] <= elapsed+eps
        if point['eligible']: assert point['available_seconds'] <= budget+eps
        else: assert point['available_seconds'] > budget-eps
        strict = point['eligible'] and (bestvalue is None or value < bestvalue)
        assert point['strict_global_incumbent'] == bool(strict)
        if strict: best, bestvalue = point, value
    assert result['best_registered'] == best
    status = 'OPTIMAL' if best is not None and bestvalue == 0 else 'FEASIBLE' if best is not None else 'UNKNOWN'
    assert record['normalized_status'] == status
    calls = 0; source = spec['method']; phase_end = 0
    if source == 'phase_full':
        assert record['source_component'] == 'frozen_v76_full_budget_phase'
        assert result['policy'] == 't1p1' and result['max_evaluations'] is None and result['phase_cache_capacity'] == 128
        assert result['stop_at_zero'] and result['global_Python_rng_unchanged'] and not result['donated_initializer_or_external_cache']
        assert not result['global_or_fixed_order_timing_optimum_claim']
    else:
        assert record['source_component'] == 'paid_v123_phase_CP'
        assert result['status'] == status and not result['positive_global_optimum_claim']
        assert result['phase_max_evaluations'] is None and result['max_repairs'] is None
        assert result['phase_fraction'] == .5 and result['repair_slice_seconds'] == .5
        assert result['max_positive_free'] == (2 if source == 'joint_pair' else 3)
        assert not result['donated_initializer_or_external_cache'] and not result['hard_return_deadline_guaranteed']
        phase = result['phase_component']
        if phase is not None:
            begin, phase_end = phase['physical_registry_attempt_range']; assert begin == 0 and phase_end <= len(points)
            assert phase['best_registered_attempt_id'] == best_prefix(points, phase_end)
            assert phase['shared_root_physical_registry'] and phase['policy'] == 't1p1'
        paid = set(range(phase_end)); attempted = set(); previous_end = phase_end
        for ix, repair in enumerate(result['repairs']):
            assert repair['id'] == ix and repair['registration_attempts_before'] == previous_end
            before, after = previous_end, repair['registration_attempts_after']; previous_end = after
            assert 0 <= before <= after <= len(points)
            aid = repair['anchor_attempt_id']; assert aid == best_prefix(points, before)
            anchor = points[aid]
            assert anchor['available_seconds'] <= repair['started_seconds']+eps
            cutoff = min(budget, repair['started_seconds']+.5)
            assert abs(repair['slice_deadline_seconds']-cutoff) <= eps
            assert repair['returned_seconds'] <= elapsed+eps
            assert repair['best_after_attempt_id'] == best_prefix(points, after)
            after_value = F(points[repair['best_after_attempt_id']]['score_fraction'])
            assert repair['improved_global_best'] == (after_value < F(anchor['score_fraction']))
            n, m = len(ctx['powers']), len(ctx['powers'][0]); operations = [(j, a) for j in range(n) for a in range(m)]
            positive = [op for op in operations if ctx['powers'][op[0]][op[1]]]; zero = set(operations)-set(positive)
            load = gross(ctx, anchor['starts']); ranking = []
            for j, a in positive:
                loss = 0
                for offset, power in enumerate(ctx['powers'][j][a]):
                    t = anchor['starts'][j][a]+offset
                    loss += ctx['carbon'][t]*(max(0, load[t]-ctx['supply'][t])-max(0, load[t]-power-ctx['supply'][t]))
                ranking.append(((j, a), loss))
            ranking.sort(key=lambda x: (-x[1], x[0]))
            expected_ranking = [{'operation': list(op), 'removal_score_fraction': str(F(v, ctx['denominator']))} for op, v in ranking]
            if repair['ranking']: assert repair['ranking'] == expected_ranking
            selected = repair['selected_positive_operations']
            if selected is None:
                assert after == before and not repair['stages']; continue
            assert repair['ranking'] == expected_ranking
            ordered = [op for op, _ in ranking]; expected = None
            for size in reversed(range(1, min(result['max_positive_free'], len(ordered))+1)):
                for offset in range(len(ordered)):
                    chosen = tuple(sorted(ordered[(offset+k)%len(ordered)] for k in range(size)))
                    exterior = tuple((j, a, anchor['starts'][j][a]) for j, a in sorted(ordered) if (j, a) not in chosen)
                    desc = tuple(anchor['permutation']), chosen, exterior
                    if desc not in attempted: expected = desc; break
                if expected is not None: break
            assert expected is not None and tuple(map(tuple, selected)) == expected[1]; attempted.add(expected)
            free = set(map(tuple, repair['free_operations'])); assert free == zero | set(map(tuple, selected))
            def belongs(point):
                return point['permutation'] == anchor['permutation'] and all(point['starts'][j][a] == anchor['starts'][j][a]
                    for j, a in operations if (j, a) not in free)
            assert all(belongs(point) for point in points[before:after])
            den, base, digits = arithmetic(case, anchor, free)
            if repair['stages']:
                assert int(repair['objective_denominator']) == den and repair['objective_base'] == base and repair['objective_digits'] == digits
            proofs = []
            for index, stage in enumerate(repair['stages']):
                calls += 1; assert stage['digit'] == digits-index-1
                assert 0 <= stage['call_started_seconds'] < cutoff+eps
                assert abs(stage['native_time_limit_seconds']-(cutoff-stage['call_started_seconds'])) <= eps
                assert stage['call_started_seconds'] <= stage['returned_seconds'] <= repair['returned_seconds']+eps
                for event in stage['events']:
                    pid = event['attempt_id']; assert 0 <= pid < after and belongs(points[pid])
                    assert event['paid_within_run_cache_hit'] == (pid in paid); paid.add(pid)
                    assert event['reference_ready_seconds'] >= points[pid]['available_seconds']-eps
                    assert event['referenced_registration_eligible'] == points[pid]['eligible']
                    assert (F(points[pid]['score_fraction'])*den).denominator == 1
                if stage['proof_used']:
                    assert stage['native_status'] == 'OPTIMAL' and stage['proof_ready_seconds'] <= cutoff+eps
                    assert 0 <= stage['optimal_digit_value'] < base
                    proofs.append({'digit': stage['digit'], 'value': stage['optimal_digit_value'], 'ready_seconds': stage['proof_ready_seconds']})
            assert proofs == repair['proved_optimal_prefix']
            assert repair['neighborhood_proved_optimal'] == (len(proofs) == digits)
            if repair['neighborhood_proved_optimal']:
                integer = sum(p['value']*base**p['digit'] for p in proofs)
                assert F(integer, den) == after_value
        assert paid == set(range(len(points)))
    initialization = best_prefix(points, phase_end) if source != 'phase_full' else best_prefix(points, len(points))
    return {'id': spec['id'], 'case': spec['case'], 'method': source, 'seed': spec['seed'], 'family': spec['family'],
        'normalized_status': status, 'best_fraction': None if best is None else str(bestvalue),
        'phase_component_best_fraction': None if initialization is None else points[initialization]['score_fraction'],
        'phase_component_budget_seconds': budget if source == 'phase_full' else .5*budget,
        'physical_registrations_checked': len(points), 'real_CP_calls': calls, 'algorithm_wall_seconds': elapsed,
        'budget_seconds': budget, 'root_overshoot_seconds': max(0., elapsed-budget)}


def statistics(rows, protocol):
    inputs = protocol['input_allowlist']; roots = protocol['quality_roots']; assert len(inputs) == 6 and len(roots) == 2
    by_key = {(x['case'], x['method'], x['seed']): x for x in rows}
    assert len(by_key) == len(rows) == 36
    means = {}; all_ranked = True
    for spec in inputs:
        for method in METHODS:
            values = [by_key[spec['case'], method, root]['best_fraction'] for root in roots]
            all_ranked &= all(v is not None for v in values)
            means[spec['case'], method] = None if any(v is None for v in values) else sum(map(F, values), F(0))/2
    comparisons = []
    for reference in ('joint_pair', 'phase_full'):
        cases = []; gains = []; positives = 0; zero_failure = False
        for spec in inputs:
            candidate = means[spec['case'], 'joint_triple']; baseline = means[spec['case'], reference]
            gain = None; convention = None
            if candidate is not None and baseline is not None:
                if baseline > 0: gain = 100*(baseline-candidate)/baseline
                elif candidate == 0: gain = F(0); convention = 'both_zero_tie_defined_as_zero_for_screen_only'
                else: zero_failure = True; convention = 'zero_reference_positive_candidate_rejects_screen'
                positives += candidate < baseline
            if gain is not None: gains.append(gain)
            cases.append({'case': spec['case'], 'family': spec['family'],
                'candidate_two_root_mean_fraction': None if candidate is None else str(candidate),
                'reference_two_root_mean_fraction': None if baseline is None else str(baseline),
                'improvement_percent_fraction': None if gain is None else str(gain), 'zero_convention': convention})
        mean = sum(gains, F(0))/6 if len(gains) == 6 else None
        passed = (all_ranked and not zero_failure and mean is not None and mean >= F(protocol['screen']['minimum_mean_percent'])
            and positives >= protocol['screen']['minimum_positive_inputs'] and min(gains) >= F(protocol['screen']['minimum_input_percent']))
        comparisons.append({'reference': reference, 'cases': cases, 'defined_inputs': len(gains),
            'mean_improvement_percent_fraction': None if mean is None else str(mean),
            'mean_improvement_percent': None if mean is None else float(mean), 'positive_inputs': positives,
            'zero_reference_positive_candidate': zero_failure, 'screen_passed_against_reference': bool(passed)})
    return {'unit_of_analysis': 'six developer inputs; ratio of two-root method means per input, then unweighted six-input mean',
        'all36_rankable': bool(all_ranked), 'comparisons': comparisons,
        'worth_broader_developer_study_screen_met': all(x['screen_passed_against_reference'] for x in comparisons),
        'family_observations_each': 1, 'publication_readiness_or_priority_proved': False, 'candidate_promoted': False}
