"""Constraint-coupled timing references under the unchanged v45 CAS model."""
