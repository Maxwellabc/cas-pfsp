"""Exact general two-operation timing and zero-duration projection references.

All choices keep the common permutation fixed. Full-node views preserve other
zero starts;positive views eliminate zero starts existentially and return a
canonical feasible lift. None of these standard graph/relaxation primitives
is claimed novel. Bounds/costs use frozen v47 exact integer accounting.
"""
from dataclasses import dataclass
from fractions import Fraction as F

from cas_pfsp_v47.pair_timing import (addition_interaction, exact_pair_repair,
                                    gross_profile, load_functional, marginal)


@dataclass(frozen=True)
class TemporalView:
    nodes: tuple
    predecessors: dict
    successors: dict
    ancestors: dict
    positive_only: bool

    def comparable(self, u, v):
        return u in self.ancestors[v] or v in self.ancestors[u]


def temporal_view(ctx, order, positive_only=False):
    n, m = len(ctx.powers), len(ctx.powers[0])
    if sorted(order) != list(range(n)):
        raise ValueError('Not a complete job permutation')
    topological = [(j, a) for j in order for a in range(m)]
    parents = {op: [] for op in topological}
    children = {op: [] for op in topological}
    for pos, j in enumerate(order):
        for a in range(m):
            op = (j, a)
            if pos:
                parents[op].append((order[pos-1], a))
            if a:
                parents[op].append((j, a-1))
            for before in parents[op]:
                children[before].append(op)
    ancestors, descendants = {}, {}
    for op in topological:
        seen = set(parents[op])
        for before in parents[op]:
            seen.update(ancestors[before])
        ancestors[op] = frozenset(seen)
    for op in reversed(topological):
        seen = set(children[op])
        for after in children[op]:
            seen.update(descendants[after])
        descendants[op] = frozenset(seen)
    nodes = tuple(op for op in topological if not positive_only or ctx.durations[op[0]][op[1]] > 0)
    if positive_only:
        retained = set(nodes)
        pred = {op: tuple(sorted(ancestors[op] & retained)) for op in nodes}
        succ = {op: tuple(sorted(descendants[op] & retained)) for op in nodes}
    else:
        pred = {op: tuple(parents[op]) for op in nodes}
        succ = {op: tuple(children[op]) for op in nodes}
    return TemporalView(nodes, pred, succ, ancestors, positive_only)


def lift_zero_operations(ctx, order, positive_starts):
    """Earliest zero starts;None iff the fixed positive starts have no lift."""
    n, m, h = len(ctx.powers), len(ctx.powers[0]), ctx.horizon
    starts = [[0]*m for _ in range(n)]
    for pos, j in enumerate(order):
        for a in range(m):
            lower = 0
            if pos:
                prev = order[pos-1]
                lower = starts[prev][a]+ctx.durations[prev][a]
            if a:
                lower = max(lower, starts[j][a-1]+ctx.durations[j][a-1])
            d = ctx.durations[j][a]
            start = positive_starts[j][a] if d else lower
            if type(start) is not int or start < lower or start+d > h:
                return None
            starts[j][a] = start
    return starts


def single_domain(ctx, view, starts, op):
    d = ctx.durations[op[0]][op[1]]
    lower = max([0]+[starts[j][a]+ctx.durations[j][a] for j, a in view.predecessors[op]])
    upper = min([ctx.horizon-d]+[starts[j][a]-d for j, a in view.successors[op]])
    return range(lower, upper+1)


def pair_domains(ctx, view, starts, u, v):
    if u == v or u not in view.nodes or v not in view.nodes:
        raise ValueError('Two different retained operations required')
    ops = (u, v)
    lower, upper, edges = [], [], set()
    for i, op in enumerate(ops):
        other = ops[1-i]
        d = ctx.durations[op[0]][op[1]]
        lo, hi = 0, ctx.horizon-d
        for j, a in view.predecessors[op]:
            if (j, a) == other:
                edges.add((1-i, i, ctx.durations[j][a]))
            else:
                lo = max(lo, starts[j][a]+ctx.durations[j][a])
        for j, a in view.successors[op]:
            if (j, a) == other:
                edges.add((i, 1-i, d))
            else:
                hi = min(hi, starts[j][a]-d)
        lower.append(lo)
        upper.append(hi)
    assert len(edges) <= 1
    for before, after, d in edges:
        lower[after] = max(lower[after], lower[before]+d)
        upper[before] = min(upper[before], upper[after]-d)
    domains = tuple(range(lo, hi+1) for lo, hi in zip(lower, upper))
    assert all(starts[j][a] in domain for (j, a), domain in zip(ops, domains))
    return domains, tuple(sorted(edges))


def feasible_pair_starts(edges, su, sv):
    values = (su, sv)
    return all(values[after] >= values[before]+duration for before, after, duration in edges)


def minimum_feasible_additive(cu, cv, edges):
    """Linear suffix-min scan AFTER chronological marginal tables are built."""
    if not edges:
        cost_u, su = min((cost, start) for start, cost in cu)
        cost_v, sv = min((cost, start) for start, cost in cv)
        return cost_u+cost_v, (su, sv)
    before, after, duration = edges[0]
    rows = (cu, cv)
    pred, succ = rows[before], rows[after]
    suffix = [None]*len(succ)
    best = None
    for k in range(len(succ)-1, -1, -1):
        start, cost = succ[k]
        best = min(best, (cost, start)) if best is not None else (cost, start)
        suffix[k] = best
    optimum = None
    for begin, cost in pred:
        k = max(0, begin+duration-succ[0][0])
        if k >= len(succ):
            continue
        cost_after, start_after = suffix[k]
        candidate = (cost+cost_after, begin, start_after)
        if optimum is None or candidate < optimum:
            optimum = candidate
    assert optimum is not None
    cost, start_before, start_after = optimum
    starts = [None, None]
    starts[before], starts[after] = start_before, start_after
    return cost, tuple(starts)


def prepare_general_pair(ctx, view, starts, u, v, gross=None):
    domains, edges = pair_domains(ctx, view, starts, u, v)
    if gross is None:
        gross = gross_profile(ctx, starts)
    current = load_functional(ctx, gross)
    background = list(gross)
    for j, a in (u, v):
        for r, draw in enumerate(ctx.powers[j][a]):
            background[starts[j][a]+r] -= draw
    assert min(background) >= 0
    base = load_functional(ctx, background)
    cu = [(s, marginal(ctx, background, u, s)) for s in domains[0]]
    cv = [(s, marginal(ctx, background, v, s)) for s in domains[1]]
    additive, argmin = minimum_feasible_additive(cu, cv, edges)
    has_zero_draw = any(not any(ctx.powers[j][a]) for j, a in (u, v))
    comparable = view.comparable(u, v)
    separable = comparable or has_zero_draw
    # Incomparable positive operations have no internal precedence edge.
    assert separable or not edges
    if not edges:
        feasible_count = len(domains[0])*len(domains[1])
    else:
        before, after, d = edges[0]
        feasible_count = sum(max(0, domains[after].stop-max(domains[after].start, s+d))
                             for s in domains[before])
    return {'u': u, 'v': v, 'domains': domains, 'internal_edges': edges,
            'background': background, 'base': base, 'incumbent': current,
            'starts_u': sorted((cost, s) for s, cost in cu),
            'starts_v': sorted((cost, s) for s, cost in cv),
            'lower_bound': base+additive, 'relaxation_argmin': argmin,
            'gain_upper_bound': current-base-additive,
            'univariate_marginals_computed': len(cu)+len(cv),
            'energy_separable': separable, 'precedence_comparable': comparable,
            'has_zero_draw': has_zero_draw, 'feasible_pair_assignments': feasible_count,
            'rectangle_assignments': len(domains[0])*len(domains[1])}


def solve_general_pair(ctx, order, view, starts, prepared):
    u, v = prepared['u'], prepared['v']
    if prepared['energy_separable']:
        best = prepared['lower_bound']
        assert best <= prepared['incumbent']
        su, sv = prepared['relaxation_argmin']
        assert feasible_pair_starts(prepared['internal_edges'], su, sv)
        assert addition_interaction(ctx, prepared['background'], u, su, v, sv) == 0
        result = [list(row) for row in starts]
        if best < prepared['incumbent']:
            result[u[0]][u[1]], result[v[0]][v[1]] = su, sv
        evaluations = 1
        mode = 'exact_feasible_additive_suffix_min'
    else:
        old = exact_pair_repair(ctx, starts, prepared)
        best, result = old['score_numerator'], old['starts']
        evaluations = old['pair_assignments_evaluated']
        mode = 'exact_shared_supply_cartesian_with_cost_pruning'
    if view.positive_only:
        result = lift_zero_operations(ctx, order, result)
        assert result is not None
    assert load_functional(ctx, gross_profile(ctx, result)) == best
    return {'starts': result, 'score_numerator': best,
            'score_fraction': str(F(best, ctx.denominator)),
            'gain_numerator': prepared['incumbent']-best, 'solution_mode': mode,
            'explicit_pair_interaction_evaluations': evaluations,
            'feasible_pair_assignments_covered': prepared['feasible_pair_assignments'],
            'rectangle_assignments': prepared['rectangle_assignments'],
            'univariate_marginals_computed': prepared['univariate_marginals_computed']}


def descend_projected_coordinates(ctx, order, initial_starts, maximum_scans=512):
    view = temporal_view(ctx, order, positive_only=True)
    starts = lift_zero_operations(ctx, order, initial_starts)
    assert starts is not None
    changed_zero_starts = starts != [list(row) for row in initial_starts]
    trace, positions = [], 0
    for scan in range(maximum_scans):
        gross = gross_profile(ctx, starts)
        current = load_functional(ctx, gross)
        best = None
        for op in view.nodes:
            j, a = op
            background = list(gross)
            for r, p in enumerate(ctx.powers[j][a]):
                background[starts[j][a]+r] -= p
            base = current-marginal(ctx, background, op, starts[j][a])
            for s in single_domain(ctx, view, starts, op):
                cost = base+marginal(ctx, background, op, s)
                positions += 1
                if cost < current and (best is None or (cost, j, a, s) < best):
                    best = (cost, j, a, s)
        if best is None:
            return {'starts': starts, 'score_fraction': str(F(current, ctx.denominator)),
                    'projected_coordinate_local_optimum': True, 'trace': trace,
                    'positions_scored': positions, 'scans': scan+1,
                    'initial_zero_lift_changed_starts': changed_zero_starts,
                    'zero_elimination_is_equivalent_representation_not_innovation': True}
        cost, j, a, s = best
        before = starts[j][a]
        starts[j][a] = s
        starts = lift_zero_operations(ctx, order, starts)
        assert starts is not None
        assert load_functional(ctx, gross_profile(ctx, starts)) == cost
        trace.append({'op': [j, a], 'from': before, 'to': s,
                      'score_fraction': str(F(cost, ctx.denominator))})
    return {'starts': starts, 'score_fraction': str(F(load_functional(ctx, gross_profile(ctx, starts)), ctx.denominator)),
            'projected_coordinate_local_optimum': False, 'trace': trace,
            'positions_scored': positions, 'scans': maximum_scans,
            'initial_zero_lift_changed_starts': changed_zero_starts}
