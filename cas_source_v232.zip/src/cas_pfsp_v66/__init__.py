"""Paid complete-search adapters for the qualified resumable timing kernel."""
