"""Bounded per-run frontier/certificate reuse in a fresh first-improvement scan.

All reused work was paid in this run. Cache entries have exact domain keys;
certificates refer to earlier completed engine lookups. A capped engine is
not resumed or silently reset:only a strict new upper bound permits a logged
new engine. Eviction explicitly closes generator frames to release cycles.
"""
from collections import OrderedDict
import copy
from fractions import Fraction as F
import hashlib
import itertools
import json
import time

from cas_pfsp_v59.joint_descent_r2 import refine as fallback_refine
from cas_pfsp_v64.registry import physical_numerator
from cas_pfsp_v65.resumable_projected_dp import ResumableProjectedDP, domain_signature


class FrontierPool:
    def __init__(self, ctx, started, frontier_capacity=1, certificate_capacity=32,
                 tombstone_capacity=32, state_limit=2_000_000, clock=time.perf_counter,
                 maximum_checkpoints=None):
        for value in (frontier_capacity, certificate_capacity, tombstone_capacity, state_limit):
            if type(value) is not int or value < 1:
                raise ValueError('Positive integer cache capacities/state limit required')
        if maximum_checkpoints is not None and (type(maximum_checkpoints) is not int or maximum_checkpoints < 1):
            raise ValueError('Positive optional diagnostic checkpoint quota')
        self.ctx, self.started, self.clock = ctx, started, clock
        self.frontier_capacity, self.certificate_capacity = frontier_capacity, certificate_capacity
        self.tombstone_capacity, self.state_limit = tombstone_capacity, state_limit
        self.maximum_checkpoints = maximum_checkpoints
        self.live, self.certificates, self.tombstones = OrderedDict(), OrderedDict(), OrderedDict()
        self.lookups, self.maintenance = [], []
        self.next_engine = self.closed_generators = self.max_live = 0
        self.closed = False

    def _time(self):
        return self.clock() - self.started

    def _drop_live(self, key, reason, lookup):
        entry = self.live.pop(key)
        # A suspended generator owns a frame referencing its engine. Closing
        # it breaks that cycle now,rather than waiting for a future GC pass.
        entry['engine']._iterator.close()
        self.closed_generators += 1
        self.maintenance.append({'action': reason, 'lookup': lookup, 'key': key,
            'engine_id': entry['engine_id'], 'available_seconds': self._time()})

    def _put_small(self, mapping, key, value, capacity, kind, lookup):
        mapping[key] = value
        mapping.move_to_end(key)
        while len(mapping) > capacity:
            victim, _ = mapping.popitem(last=False)
            self.maintenance.append({'action': 'evict_' + kind, 'lookup': lookup,
                                     'key': victim, 'available_seconds': self._time()})

    def response(self, order, initial, machines, fixed, deadline, on_candidate):
        if self.closed:
            raise RuntimeError('A closed pool cannot be reused')
        began = self.clock()
        signature = domain_signature(self.ctx, order, initial, machines, fixed)
        key = hashlib.sha256(json.dumps(signature, separators=(',', ':')).encode()).hexdigest()
        initial_value = physical_numerator(self.ctx, order, initial)
        index = len(self.lookups)
        mode = 'background' if fixed else 'residual'
        row = {'id': index, 'key': key, 'permutation': list(order), 'initial': copy.deepcopy(initial),
            'initial_score_numerator': initial_value, 'machines': list(machines),
            'fixed_positive_machines': list(fixed), 'bound_mode': mode,
            'started_seconds': began - self.started, 'deadline_seconds': deadline - self.started,
            'stored_certificate': False, 'stored_tombstone': False,
            'strict_upper_offered': False, 'kernel_before': None, 'kernel_result': None}
        self.lookups.append(row)
        for mapping in (self.live, self.certificates, self.tombstones):
            if key in mapping and mapping[key]['signature'] != signature:
                raise ValueError('Fingerprint collision cannot substitute for exact domain equality')
        best, value, complete = copy.deepcopy(initial), initial_value, False
        if key in self.certificates:
            proof = self.certificates[key]
            self.certificates.move_to_end(key)
            row.update(source='completed_certificate', engine_id=proof['engine_id'],
                       source_lookup=proof['lookup'], source_available_seconds=proof['available_seconds'])
            best, value, complete = copy.deepcopy(proof['starts']), proof['score_numerator'], True
            if value > initial_value:
                raise ValueError('Cached optimum is worse than a feasible same-domain incumbent')
            on_candidate(best, value, 'completed_certificate', index)
        elif key in self.tombstones and initial_value >= self.tombstones[key]['score_numerator']:
            old = self.tombstones[key]
            self.tombstones.move_to_end(key)
            row.update(source='state_limit_tombstone', engine_id=old['engine_id'],
                       source_lookup=old['lookup'], source_available_seconds=old['available_seconds'])
            best, value = copy.deepcopy(old['starts']), old['score_numerator']
            on_candidate(best, value, 'state_limit_tombstone', index)
        else:
            if key in self.live:
                entry = self.live[key]
                self.live.move_to_end(key)
                row.update(source='resume_engine', source_lookup=entry['last_lookup'])
            else:
                row.update(source='fresh_engine', source_lookup=None)
                if key in self.tombstones:
                    old = self.tombstones.pop(key)
                    assert initial_value < old['score_numerator']
                    row.update(source='strict_upper_restart_after_cap', source_lookup=old['lookup'])
                while len(self.live) >= self.frontier_capacity:
                    self._drop_live(next(iter(self.live)), 'evict_frontier', index)
                engine = ResumableProjectedDP(self.ctx, order, initial, machines, fixed,
                    bound_mode=mode, state_limit=self.state_limit, clock=self.clock)
                assert engine.fingerprint == key
                entry = {'engine': engine, 'engine_id': self.next_engine, 'last_lookup': None,
                         'signature': signature}
                self.next_engine += 1
                self.live[key] = entry
                self.max_live = max(self.max_live, len(self.live))
            engine = entry['engine']
            row['engine_id'] = entry['engine_id']
            row['engine_initial'] = copy.deepcopy(engine.initial)
            row['kernel_before'] = engine.snapshot()
            row['strict_upper_offered'] = engine.offer_incumbent(self.ctx, order, initial)
            # A previous slice may have finished reconstructing a candidate
            # too late to publish. It is offered now with this actual time.
            on_candidate(copy.deepcopy(engine.best), engine.upper_value, 'stored_engine', index)
            result = engine.advance(deadline=deadline, maximum_checkpoints=self.maximum_checkpoints,
                on_improvement=lambda s, v: on_candidate(s, v, 'engine_callback', index))
            row['kernel_result'] = result
            row['engine_terminal_reason'] = engine.terminal_reason
            best, value, complete = copy.deepcopy(result['starts']), result['score_numerator'], result['complete']
            on_candidate(best, value, 'post_advance', index)
            entry['last_lookup'] = index
            if result['complete']:
                card = {'engine_id': entry['engine_id'], 'lookup': index, 'signature': signature,
                        'starts': copy.deepcopy(best), 'score_numerator': value}
                self._drop_live(key, 'completed_engine_released', index)
                card['available_seconds'] = self._time()
                self._put_small(self.certificates, key, card, self.certificate_capacity, 'certificate', index)
                row['stored_certificate'] = True
                row['cache_available_seconds'] = card['available_seconds']
            elif engine.terminal_reason == 'state_limit':
                card = {'engine_id': entry['engine_id'], 'lookup': index, 'signature': signature,
                        'starts': copy.deepcopy(best), 'score_numerator': value}
                self._drop_live(key, 'capped_engine_released', index)
                card['available_seconds'] = self._time()
                self._put_small(self.tombstones, key, card, self.tombstone_capacity, 'tombstone', index)
                row['stored_tombstone'] = True
                row['cache_available_seconds'] = card['available_seconds']
        assert physical_numerator(self.ctx, order, best) == value <= initial_value
        row.update(starts=copy.deepcopy(best), score_numerator=value,
                   score_fraction=str(F(value, self.ctx.denominator)),
                   live_entries=len(self.live), certificate_entries=len(self.certificates),
                   tombstone_entries=len(self.tombstones), returned_seconds=self._time())
        row['complete'] = bool(complete and self.clock() < deadline)
        return row

    def close(self):
        if not self.closed:
            while self.live:
                self._drop_live(next(iter(self.live)), 'pool_close_frontier', len(self.lookups))
            self.certificates.clear()
            self.tombstones.clear()
            self.closed = True

    def receipt(self):
        return {'frontier_capacity': self.frontier_capacity, 'certificate_capacity': self.certificate_capacity,
            'tombstone_capacity': self.tombstone_capacity, 'state_limit_per_engine_lifetime': self.state_limit,
            'diagnostic_maximum_checkpoints_per_lookup': self.maximum_checkpoints,
            'engine_lifetimes': self.next_engine, 'max_live_entries': self.max_live,
            'closed_generator_frames': self.closed_generators, 'closed': self.closed,
            'lookups': self.lookups, 'maintenance': self.maintenance,
            'current_run_only_no_external_cached_initializer': True}


class ResumableJointRefiner:
    def __init__(self, ctx, started, clock=time.perf_counter, **pool_options):
        self.ctx, self.clock = ctx, clock
        self.pool = FrontierPool(ctx, started, clock=clock, **pool_options)

    def __call__(self, ctx, order, initial, deadline, started, events,
                 maximum_passes=32, state_limit=2_000_000):
        if ctx != self.ctx or started != self.pool.started:
            raise ValueError('A refiner belongs to one fixed instance and paid run')
        if state_limit != self.pool.state_limit:
            raise ValueError('Cannot reset or alter the engine lifetime state limit')
        m = len(ctx.powers[0])
        if m == 1:
            result = fallback_refine(ctx, order, initial, deadline, started, events, maximum_passes, state_limit)
            result['resumable_M1_fallback'] = True
            return result
        current = copy.deepcopy(initial)
        score = physical_numerator(ctx, order, current)
        calls, accepted, local = [], 0, False
        sequence = []
        for a in range(m):
            dummy = next(b for b in range(m) if b != a)
            sequence.append(('projected_single', tuple(sorted((a, dummy))), (dummy,)))
        sequence.extend(('projected_pair', pair, ()) for pair in itertools.combinations(range(m), 2))
        stop = 'pass_cap_without_locality'
        for turn in range(maximum_passes):
            changed = False
            for kind, pair, fixed in sequence:
                if self.clock() >= deadline:
                    stop = 'deadline_before_neighborhood'
                    break
                before, base, tick = copy.deepcopy(current), score, self.clock()
                call_index = len(calls)

                def retain(candidate, value, proposal_stage, lookup):
                    nonlocal current, score, accepted
                    if value >= score or self.clock() >= deadline:
                        return
                    assert physical_numerator(ctx, order, candidate) == value
                    available = self.clock()
                    if available >= deadline:
                        return
                    current, score = copy.deepcopy(candidate), value
                    accepted += 1
                    events.append({'elapsed_seconds': available - started,
                        'source': 'resumable_projected_joint_refinement', 'permutation': list(order),
                        'starts': copy.deepcopy(current), 'score_fraction': str(F(score, ctx.denominator)),
                        'move': {'kind': kind, 'call_index': call_index, 'pool_lookup': lookup,
                                 'proposal_stage': proposal_stage}})

                response = self.pool.response(order, before, pair, fixed, deadline, retain)
                complete = response['complete']
                calls.append({'pass': turn, 'kind': kind, 'machines': list(pair),
                    'fixed_positive_machines': list(fixed), 'initial': before,
                    'complete': complete, 'accepted': score < base,
                    'seconds': self.clock() - tick, 'result': response})
                if not complete:
                    stop = 'incomplete_neighborhood'
                    break
                if score < base:
                    changed = True
                    break
                if self.clock() >= deadline:
                    stop = 'deadline_after_neighborhood'
                    break
            else:
                local = self.clock() < deadline
                stop = 'completed_projected_machine_single_pair_local' if local else 'deadline_after_scan'
                break
            if not changed:
                break
        assert physical_numerator(ctx, order, current) == score
        return {'starts': current, 'score_fraction': str(F(score, ctx.denominator)),
            'local': local, 'stop': stop, 'calls': calls, 'accepted_moves': accepted,
            'maximum_passes': maximum_passes, 'arm': 'ma_resume_joint',
            'state_limit_per_product_call': state_limit,
            'pair_selection': 'singles_by_machine_then_lexicographic_pairs_first_improvement',
            'all_zero_nodes_free_for_product_calls': True, 'no_job_chain_locality_claim': True,
            'cache_is_bounded_and_current_run_only': True}
