"""Exact policy state, without CP or a measured complete-search clock.

Inspired by Kasapidis et al. EJOR2025, not their original implementation.
CAS changes include timing-sensitive elite/tabu features, whole-job removal,
and explicitly specified bounded parameter steps. No new mechanism priority
or complete paid modern-baseline qualification is claimed here.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations
import random

OPERATORS=('time_window','overlap_block','machine_removal','whole_job','order_frequency')
XI=(F(1,100),F(1,40),F(1,20),F(3,40),F(1,10))


def ceil_fraction(value):return (value.numerator+value.denominator-1)//value.denominator


def acyclic_pairs(n,weighted,checkpoint=lambda phase:None):
    """Descending frequency, then pair IDs; reject edges closing a directed cycle."""
    if type(n) is not int or n<1:raise ValueError('Positive integer job count required')
    seen=set();items=[]
    for i,j,weight in weighted:
        if type(i) is not int or type(j) is not int or not 0<=i<n or not 0<=j<n or i==j:
            raise ValueError('Distinct valid job pair required')
        if (i,j) in seen:raise ValueError('Duplicate weighted pair')
        value=F(weight)
        if not 0<=value<=1:raise ValueError('Frequency must be in[0,1]')
        seen.add((i,j));items.append((i,j,value))
    graph={i:set() for i in range(n)};kept=[];removed=[]
    for i,j,weight in sorted(items,key=lambda x:(-x[2],x[0],x[1])):
        checkpoint('policy_frequency_cycle_edge');stack=[j];reached=set()
        while stack:
            checkpoint('policy_frequency_cycle_visit');node=stack.pop()
            if node in reached:continue
            reached.add(node);stack.extend(graph[node])
        row={'before':i,'after':j,'frequency_fraction':str(weight)}
        if i in reached:removed.append(row)
        else:graph[i].add(j);kept.append(row)
    return kept,removed


@dataclass(frozen=True)
class Solution:
    attempt_id:int
    order:tuple
    starts:tuple
    score:F
    signature:tuple


class AdaptivePolicy:
    def __init__(self,durations,horizon,seed=0,elite_capacity=200,trajectory_capacity=25,
                 stagnation_limit=50,adaptation_window=20,rho=F(1,4),delta=F(1,10),
                 elite_fraction=F(1,2),theta=F(1,2),theta_step=F(1,10),
                 theta_min=F(1,10),theta_max=F(2),checkpoint=lambda phase:None):
        self.d=tuple(tuple(row) for row in durations)
        if not self.d or not self.d[0] or any(len(row)!=len(self.d[0]) or
                any(type(x) is not int or x<0 for x in row) for row in self.d):
            raise ValueError('Rectangular nonnegative integer durations required')
        self.n,self.m=len(self.d),len(self.d[0])
        if type(horizon) is not int or horizon<1 or type(seed) is not int:raise ValueError('Integer horizon/seed required')
        for value in [elite_capacity,trajectory_capacity,stagnation_limit,adaptation_window]:
            if type(value) is not int or value<1:raise ValueError('Positive integer capacity/window required')
        rho,delta,elite_fraction,theta,theta_step,theta_min,theta_max=map(F,
            (rho,delta,elite_fraction,theta,theta_step,theta_min,theta_max))
        if not 0<rho<=1 or not 0<delta<=1 or not 0<elite_fraction<=1:raise ValueError('Fraction parameters outside(0,1]')
        if not 0<theta_min<=theta<=theta_max or theta_step<=0:raise ValueError('Invalid bounded slice parameters')
        self.h=horizon;self.seed=seed;self.rng=random.Random(seed);self.checkpoint=checkpoint
        self.elite_capacity=elite_capacity;self.trajectory_capacity=trajectory_capacity
        self.stagnation_limit=stagnation_limit;self.window=adaptation_window
        self.rho=max(F(1,self.n),rho);self.delta=delta;self.elite_fraction=elite_fraction
        self.theta,self.theta_step,self.theta_min,self.theta_max=theta,theta_step,theta_min,theta_max
        self.positive=tuple((j,a) for j in range(self.n) for a in range(self.m) if self.d[j][a])
        self.elite=();self.trajectory=();self.representatives={};self.offered={}
        self.best=None;self.current=None;self.weights={op:100 for op in OPERATORS}
        self.iterations=0;self.stagnation=0;self.window_attempts=0;self.window_optima=0
        self.pending=None;self.pending_best=None;self.pending_inserted=False

    def solution(self,point,attempt_id):
        if type(point.get('eligible')) is not bool:raise ValueError('Explicit registry eligibility Boolean required')
        if not point['eligible']:return None
        if type(attempt_id) is not int or attempt_id<0:raise ValueError('Nonnegative integer attempt ID required')
        order=tuple(point['permutation']);starts=tuple(tuple(row) for row in point['starts'])
        if len(order)!=self.n or any(type(j) is not int for j in order) or sorted(order)!=list(range(self.n)):
            raise ValueError('Complete integer permutation required')
        if len(starts)!=self.n or any(len(row)!=self.m or any(type(s) is not int for s in row) for row in starts):
            raise ValueError('Integer start matrix required')
        for j in range(self.n):
            for a in range(self.m):
                s=starts[j][a];end=s+self.d[j][a]
                if not 0<=s<=end<=self.h or a and s<starts[j][a-1]+self.d[j][a-1]:raise ValueError('Invalid within-job timing')
        for i,j in zip(order,order[1:]):
            if any(starts[i][a]+self.d[i][a]>starts[j][a] for a in range(self.m)):raise ValueError('Invalid common-machine order')
        if not isinstance(point['score_fraction'],str):raise ValueError('Exact score string required')
        score=F(point['score_fraction'])
        if score<0:raise ValueError('Nonnegative carbon score required')
        signature=order,tuple(starts[j][a] for j,a in self.positive)
        return Solution(attempt_id,order,starts,score,signature)

    @staticmethod
    def distance(a,b):
        return sum(x!=y for x,y in zip(a.signature[0],b.signature[0]))+sum(x!=y for x,y in zip(a.signature[1],b.signature[1]))

    def offer(self,point,attempt_id):
        item=self.solution(point,attempt_id)
        if item is None:return {'inserted':False,'reason':'ineligible_registry_point','attempt_id':attempt_id}
        if attempt_id in self.offered and self.offered[attempt_id]!=item:raise ValueError('Attempt ID reused for different point')
        representative=self.representatives.get(item.signature)
        if representative is not None and representative.score!=item.score:
            raise ValueError('Same positive-work signature has inconsistent exact score')
        strict=self.best is None or item.score<self.best.score
        new_best=item if strict else self.best;elite=list(self.elite);inserted=False;evicted=None
        duplicate_elite=any(s.signature==item.signature for s in self.elite)
        reason='duplicate_positive_signature' if duplicate_elite else 'not_selected_for_elite'
        if not duplicate_elite:
            if len(elite)<self.elite_capacity:
                elite.append(item);inserted=True;reason='elite_has_capacity'
            elif strict:
                worst=max(elite,key=lambda s:(s.score,s.signature,s.attempt_id))
                elite.remove(worst);elite.append(item);inserted=True;evicted=worst.attempt_id;reason='strict_global_improvement'
            elif self.elite_capacity==1:reason='preserve_single_best_elite'
            else:
                averages={s.attempt_id:F(sum(self.distance(s,t) for t in elite),len(elite)) for s in elite}
                candidate_average=F(sum(self.distance(item,t) for t in elite),len(elite))
                if candidate_average<min(averages.values()):reason='insufficient_timing_order_diversity'
                else:
                    best_score=min(s.score for s in elite);worst_score=max(s.score for s in elite)
                    replace=[s for s in elite if best_score<item.score<worst_score and item.score<=s.score and candidate_average>=averages[s.attempt_id]]
                    if not replace:replace=[s for s in elite if s.signature!=self.best.signature]
                    worst=min(replace,key=lambda s:(-s.score,averages[s.attempt_id],-s.attempt_id,s.signature))
                    elite.remove(worst);elite.append(item);inserted=True;evicted=worst.attempt_id;reason='quality_diversity_replacement'
        self.checkpoint('policy_offer_before_commit')
        self.offered[attempt_id]=item
        if representative is None:self.representatives[item.signature]=item
        self.best=new_best;self.elite=tuple(sorted(elite,key=lambda s:(s.score,s.signature,s.attempt_id)))
        if self.current is None:self.current=self.representatives[item.signature]
        if self.pending is not None and inserted:self.pending_inserted=True
        assert self.best is not None and any(s.signature==self.best.signature for s in self.elite)
        return {'attempt_id':attempt_id,'representative_attempt_id':self.representatives[item.signature].attempt_id,
                'inserted':inserted,'reason':reason,'evicted_attempt_id':evicted}

    def tabu_features(self):
        return [{'attempt_id':s.attempt_id,'permutation':list(s.order),
                 'positive_starts':[[j,a,s.starts[j][a]] for j,a in self.positive]} for s in self.trajectory]

    def begin_iteration(self,force_operator=None):
        if self.current is None or self.pending is not None or self.stagnation>=self.stagnation_limit:
            raise ValueError('An initialized,unfinished-free,nonstagnated policy is required')
        if force_operator is not None and force_operator not in OPERATORS:raise ValueError('Unknown extraction operator')
        roulette=None
        if force_operator is None:
            roulette=self.rng.randrange(sum(self.weights.values()));remaining=roulette
            for op in OPERATORS:
                if remaining<self.weights[op]:break
                remaining-=self.weights[op]
        else:op=force_operator
        anchor=self.current;rho=self.rho;detail={}
        if op=='time_window':
            end=max((anchor.starts[j][a]+self.d[j][a] for j,a in self.positive),default=0)
            width=min(end,ceil_fraction(rho*end));start=self.rng.randrange(end-width+1) if end else 0
            free=[[j,a] for j,a in self.positive if anchor.starts[j][a]<=start+width and anchor.starts[j][a]+self.d[j][a]>=start]
            kind='operation';detail={'window_start':start,'window_end':start+width,'positive_makespan':end}
        elif op=='overlap_block':
            target=min(len(self.positive),ceil_fraction(rho*len(self.positive)));selected=[];queue=[];seeds=[]
            while len(selected)<target:
                self.checkpoint('policy_overlap_block')
                if not queue:
                    left=[x for x in self.positive if x not in selected];chosen=self.rng.choice(left)
                    selected.append(chosen);queue.append(chosen);seeds.append(list(chosen))
                j,a=queue.pop(0)
                for k,b in self.positive:
                    self.checkpoint('policy_overlap_pair')
                    if len(selected)>=target:break
                    if (k,b) not in selected and anchor.starts[k][b]<=anchor.starts[j][a]+self.d[j][a] and anchor.starts[k][b]+self.d[k][b]>=anchor.starts[j][a]:
                        selected.append((k,b));queue.append((k,b))
            free=[list(x) for x in sorted(selected)];kind='operation';detail={'target_positive_operations':target,'restart_seeds':seeds}
        elif op=='machine_removal':
            free=sorted(self.rng.sample(range(self.m),min(self.m,ceil_fraction(rho*self.m))));kind='machine'
        elif op=='whole_job':
            free=sorted(self.rng.sample(range(self.n),min(self.n,ceil_fraction(rho*self.n))));kind='job'
        else:
            chosen=list(self.elite[:max(1,ceil_fraction(self.elite_fraction*len(self.elite)))])
            xi=self.rng.choice(XI);weighted=[]
            positions=[{job:k for k,job in enumerate(s.order)} for s in chosen]
            for i in range(self.n):
                for j in range(self.n):
                    if i==j:continue
                    self.checkpoint('policy_order_frequency_pair')
                    frequency=F(sum(pos[i]<pos[j] for pos in positions),len(chosen))
                    if frequency>=1-xi:weighted.append((i,j,frequency))
            kept,removed=acyclic_pairs(self.n,weighted,self.checkpoint);kind='rank';free=None
            detail={'selected_elite_attempt_ids':[s.attempt_id for s in chosen],'xi_fraction':str(xi),
                    'rank_pairs':[[e['before'],e['after']] for e in kept],'kept_frequency_edges':kept,'cycle_edges_removed':removed}
        result={'operator':op,'forced_diagnostic_operator':force_operator is not None,'roulette_draw':roulette,
                'kind':kind,'free':free,'anchor_attempt_id':anchor.attempt_id,'anchor_permutation':list(anchor.order),
                'rho_fraction':str(rho),'theta_seconds_fraction':str(self.theta),
                'tabu_positive_features':self.tabu_features(),**detail}
        self.checkpoint('policy_begin_before_commit');self.pending=op;self.pending_best=self.best.score;self.pending_inserted=False
        return result

    def finish_iteration(self,current_attempt_id=None,proved_optimal=False):
        if self.pending is None or type(proved_optimal) is not bool:raise ValueError('Pending operator and Boolean proof outcome required')
        if current_attempt_id is not None and (type(current_attempt_id) is not int or current_attempt_id not in self.offered):
            raise ValueError('Current point must be an observed eligible attempt')
        current=self.current if current_attempt_id is None else self.representatives[self.offered[current_attempt_id].signature]
        improved=self.best.score<self.pending_best;trajectory=[] if improved else list(self.trajectory)
        trajectory=[s for s in trajectory if s.signature!=current.signature]+[current]
        trajectory=trajectory[-self.trajectory_capacity:]
        weights=dict(self.weights);weights[self.pending]=max(1,weights[self.pending]+(1 if self.pending_inserted else -1))
        theta=min(self.theta_max,max(self.theta_min,self.theta+(self.theta_step if proved_optimal else -self.theta_step)))
        attempts,optima=self.window_attempts+1,self.window_optima+int(proved_optimal);rho=self.rho
        if attempts==self.window:
            rho=min(F(1),max(F(1,self.n),rho+self.delta*F(2*optima-attempts,attempts)));attempts=optima=0
        self.checkpoint('policy_finish_before_commit')
        self.current=current;self.trajectory=tuple(trajectory);self.weights=weights;self.theta=theta;self.rho=rho
        self.window_attempts,self.window_optima=attempts,optima
        self.stagnation=0 if improved else self.stagnation+1;self.iterations+=1
        self.pending=None;self.pending_best=None;self.pending_inserted=False
        return {'strict_global_improvement_in_iteration':improved,'stagnation_stop':self.stagnation>=self.stagnation_limit}

    def snapshot(self):
        return {'elite_attempt_ids':[s.attempt_id for s in self.elite],
            'trajectory_attempt_ids':[s.attempt_id for s in self.trajectory],
            'best_attempt_id':None if self.best is None else self.best.attempt_id,
            'current_attempt_id':None if self.current is None else self.current.attempt_id,
            'weights':dict(self.weights),'rho_fraction':str(self.rho),'theta_seconds_fraction':str(self.theta),
            'iterations':self.iterations,'stagnation':self.stagnation,'window_attempts':self.window_attempts,
            'window_optima':self.window_optima,'pending':self.pending,'observed_eligible_attempts':len(self.offered)}
