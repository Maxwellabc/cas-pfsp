"""One paid fast-wait search followed by exact serial and paired row descent.

Development policy, not a universal dominance or original DP priority claim.
"""
from fractions import Fraction as F
from pathlib import Path
import itertools
import math
import random
import time
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v64.registry import PhysicalRegistry
from cas_pfsp_v194.search import RecordPrunedWaitSearch
from .runtime import Budget, Expired
from cas_pfsp_v172.two_chain import PreparedInput, ViableChainTiming
from .serial import serial_response


class SliceExpired(Exception):
    pass


def attempt_id(registry,point):
    return next(i for i in reversed(range(len(registry.attempts))) if registry.attempts[i] is point)


def ranking(ctx, anchor, poll):
    """Build once for one immutable anchor; exact shared-load removal scores."""
    rows = [a for a in range(len(anchor.row_power))
            if any(ctx.durations[j][a] for j in anchor.order)]
    result = []
    for size in range(1,min(2,len(rows))+1):
        for chosen in itertools.combinations(rows,size):
            poll('row_rank_group')
            value = 0
            for t in range(ctx.horizon):
                if t % 32 == 0:
                    poll('row_rank_period')
                removed = sum(anchor.row_power[a][t] for a in chosen)
                value += ctx.carbon[t]*(max(0,anchor.gross[t]-ctx.renewable[t])
                    - max(0,anchor.gross[t]-removed-ctx.renewable[t]))
            result.append((chosen,value))
    return sorted(result,key=lambda x:(len(x[0]),-x[1],x[0]))


def run_budgeted(loader, budget_seconds, seed=0, phase_fraction=.6,
                 repair_slice_seconds=.5, phase_max_evaluations=None,
                 max_repairs=None, clock=time.perf_counter):
    if type(budget_seconds) not in (int,float) or not math.isfinite(budget_seconds) or budget_seconds<=0:
        raise ValueError('Positive finite paid root budget required')
    if type(seed) is not int:
        raise ValueError('Typed private integer seed required')
    if not math.isfinite(phase_fraction) or not 0<phase_fraction<1:
        raise ValueError('Phase fraction strictly between zero and one required')
    if not math.isfinite(repair_slice_seconds) or repair_slice_seconds<=0:
        raise ValueError('Positive finite repair slice required')
    for quota in (phase_max_evaluations,max_repairs):
        if quota is not None and (type(quota) is not int or quota<1):
            raise ValueError('Positive typed diagnostic quota required')
    budget=Budget(float(budget_seconds),clock)
    cpu=time.process_time(); before=random.getstate()
    physical=prepared=registry=phase_out=None
    setup={};repairs=[];ranking_builds=[];attempted=set();stop=None
    saved=None; saved_id=None; ranked=None
    try:
        budget.poll('before_input')
        physical=loader();setup['input_loaded_seconds']=budget.now()-budget.started
        prepared=PreparedInput(physical,checkpoint=budget.poll);ctx=prepared.context
        setup['context_ready_seconds']=budget.now()-budget.started
        registry=PhysicalRegistry(ctx,budget.started,budget.deadline,clock=budget.now)
        phase_deadline=budget.started+phase_fraction*budget_seconds
        phase=RecordPrunedWaitSearch(ctx,budget.started,phase_deadline,seed,
            clock=budget.now,max_evaluations=phase_max_evaluations)
        phase.registry=registry
        phase_out=phase.run()
        phase_out.pop('registered_attempts');phase_best=phase_out.pop('best_registered')
        phase_out.update(physical_registry_attempt_range=[0,len(registry.attempts)],
            best_registered_attempt_id=None if phase_best is None else attempt_id(registry,phase_best),
            shared_root_physical_registry=True,returned_to_composition_seconds=budget.now()-budget.started)
        while True:
            budget.poll('before_row_repair')
            if registry.best is None:stop='no_paid_feasible_initializer';break
            if registry.best_value==0:stop='nonnegative_zero_attained';break
            if max_repairs is not None and len(repairs)>=max_repairs:stop='diagnostic_repair_quota';break
            start=budget.now();cutoff=min(budget.deadline,start+repair_slice_seconds)
            row=dict(id=len(repairs),anchor_attempt_id=attempt_id(registry,registry.best),
                started_seconds=start-budget.started,slice_deadline_seconds=cutoff-budget.started,
                selected_machine_rows=None,descriptor=None,neighborhood_proved_optimal=False,
                registered_attempt_ids=[],result=None,stop=None,ranking_cache_hit=False)
            repairs.append(row)
            def poll(phase):
                budget.poll(phase)
                if budget.now()>=cutoff:raise SliceExpired(phase)
            old_value=registry.best_value
            try:
                if row['anchor_attempt_id']!=saved_id:
                    saved=prepared.anchor(registry.best['permutation'],registry.best['starts'],checkpoint=poll)
                    ranked=ranking(ctx,saved,poll)
                    saved_id=row['anchor_attempt_id']
                    ranking_builds.append(dict(anchor_attempt_id=saved_id,
                        ready_seconds=budget.now()-budget.started,
                        groups=[dict(machine_rows=list(rs),removal_score_numerator=v) for rs,v in ranked]))
                else:row['ranking_cache_hit']=True
                chosen=descriptor=None
                for rs,value in ranked:
                    poll('row_descriptor')
                    exterior=tuple((j,a,saved.starts[j][a]) for j in saved.order
                        for a in range(len(ctx.powers[j])) if ctx.durations[j][a] and a not in rs)
                    candidate=saved.order,rs,exterior
                    if candidate not in attempted:
                        chosen,descriptor=rs,candidate;break
                if chosen is None:
                    row['stop']=stop='declared_row_groups_exhausted';break
                attempted.add(descriptor)
                row.update(selected_machine_rows=list(chosen),
                    descriptor=dict(order=list(saved.order),machine_rows=list(chosen),
                        fixed_positive_starts=[list(z) for z in exterior]))
                def register(point):
                    poll('before_root_registration')
                    record=registry.register(point['permutation'],point['starts'],point['score_fraction'],
                        dict(kind='serial_row_strict_improvement' if len(chosen)==1 else 'paired_row_strict_improvement',
                            repair=row['id']))
                    row['registered_attempt_ids'].append(len(registry.attempts)-1)
                    poll('after_root_registration')
                if len(chosen)==1:
                    response=serial_response(prepared,saved,chosen[0],poll)
                    row['result']={k:v for k,v in response.items() if k not in ('permutation','starts','certificate')}
                    if response['score_numerator']<registry.best_value:register(response)
                    row['stop']='serial_row_complete'
                else:
                    model=ViableChainTiming(prepared,saved.order,saved,chosen,checkpoint=poll)
                    response=model.run(on_improvement=register)
                    row['result']=response
                    row['stop']='paired_row_complete'
                ready=budget.now()
                row['proof_ready_seconds']=ready-budget.started
                row['neighborhood_proved_optimal']=ready<cutoff and ready<budget.deadline
                if not row['neighborhood_proved_optimal']:
                    row['stop']='late_row_proof'
            except SliceExpired as error:row['stop']='slice_at_'+str(error)
            except Expired as error:
                row['stop']='global_budget_at_'+str(error);raise
            finally:
                row.update(returned_seconds=budget.now()-budget.started,
                    improved_global_best=registry.best_value<old_value,
                    best_after_attempt_id=attempt_id(registry,registry.best))
    except Expired as error:stop='global_budget_at_'+str(error)
    assert random.getstate()==before
    elapsed=budget.now()-budget.started
    best=None if registry is None else registry.best
    return dict(status='OPTIMAL' if best is not None and registry.best_value==0 else 'FEASIBLE' if best else 'UNKNOWN',
        stop_reason=stop,seed=seed,budget_seconds=budget_seconds,phase_fraction=phase_fraction,
        repair_slice_seconds=repair_slice_seconds,setup=setup,phase_component=phase_out,
        repairs=repairs,ranking_builds=ranking_builds,
        registered_attempts=[] if registry is None else registry.attempts,best_registered=best,
        registration_seconds=0 if registry is None else registry.registration_seconds,
        algorithm_wall_seconds=elapsed,algorithm_cpu_seconds=time.process_time()-cpu,
        overshoot_seconds=max(0,elapsed-budget_seconds),checkpoint_counts=budget.polls,
        input_sha256=None if physical is None else physical.input_sha256,
        global_Python_rng_unchanged=True,donated_initializer_or_external_cache=False,
        all_initialization_selection_model_scoring_registration_logging_charged=True,
        module_loading_and_final_JSON_serialization_excluded_like_frozen_core_contract=True,
        hard_return_deadline_guaranteed=False,positive_global_optimum_claim=False,
        timing_backend='projected_serial_prefix_min_then_v172_two_row',algorithm_version='v197',
        new_metaheuristic_or_DP_priority_claim=False,public_stable_superiority_qualified=False)


def run_file(input_path,budget_seconds,seed=0,**options):
    path=Path(input_path).resolve()
    if 'neso_' in str(path).lower():raise ValueError('Reserved path before reading contents')
    return run_budgeted(lambda:load_instance(path),budget_seconds,seed,**options)
