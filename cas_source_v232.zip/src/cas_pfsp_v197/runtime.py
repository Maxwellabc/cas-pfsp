"""The inherited finite monotone paid-clock contract without a CP dependency."""
import math


class Expired(Exception):
    pass


class Budget:
    def __init__(self,seconds,clock):
        self.raw_clock=clock
        self.last=None
        self.started=self.now()
        self.deadline=self.started+seconds
        self.polls={}
        self.last_phase=None

    def now(self):
        value=float(self.raw_clock())
        if not math.isfinite(value) or self.last is not None and value<self.last:
            raise ValueError('Finite monotone clock required')
        self.last=value
        return value

    def poll(self,phase):
        self.last_phase=phase
        self.polls[phase]=self.polls.get(phase,0)+1
        if self.now()>=self.deadline:
            raise Expired(phase)
