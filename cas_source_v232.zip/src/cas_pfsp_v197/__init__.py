"""Projected exact serial rows inside a complete paid CAS search."""
