"""Exact one-row response, with all zero-duration nodes free.

The serial Bellman recurrence and prefix minima are established techniques.
The context, immutable anchor, and domain preparation are charged to the caller.
No float coefficient arithmetic or independent deduction of shared supply.
"""
from fractions import Fraction as F
from cas_pfsp_v172.two_chain import ChainTiming
from cas_pfsp_v49.timing_pairs import lift_zero_operations
from cas_pfsp_v64.registry import physical_numerator


def serial_response(prepared, anchor, machine, checkpoint=lambda phase: None,
                    capture_certificate=False):
    model = ChainTiming(prepared, anchor.order, anchor, [machine], checkpoint)
    ctx, horizon = model.ctx, model.h
    chain = model.chains[0]
    checkpoint('serial_residual_begin')
    residual = [max(0, r-b) for r, b in zip(ctx.renewable, model.background)]
    previous = None
    predecessors, certificates = [], []
    unary_cache = {}
    states = hits = computed = 0
    last_duration = 0
    for i, op in enumerate(chain):
        checkpoint('serial_operation_begin')
        j, a = op
        profile = ctx.powers[j][a]
        low, high = model.domains[op]
        prefix_values = [None] * (horizon+1)
        prefix_times = [None] * (horizon+1)
        if previous is not None:
            best = best_time = None
            for t, value in enumerate(previous):
                if t % 32 == 0:
                    checkpoint('serial_prefix_minimum')
                if value is not None and (best is None or value < best):
                    best, best_time = value, t
                prefix_values[t], prefix_times[t] = best, best_time
        row, parent = [None]*(horizon+1), [None]*(horizon+1)
        costs = []
        for t in range(low, high+1):
            if (t-low) % 16 == 0:
                checkpoint('serial_start_cost')
            predecessor = t-last_duration
            if previous is not None and (predecessor < 0 or prefix_values[predecessor] is None):
                continue
            key = profile, t
            if key in unary_cache:
                unary = unary_cache[key]
                hits += 1
            else:
                # Increment over the fixed background: c * max(p-residual,0).
                unary = sum(ctx.carbon[t+u]*max(0,p-residual[t+u])
                            for u,p in enumerate(profile))
                unary_cache[key] = unary
                computed += 1
            row[t] = unary + (prefix_values[predecessor] if previous is not None else 0)
            parent[t] = prefix_times[predecessor] if previous is not None else None
            states += 1
            if capture_certificate:
                costs.append([t, unary])
        assert any(v is not None for v in row), 'Paid feasible anchor must remain reachable'
        predecessors.append(parent)
        if capture_certificate:
            certificates.append(dict(operation=list(op), domain=[low,high], unary=costs,
                                     values=row, predecessors=parent))
        previous, last_duration = row, len(profile)
    if chain:
        increment, t = min((value,t) for t,value in enumerate(previous) if value is not None)
        starts = [list(row) for row in anchor.starts]
        for i in reversed(range(len(chain))):
            j,a = chain[i]
            starts[j][a] = t
            t = predecessors[i][t]
        starts = lift_zero_operations(ctx, model.order, starts)
        assert starts is not None
        value = model.background_tail[0] + increment
    else:
        starts = [list(row) for row in anchor.starts]
        increment, value = 0, anchor.value
    checkpoint('serial_before_physical_validation')
    assert physical_numerator(ctx, model.order, starts) == value <= anchor.value
    checkpoint('serial_complete')
    return dict(permutation=list(model.order), starts=starts, score_numerator=value,
                score_fraction=str(F(value,ctx.denominator)), machine_row=machine,
                anchor_score_numerator=anchor.value, background_numerator=model.background_tail[0],
                minimum_increment_numerator=increment, DP_states=states,
                exact_unary_values_computed=computed, same_background_unary_cache_hits=hits,
                domains=[dict(operation=list(op), lower=model.domains[op][0],upper=model.domains[op][1]) for op in chain],
                neighborhood_proved_optimal=True, all_zero_duration_nodes_free=True,
                certificate=certificates if capture_certificate else None,
                positive_global_optimum_claim=False)
