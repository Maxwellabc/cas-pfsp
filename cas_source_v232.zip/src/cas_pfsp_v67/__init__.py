"""Complementary timing neighborhoods and global small-model references."""
