"""Persistent first-improvement scan of chain and projected neighborhoods.

Completed prefix proofs survive only for an identical permutation and complete
start matrix. Every strict accepted change resets the scan. A bounded scan
cache can forget prefixes;all later recomputation is paid. Projected engines
retain the qualified v66 per-engine state cap and LRU semantics;there is no
permanent per-domain cap after eviction. Jobs remain nonpreemptive.
"""
from collections import OrderedDict
import copy
from fractions import Fraction as F
import hashlib
import itertools
import json
import time

from cas_pfsp_v57.chain_dp_certificate import best_response as chain_response
from cas_pfsp_v64.registry import physical_numerator
from cas_pfsp_v66.resumable_descent import FrontierPool


class ChainCertificateCache:
    def __init__(self, ctx, started, capacity=128, clock=time.perf_counter, solver=chain_response):
        if type(capacity) is not int or capacity < 1:
            raise ValueError('Positive chain certificate capacity')
        self.ctx, self.started, self.capacity, self.clock, self.solver = ctx, started, capacity, clock, solver
        self.cards = OrderedDict()
        self.lookups, self.evictions = [], []

    def response(self, order, initial, kind, index, deadline):
        tick = self.clock()
        n, m = len(self.ctx.powers), len(self.ctx.powers[0])
        members = [(j, index) for j in order] if kind == 'machine' else [(index, a) for a in range(m)]
        signature = (self.ctx.powers, self.ctx.renewable, self.ctx.carbon, self.ctx.denominator,
            self.ctx.horizon, tuple(order), kind, index,
            tuple((j, a, initial[j][a]) for j in range(n) for a in range(m) if (j, a) not in members))
        key = hashlib.sha256(json.dumps(signature, separators=(',', ':')).encode()).hexdigest()
        row = {'id': len(self.lookups), 'key': key, 'kind': kind, 'index': index,
            'permutation': list(order), 'initial': copy.deepcopy(initial),
            'initial_score_numerator': physical_numerator(self.ctx, order, initial),
            'started_seconds': tick - self.started, 'deadline_seconds': deadline - self.started,
            'kernel_result': None, 'stored_certificate': False}
        self.lookups.append(row)
        if key in self.cards:
            old = self.cards[key]
            assert signature == old['signature']
            self.cards.move_to_end(key)
            result = {'starts': copy.deepcopy(old['starts']), 'score_numerator': old['score_numerator']}
            row.update(source='completed_chain_certificate', source_lookup=old['lookup'],
                       source_available_seconds=old['available_seconds'])
            complete = True
        else:
            row.update(source='fresh_chain_DP', source_lookup=None)
            try:
                result = self.solver(self.ctx, order, initial, kind, index, deadline=deadline)
                assert result['complete']
                row['kernel_result'] = result
                card = {'signature': signature, 'lookup': row['id'], 'starts': copy.deepcopy(result['starts']),
                        'score_numerator': result['score_numerator'], 'available_seconds': self.clock() - self.started}
                self.cards[key] = card
                if len(self.cards) > self.capacity:
                    victim, _ = self.cards.popitem(last=False)
                    self.evictions.append({'lookup': row['id'], 'key': victim,
                                           'available_seconds': self.clock() - self.started})
                row.update(stored_certificate=True, cache_available_seconds=card['available_seconds'])
                complete = True
            except TimeoutError:
                result = {'starts': copy.deepcopy(initial), 'score_numerator': row['initial_score_numerator']}
                complete = False
        assert physical_numerator(self.ctx, order, result['starts']) == result['score_numerator'] <= row['initial_score_numerator']
        row.update(starts=copy.deepcopy(result['starts']), score_numerator=result['score_numerator'],
            score_fraction=str(F(result['score_numerator'], self.ctx.denominator)),
            certificate_entries=len(self.cards), returned_seconds=self.clock() - self.started)
        row['complete'] = bool(complete and self.clock() < deadline)
        return row

    def receipt(self):
        return {'capacity': self.capacity, 'lookups': self.lookups, 'evictions': self.evictions,
                'current_run_only': True}


class UnionRefiner:
    def __init__(self, ctx, started, scan_capacity=16, chain_capacity=128,
                 clock=time.perf_counter, chain_solver=chain_response, **projected_options):
        if type(scan_capacity) is not int or scan_capacity < 1:
            raise ValueError('Positive scan cache capacity')
        self.ctx, self.started, self.clock = ctx, started, clock
        self.scan_capacity, self.scans = scan_capacity, OrderedDict()
        self.chain_cache = ChainCertificateCache(ctx, started, chain_capacity, clock, chain_solver)
        self.projected_pool = FrontierPool(ctx, started, clock=clock, **projected_options)
        self.steps, self.invocations, self.scan_actions = [], [], []
        self.next_scan_id = 0
        m, n = len(ctx.powers[0]), len(ctx.powers)
        self.sequence = [('chain', 'machine', a) for a in range(m)]
        if m > 1:
            self.sequence += [('chain', 'job', j) for j in range(n)]
            for a in range(m):
                dummy = next(b for b in range(m) if b != a)
                self.sequence.append(('projected', 'single', tuple(sorted((a, dummy))), (dummy,)))
            self.sequence += [('projected', 'pair', pair, ()) for pair in itertools.combinations(range(m), 2)]
        self.closed = False

    def _state(self, entry):
        return {k: copy.deepcopy(entry[k]) for k in ('id', 'epoch', 'cursor', 'starts', 'proof_steps', 'local')}

    def __call__(self, ctx, order, initial, deadline, started, events, maximum_passes=32, state_limit=2_000_000):
        if self.closed or ctx != self.ctx or started != self.started:
            raise ValueError('A union refiner belongs to one live instance/run')
        if state_limit != self.projected_pool.state_limit:
            raise ValueError('Cannot silently change an engine lifetime cap')
        invocation = len(self.invocations)
        key = tuple(order)
        sequence = [('chain', 'job', order[d[2]]) if d[0] == 'chain' and d[1] == 'job' else d
                    for d in self.sequence]
        current, score = copy.deepcopy(initial), physical_numerator(ctx, order, initial)
        if key not in self.scans:
            while len(self.scans) >= self.scan_capacity:
                victim, old = self.scans.popitem(last=False)
                self.scan_actions.append({'action': 'evict_scan', 'invocation': invocation,
                    'permutation': list(victim), 'scan_id': old['id'], 'available_seconds': self.clock() - started})
            entry = {'id': self.next_scan_id, 'epoch': 0, 'cursor': 0, 'starts': copy.deepcopy(initial),
                     'proof_steps': [], 'local': False}
            self.next_scan_id += 1
            self.scans[key] = entry
            action = 'created'
        else:
            entry = self.scans[key]
            self.scans.move_to_end(key)
            action = 'resume_identical_timing'
            if entry['starts'] != initial:
                entry.update(epoch=entry['epoch'] + 1, cursor=0, starts=copy.deepcopy(initial), proof_steps=[], local=False)
                action = 'reset_changed_caller_timing'
        before = self._state(entry)
        record = {'id': invocation, 'permutation': list(order), 'initial': copy.deepcopy(initial),
            'action': action, 'before': before, 'deadline_seconds': deadline - started,
            'started_seconds': self.clock() - started, 'sequence': [list(d) for d in sequence]}
        self.invocations.append(record)
        calls, accepted, changed_neighborhoods = [], 0, 0
        stop = 'deadline_before_neighborhood'
        while entry['cursor'] < len(self.sequence) and changed_neighborhoods < maximum_passes:
            if self.clock() >= deadline:
                break
            cursor, epoch = entry['cursor'], entry['epoch']
            descriptor = sequence[cursor]
            old_starts, old_value = copy.deepcopy(current), score
            call_index, step_id = len(calls), len(self.steps)
            tick = self.clock()

            def retain(candidate, value, stage, lookup):
                nonlocal current, score, accepted
                if value >= score or self.clock() >= deadline:
                    return
                assert physical_numerator(ctx, order, candidate) == value
                available = self.clock()
                if available >= deadline:
                    return
                current, score = copy.deepcopy(candidate), value
                accepted += 1
                events.append({'elapsed_seconds': available - started, 'source': 'union_chain_projected_refinement',
                    'permutation': list(order), 'starts': copy.deepcopy(current),
                    'score_fraction': str(F(score, ctx.denominator)),
                    'move': {'call_index': call_index, 'step_id': step_id, 'scope': descriptor[0],
                             'proposal_stage': stage, 'source_lookup': lookup}})

            if descriptor[0] == 'chain':
                _, kind, index = descriptor
                response = self.chain_cache.response(order, current, kind, index, deadline)
                retain(response['starts'], response['score_numerator'], response['source'], response['id'])
            else:
                _, kind, machines, fixed = descriptor
                response = self.projected_pool.response(order, current, machines, fixed, deadline, retain)
            complete, improved = response['complete'], score < old_value
            deferred = bool(complete and not improved and response['score_numerator'] < score)
            step = {'id': step_id, 'invocation': invocation, 'scan_id': entry['id'], 'epoch': epoch,
                'cursor': cursor, 'descriptor': list(descriptor), 'initial': old_starts,
                'complete': complete, 'accepted': improved, 'response': response,
                'deferred_strict_improvement': deferred,
                'returned_starts': copy.deepcopy(current), 'score_fraction': str(F(score, ctx.denominator)),
                'seconds': self.clock() - tick}
            self.steps.append(step)
            calls.append(step)
            entry['starts'] = copy.deepcopy(current)
            if improved:
                entry.update(epoch=epoch + 1, cursor=0, proof_steps=[], local=False)
                changed_neighborhoods += 1
            elif complete and not deferred:
                entry['proof_steps'].append(step_id)
                entry['cursor'] += 1
                entry['local'] = entry['cursor'] == len(self.sequence)
            if not complete:
                stop = 'incomplete_neighborhood'
                break
            if deferred:
                # A proved improvement can finish before the slice cutoff
                # but miss its later admission. It cannot certify that the
                # unchanged incumbent is locally optimal on a future call.
                stop = 'deferred_neighborhood_improvement'
                break
        if entry['cursor'] == len(self.sequence):
            stop = 'completed_chain_projected_union_local'
        elif changed_neighborhoods >= maximum_passes:
            stop = 'change_cap_without_union_locality'
        assert physical_numerator(ctx, order, current) == score
        record.update(after=self._state(entry))
        result = {'starts': current, 'score_fraction': str(F(score, ctx.denominator)), 'local': False,
            'stop': stop, 'calls': calls, 'accepted_moves': accepted, 'maximum_passes': maximum_passes,
            'arm': 'ma_chain_projected_union', 'invocation_id': invocation,
            'scan_before': before, 'scan_after': self._state(entry),
            'union_scope': 'fixed_exterior_machine_job_chains_and_zero_free_projected_single_pair',
            'M1_job_chains_subsumed_by_full_machine_chain': len(ctx.powers[0]) == 1}
        returned = self.clock()
        local = bool(entry['local'] and returned < deadline)
        if entry['local'] and not local:
            result['stop'] = 'deadline_before_union_locality_return'
        result['local'] = local
        record.update(returned_seconds=returned - started, local=local)
        return result

    def close(self):
        if not self.closed:
            self.projected_pool.close()
            self.chain_cache.cards.clear()
            self.scans.clear()
            self.closed = True
        return {'closed': self.closed, 'scan_capacity': self.scan_capacity,
            'sequence_template': [list(d) for d in self.sequence],
            'job_template_indices_are_positions_in_current_permutation': True,
            'scan_actions': self.scan_actions,
            'scan_entries_created': self.next_scan_id, 'steps': self.steps, 'invocations': self.invocations,
            'chain_cache': self.chain_cache.receipt(), 'projected_pool': self.projected_pool.receipt(),
            'prefix_reuse_requires_identical_full_timing': True,
            'all_cache_work_paid_in_current_run_only': True}
