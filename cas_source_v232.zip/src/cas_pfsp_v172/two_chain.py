"""Equivalent row preparation using conventional grid and chain prefix tables.

The v135/v138/v157 transition, reconstruction and summary methods are inherited
unchanged. PreparedInput and OwnedAnchor are immutable snapshots, not a paid
search policy: a future complete caller must create and charge them within its
own root run. No public performance, scientific priority or hard deadline claim.
"""
from dataclasses import dataclass
from cas_pfsp_v45.model import Instance
from cas_pfsp_v47.pair_timing import make_context, load_functional
from cas_pfsp_v64.registry import physical_numerator
from cas_pfsp_v135.two_chain import ChainTiming as OriginalChainTiming
from cas_pfsp_v138.two_chain import ViableChainTiming as OriginalViableChainTiming
from cas_pfsp_v157.two_chain import JointViableChainTiming as OriginalJointChainTiming


@dataclass(frozen=True, slots=True, eq=False, init=False)
class PreparedInput:
    """Own one exact context; no externally supplied context/cost is accepted."""
    context: object
    n: int
    m: int
    horizon: int

    def __init__(self, instance, checkpoint=lambda phase: None):
        if not isinstance(instance, Instance):
            raise TypeError('A fixed CAS Instance is required to create a context owner')
        checkpoint('ordered_context_begin')
        ctx = make_context(instance)
        object.__setattr__(self, 'context', ctx)
        object.__setattr__(self, 'n', len(ctx.powers))
        object.__setattr__(self, 'm', len(ctx.powers[0]))
        object.__setattr__(self, 'horizon', ctx.horizon)
        checkpoint('ordered_context_complete')

    def anchor(self, order, starts, checkpoint=lambda phase: None):
        return OwnedAnchor(self, order, starts, checkpoint=checkpoint)


@dataclass(frozen=True, slots=True, eq=False, init=False)
class OwnedAnchor:
    """Validated fixed schedule and exact machine/gross loads owned by one input."""
    owner: PreparedInput
    order: tuple
    starts: tuple
    value: int
    row_power: tuple
    gross: tuple

    def __init__(self, owner, order, starts, checkpoint=lambda phase: None):
        if not isinstance(owner, PreparedInput):
            raise TypeError('PreparedInput owner required')
        checkpoint('ordered_anchor_begin')
        permutation = tuple(order)
        matrix = tuple(tuple(row) for row in starts)
        value = physical_numerator(owner.context, permutation, matrix)
        checkpoint('ordered_anchor_validated')
        loads = [[0] * owner.horizon for _ in range(owner.m)]
        for j, job in enumerate(owner.context.powers):
            for a, profile in enumerate(job):
                checkpoint('ordered_anchor_profile')
                for offset, power in enumerate(profile):
                    loads[a][matrix[j][a] + offset] += power
        gross = []
        for t in range(owner.horizon):
            checkpoint('ordered_anchor_gross_period')
            gross.append(sum(loads[a][t] for a in range(owner.m)))
        assert load_functional(owner.context, gross) == value
        object.__setattr__(self, 'owner', owner)
        object.__setattr__(self, 'order', permutation)
        object.__setattr__(self, 'starts', matrix)
        object.__setattr__(self, 'value', value)
        object.__setattr__(self, 'row_power', tuple(tuple(row) for row in loads))
        object.__setattr__(self, 'gross', tuple(gross))
        checkpoint('ordered_anchor_complete')


class ChainTiming(OriginalChainTiming):
    """Same v135 state/kernel; replace only preparation and within-owner reuse."""
    def __init__(self, instance, order, anchor, machine_rows, checkpoint=lambda phase: None):
        self.checkpoint = checkpoint
        checkpoint('chain_prepare_begin')
        if isinstance(anchor, OwnedAnchor):
            if not isinstance(instance, PreparedInput) or anchor.owner is not instance:
                raise ValueError('Owned anchor belongs to a different input owner')
            permutation = tuple(order)
            if any(type(j) is not int for j in permutation) or permutation != anchor.order:
                raise ValueError('Owned anchor permutation differs from requested order')
            owner, saved = instance, anchor
        else:
            owner = instance if isinstance(instance, PreparedInput) else PreparedInput(instance, checkpoint)
            saved = owner.anchor(order, anchor, checkpoint)
        self.prepared_input, self.owned_anchor = owner, saved
        self.ctx = owner.context
        self.order = list(saved.order)
        self.anchor = [list(row) for row in saved.starts]
        self.anchor_value = saved.value
        self.n, self.m, self.h = owner.n, owner.m, owner.horizon
        rows = list(machine_rows)
        if not 1 <= len(rows) <= 2 or any(type(a) is not int for a in rows):
            raise ValueError('One or two integer machine rows required')
        if len(set(rows)) != len(rows):
            raise ValueError('Duplicate machine row')
        if any(not 0 <= a < self.m for a in rows):
            raise ValueError('Machine row outside model')
        self.rows = tuple(sorted(rows))
        self.rank = {j: r for r, j in enumerate(self.order)}
        self.chains = [[(j, a) for j in self.order if self.ctx.durations[j][a]] for a in self.rows]
        self.free = {op for chain in self.chains for op in chain}
        self.fixed = [(j, a) for j in range(self.n) for a in range(self.m)
                      if self.ctx.durations[j][a] and (j, a) not in self.free]
        selected = set(self.rows)

        # At a free vertex the cell itself is not fixed: inclusive dominance
        # rectangles therefore equal the distinct comparable-fixed sets.
        earlier = [[0] * self.m for _ in range(self.n)]
        for r, j in enumerate(self.order):
            for a in range(self.m):
                checkpoint('ordered_fixed_prefix_cell')
                fixed_end = self.anchor[j][a] + self.ctx.durations[j][a] if self.ctx.durations[j][a] and a not in selected else 0
                earlier[r][a] = max(fixed_end, earlier[r-1][a] if r else 0,
                                    earlier[r][a-1] if a else 0)
        later = [[self.h] * self.m for _ in range(self.n)]
        for r in reversed(range(self.n)):
            j = self.order[r]
            for a in reversed(range(self.m)):
                checkpoint('ordered_fixed_suffix_cell')
                fixed_start = self.anchor[j][a] if self.ctx.durations[j][a] and a not in selected else self.h
                later[r][a] = min(fixed_start, later[r+1][a] if r+1 < self.n else self.h,
                                  later[r][a+1] if a+1 < self.m else self.h)
        self.domains = {}
        for j, a in sorted(self.free):
            checkpoint('chain_prepare_domain')
            low = earlier[self.rank[j]][a]
            high = later[self.rank[j]][a] - self.ctx.durations[j][a]
            assert low <= self.anchor[j][a] <= high
            self.domains[j, a] = low, high

        self.chain_tables, self.work, self.goal = [], {}, []
        for index, chain in enumerate(self.chains):
            checkpoint('chain_prepare_table')
            table, done = [], 0
            for op in chain:
                j, a = op
                duration = self.ctx.durations[j][a]
                self.work[op] = index, done, done + duration
                for offset in range(duration):
                    table.append((op, offset, offset != 0))
                done += duration
            table.append((None, None, False))
            self.chain_tables.append(table)
            self.goal.append(done)
            assert done <= self.h
        self.goal = tuple(self.goal)

        prefixes = []
        for a in self.rows:
            totals = [0]
            for j in self.order:
                checkpoint('ordered_chain_prefix_job')
                totals.append(totals[-1] + self.ctx.durations[j][a])
            prefixes.append(totals)
        self.requirements = {}
        for j, a in sorted(self.free):
            needed = []
            for i, row in enumerate(self.rows):
                checkpoint('ordered_predecessor_query')
                needed.append(prefixes[i][self.rank[j] + (row < a)] if row <= a else 0)
            self.requirements[j, a] = tuple(needed)

        self.background = []
        for t in range(self.h):
            checkpoint('ordered_background_period')
            power = saved.gross[t] - sum(saved.row_power[a][t] for a in self.rows)
            assert power >= 0
            self.background.append(power)
        self.background_tail = [0] * (self.h+1)
        for t in reversed(range(self.h)):
            checkpoint('ordered_background_tail_period')
            self.background_tail[t] = self.background_tail[t+1] + self.ctx.carbon[t] * max(0, self.background[t]-self.ctx.renewable[t])
        self.best_value = self.anchor_value
        self.best_starts = [row[:] for row in self.anchor]
        self.layers = [{tuple(0 for a in self.rows): dict(cost=0, parent=None, starts=[])}]
        self.frontier_trace = []
        self.started = self.complete = False
        self.transitions = self.state_updates = self.materialized = self.improvements = 0
        self.preparation = dict(method='ordered_grid_and_chain_prefix_v172',
                                fixed_domain_grid_cells=2*self.n*self.m,
                                predecessor_queries=len(self.rows)*len(self.free),
                                context_identity_reused=self.ctx is owner.context,
                                immutable_anchor_identity_reused=saved is anchor,
                                state_transition_kernel_changed=False,
                                paid_complete_policy_or_public_speed_qualified=False)
        checkpoint('chain_prepare_complete')


class ViableChainTiming(OriginalViableChainTiming, ChainTiming):
    """MRO sends only base preparation to v172; v138 tables/kernel unchanged."""


class JointViableChainTiming(OriginalJointChainTiming, ViableChainTiming):
    """MRO also retains the complete v157 joint table and predicate unchanged."""
