"""Equivalent ordered-grid preparation; complete-policy qualification is separate."""
