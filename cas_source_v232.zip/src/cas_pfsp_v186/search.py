"""Experimental paid competition+cost+joint row repair; inherited policy and root accounting.
No performance or priority claim is established by this implementation.
"""
from fractions import Fraction as F
from pathlib import Path
import itertools
import hashlib
import json
import math
import random
import time
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import gross_profile
from cas_pfsp_v64.registry import PhysicalRegistry
from cas_pfsp_v76.search import PhaseSearch
from cas_pfsp_v116.timed import Budget,Expired
from cas_pfsp_v123.search import attempt_id,point_key
from cas_pfsp_v172.two_chain import PreparedInput
from cas_pfsp_v186.two_chain import CompetitionChainTiming as ChainTiming


class SliceExpired(Exception):pass


def select_rows(ctx,anchor,maximum,attempted,poll,row):
    poll('row_selection_begin');h=ctx.horizon;gross=gross_profile(ctx,anchor['starts'])
    m=len(ctx.powers[0]);loads=[[0]*h for a in range(m)];positive=[]
    for j,job in enumerate(ctx.powers):
        for a,profile in enumerate(job):
            poll('row_selection_operation')
            if profile:positive.append((j,a))
            for offset,power in enumerate(profile):loads[a][anchor['starts'][j][a]+offset]+=power
    active=sorted({a for j,a in positive});groups=[]
    for size in reversed(range(1,min(maximum,len(active))+1)):
        for chosen in itertools.combinations(active,size):
            poll('row_group_score');score=0
            for t in range(h):
                removed=sum(loads[a][t] for a in chosen)
                score+=ctx.carbon[t]*(max(0,gross[t]-ctx.renewable[t])-max(0,gross[t]-removed-ctx.renewable[t]))
            groups.append((chosen,score))
    groups.sort(key=lambda x:(-len(x[0]),-x[1],x[0]))
    row['row_group_ranking']=[{'machine_rows':list(chosen),'removal_score_fraction':str(F(score,ctx.denominator))}
        for chosen,score in groups]
    for chosen,score in groups:
        poll('row_selection_descriptor')
        exterior=tuple((j,a,anchor['starts'][j][a]) for j,a in positive if a not in chosen)
        descriptor=tuple(anchor['permutation']),chosen,exterior
        if descriptor in attempted:continue
        free=[list(op) for op in positive if op[1] in chosen]
        row.update(selected_machine_rows=list(chosen),free_positive_operations=free,
            descriptor={'order':anchor['permutation'],'machine_rows':list(chosen),
                'fixed_positive_starts':[list(x) for x in exterior]})
        return descriptor
    return None


def repair(prepared,ctx,registry,budget,cache,owned_cache,attempted,repairs,maximum,slice_seconds):
    anchor=registry.best;start=budget.now()
    if start>=budget.deadline:raise Expired('before_repair_start')
    cutoff=min(budget.deadline,start+slice_seconds)
    row={'id':len(repairs),'anchor_attempt_id':attempt_id(registry,anchor),
        'started_seconds':start-budget.started,'slice_deadline_seconds':cutoff-budget.started,
        'row_group_ranking':[],'selected_machine_rows':None,'free_positive_operations':None,
        'descriptor':None,'events':[],'chain_DP':None,'neighborhood_proved_optimal':False,
        'proof_ready_seconds':None,'stop':None,'returned_seconds':None,
        'registration_attempts_before':len(registry.attempts),
        'owned_anchor_cache_hit':None,'owned_anchor_lookup_ready_seconds':None,'owned_anchor_lookup_timely':None,
        'owned_anchor_creation_started_seconds':None,'owned_anchor_original_ready_seconds':None,
        'owned_anchor_cache_committed':False,'owned_anchor_origin_repair':None,'owned_anchor_origin_attempt_id':None,
        'owned_anchor_snapshot_sha256':None,'owned_anchor_validation_reused_inside_root':False,
        'owned_model_context_same_as_root':None,'owned_model_anchor_same_as_cached':None}
    repairs.append(row);before=F(anchor['score_fraction']);built=None
    def poll(phase):
        budget.poll(phase)
        if budget.now()>=cutoff:raise SliceExpired(phase)
    def record(point):
        poll('chain_before_root_registration');key=point_key(point);cached=key in cache
        if not cached:
            registered=registry.register(point['permutation'],point['starts'],point['score_fraction'],
                {'kind':'chain_DP_strict_improvement','repair':row['id'],
                 'scaled_integer_objective':str(point['score_numerator']),
                 'objective_denominator':str(ctx.denominator)})
            index=len(registry.attempts)-1;cache[key]=index
        else:index=cache[key];registered=registry.attempts[index]
        row['events'].append({'kind':'chain_DP_strict_improvement','attempt_id':index,
            'paid_within_run_cache_hit':cached,'reference_ready_seconds':budget.now()-budget.started,
            'referenced_registration_eligible':registered['eligible']})
        poll('chain_after_root_registration')
    try:
        key=select_rows(ctx,anchor,maximum,attempted,poll,row)
        row['selection_ready_seconds']=budget.now()-budget.started
        if key is None:row['stop']='declared_row_groups_exhausted';return False
        attempted.add(key);poll('before_chain_build')
        poll('before_owned_anchor_lookup');current_key=point_key(anchor)
        hit=owned_cache['key']==current_key
        owned_cache['lookups']+=1;owned_cache['hits']+=int(hit)
        row['owned_anchor_cache_hit']=hit
        lookup_ready=budget.now();row['owned_anchor_lookup_ready_seconds']=lookup_ready-budget.started
        row['owned_anchor_lookup_timely']=lookup_ready<=cutoff and lookup_ready<=budget.deadline
        if lookup_ready>budget.deadline:raise Expired('owned_anchor_lookup_ready')
        if lookup_ready>cutoff:raise SliceExpired('owned_anchor_lookup_ready')
        if not hit:
            row['owned_anchor_creation_started_seconds']=budget.now()-budget.started
            owned_cache['creation_attempts']+=1
            saved=prepared.anchor(anchor['permutation'],anchor['starts'],checkpoint=poll)
            payload=(saved.order,saved.starts,str(F(saved.value,ctx.denominator)))
            fingerprint=hashlib.sha256(json.dumps(payload,separators=(',',':')).encode()).hexdigest()
            ready=budget.now();row['owned_anchor_original_ready_seconds']=ready-budget.started
            row['owned_anchor_snapshot_sha256']=fingerprint
            if ready>budget.deadline:raise Expired('owned_anchor_ready')
            if ready>cutoff:raise SliceExpired('owned_anchor_ready')
            owned_cache.update(key=current_key,anchor=saved,ready_seconds=ready-budget.started,
                snapshot_sha256=fingerprint,origin_repair=row['id'],origin_attempt_id=row['anchor_attempt_id'])
            owned_cache['committed']+=1;row['owned_anchor_cache_committed']=True
        saved=owned_cache['anchor']
        row.update(owned_anchor_original_ready_seconds=owned_cache['ready_seconds'],
            owned_anchor_origin_repair=owned_cache['origin_repair'],owned_anchor_origin_attempt_id=owned_cache['origin_attempt_id'],
            owned_anchor_snapshot_sha256=owned_cache['snapshot_sha256'],owned_anchor_validation_reused_inside_root=hit)
        assert prepared.context is ctx
        poll('before_ordered_chain_build')
        built=ChainTiming(prepared,anchor['permutation'],saved,row['selected_machine_rows'],checkpoint=poll)
        row['owned_model_context_same_as_root']=built.ctx is ctx
        row['owned_model_anchor_same_as_cached']=built.owned_anchor is saved
        row['model_ready_seconds']=budget.now()-budget.started
        summary=built.run(on_improvement=record);row['chain_DP']=summary
        ready=budget.now();row['proof_ready_seconds']=ready-budget.started
        row['neighborhood_proved_optimal']=ready<=cutoff and ready<=budget.deadline
        row['stop']='chain_DP_complete' if row['neighborhood_proved_optimal'] else 'late_chain_proof'
        if row['neighborhood_proved_optimal']:
            assert summary['neighborhood_proved_optimal']
            assert F(registry.best['score_fraction'])==F(summary['best']['score_fraction'])
    except SliceExpired as error:row['stop']='slice_at_'+str(error)
    except Expired as error:
        row['stop']='global_budget_at_'+str(error);raise
    finally:
        if built is not None and row['chain_DP'] is None:row['chain_DP']=built.summary()
        row.update(returned_seconds=budget.now()-budget.started,registration_attempts_after=len(registry.attempts),
            best_after_attempt_id=attempt_id(registry,registry.best),improved_global_best=F(registry.best['score_fraction'])<before)
    return True


def run_budgeted(loader,budget_seconds,seed=0,phase_fraction=.5,max_machine_rows=2,
        repair_slice_seconds=.5,phase_max_evaluations=None,max_repairs=None,clock=time.perf_counter):
    if not math.isfinite(budget_seconds) or budget_seconds<=0:raise ValueError('Positive finite core budget required')
    if not math.isfinite(phase_fraction) or not 0<phase_fraction<1:raise ValueError('Phase fraction must be strictly between0and1')
    if not math.isfinite(repair_slice_seconds) or repair_slice_seconds<=0:raise ValueError('Positive finite repair slice required')
    if type(seed) is not int or type(max_machine_rows) is not int or max_machine_rows not in (1,2):
        raise ValueError('Integer seed and maximum machine row count1or2 required')
    for value in (phase_max_evaluations,max_repairs):
        if value is not None and (type(value) is not int or value<1):raise ValueError('Positive integer diagnostic quota required')
    budget=Budget(float(budget_seconds),clock);cpu=time.process_time();rng=random.getstate()
    physical=ctx=registry=prepared=None;phase_out=None;repairs=[];cache={};attempted=set();setup={};reason=None
    owned_cache=dict(key=None,anchor=None,ready_seconds=None,snapshot_sha256=None,origin_repair=None,origin_attempt_id=None,
        lookups=0,hits=0,creation_attempts=0,committed=0)
    try:
        budget.poll('before_input_load');physical=loader()
        setup['input_loaded_seconds']=budget.now()-budget.started
        budget.poll('after_input_load')
        setup['owned_context_started_seconds']=budget.now()-budget.started
        prepared=PreparedInput(physical,checkpoint=budget.poll);ctx=prepared.context
        setup['context_ready_seconds']=budget.now()-budget.started
        registry=PhysicalRegistry(ctx,budget.started,budget.deadline,clock=budget.now)
        budget.poll('before_phase_component')
        phase_deadline=budget.started+phase_fraction*budget_seconds
        phase=PhaseSearch(ctx,budget.started,phase_deadline,'t1p1',seed,clock=budget.now,max_evaluations=phase_max_evaluations)
        phase.registry=registry;phase_out=phase.run()
        phase_out.pop('registered_attempts');phase_best=phase_out.pop('best_registered')
        phase_out.update(physical_registry_attempt_range=[0,len(registry.attempts)],
            best_registered_attempt_id=None if phase_best is None else attempt_id(registry,phase_best),
            shared_root_physical_registry=True,returned_to_composition_seconds=budget.now()-budget.started)
        budget.poll('after_phase_component')
        for i,point in enumerate(registry.attempts):cache.setdefault(point_key(point),i)
        while True:
            budget.poll('before_repair')
            if registry.best is None:reason='no_paid_feasible_initializer';break
            if registry.best_value==0:reason='nonnegative_zero_attained';break
            if max_repairs is not None and len(repairs)>=max_repairs:reason='diagnostic_repair_quota';break
            if not repair(prepared,ctx,registry,budget,cache,owned_cache,attempted,repairs,max_machine_rows,repair_slice_seconds):
                reason='declared_row_groups_exhausted';break
    except Expired as error:reason='global_budget_at_'+str(error)
    assert random.getstate()==rng
    best=None if registry is None else registry.best;zero=best is not None and F(best['score_fraction'])==0
    owned_accounting=dict(context_owner_constructor_completed=prepared is not None,
        context_owner_ready_seconds=setup.get('context_ready_seconds'),single_anchor_capacity=1,
        cached_anchors_at_return=int(owned_cache['anchor'] is not None),lookup_attempts=owned_cache['lookups'],
        lookup_hits=owned_cache['hits'],anchor_creation_attempts=owned_cache['creation_attempts'],
        anchor_creations_committed=owned_cache['committed'],external_context_or_anchor_arguments_accepted=False,
        all_owner_creation_and_cache_work_inside_this_root=True,
        cache_commit_requires_original_ready_at_or_before_both_limits=True)
    elapsed=budget.now()-budget.started
    return {'status':'OPTIMAL' if zero else 'FEASIBLE' if best is not None else 'UNKNOWN','stop_reason':reason,
        'seed':seed,'budget_seconds':budget_seconds,'phase_fraction':phase_fraction,'max_machine_rows':max_machine_rows,
        'repair_slice_seconds':repair_slice_seconds,'phase_max_evaluations':phase_max_evaluations,'max_repairs':max_repairs,
        'setup':setup,'phase_component':phase_out,'repairs':repairs,'owned_preparation_accounting':owned_accounting,
        'registered_attempts':[] if registry is None else registry.attempts,'best_registered':best,
        'registration_seconds':0. if registry is None else registry.registration_seconds,
        'input_sha256':None if physical is None else physical.input_sha256,
        'algorithm_wall_seconds':elapsed,'algorithm_cpu_seconds':time.process_time()-cpu,
        'overshoot_seconds':max(0.,elapsed-budget_seconds),'checkpoint_counts':budget.polls,'last_checkpoint':budget.last_phase,
        'zero_global_objective_certified':zero,'positive_global_optimum_claim':False,
        'all_initialization_selection_model_solver_callbacks_registration_and_policy_charged':True,
        'module_loading_and_final_JSON_serialization_excluded_like_frozen_core_contract':True,
        'shared_root_eligibility':'available_seconds<=budget_seconds','donated_initializer_or_external_cache':False,
        'global_Python_RNG_unchanged':True,'hard_return_deadline_guaranteed':False,
        'public_quality_or_algorithmic_priority_qualified':False,'timing_backend':'competition_priced_cost_joint_ordered_exact_machine_row_DP_v186',
        'CP_solver_calls':0,'v76_initializer_program_and_default_phase_fraction_retained':True,
        'v136_row_selector_attempt_rules_and_defaults_retained':True,
        'row_group_selection_policy':'larger_groups_first_then_exact_joint_removal_score_then_machine_ids',
        'attempt_policy':'once_per_order_rows_and_fixed_outside_positive_starts_including_interrupted_attempts'}


def run_file(path,budget_seconds,**kwargs):
    path=Path(path).resolve()
    if 'neso_' in str(path).lower():raise ValueError('Reserved path before content access')
    return run_budgeted(lambda:load_instance(path),budget_seconds,**kwargs)
