"""Exact integer supporting-price lower bounds for shared renewable supply.

For 0 <= price[t] <= carbon[t], c[t] * max(0, load-r[t]) >=
price[t] * (load-r[t]). Minimize each residual chain's priced load
independently, add the fixed exterior term, and maximize with the existing
marginal lower bound. Prices are fixed from the paid feasible anchor;
no optimized dual solution or priority is claimed.
"""
from cas_pfsp_v166.marginal_bound import MarginalSuffixBound


class CompetitionBound:
    def __init__(self, marginal, chains, background, renewable, carbon,
                 anchor_load, checkpoint=lambda phase: None):
        self.marginal = marginal
        self.h = len(carbon)
        assert len(anchor_load) == self.h
        candidates = [tuple(carbon), tuple(c if load >= r else 0
                      for c, load, r in zip(carbon, anchor_load, renewable))]
        self.prices = list(dict.fromkeys(candidates))
        self.parts = []
        for prices in self.prices:
            assert all(type(p) is int and 0 <= p <= c for p, c in zip(prices, carbon))
            priced = MarginalSuffixBound(chains, [0] * self.h, [0] * self.h,
                                         prices, checkpoint=checkpoint)
            tail = [0] * (self.h + 1)
            for t in reversed(range(self.h)):
                checkpoint('competition_fixed_price_tail')
                tail[t] = tail[t + 1] + prices[t] * (background[t] - renewable[t])
            self.parts.append((priced, tail))
        self.prepared_cells = marginal.prepared_cells + sum(p.prepared_cells for p, _ in self.parts)
        self.evaluations = self.strictly_stronger = 0

    def details(self, time, work, prefix_numerator):
        marginal = self.marginal.full_lower(time, work, prefix_numerator)
        prices = []
        for priced, tail in self.parts:
            solo = priced.remaining(time, work)
            prices.append(None if solo is None else prefix_numerator + tail[time] + solo)
        lower = None if marginal is None or any(x is None for x in prices) else max([marginal] + prices)
        return dict(marginal=marginal, priced=prices, lower=lower)

    def full_lower(self, time, work, prefix_numerator):
        d = self.details(time, work, prefix_numerator)
        self.evaluations += 1
        self.strictly_stronger += int(d['lower'] is not None and d['lower'] > d['marginal'])
        return d['lower']
