"""Experimental renewable competition bounds; scientific priority unestablished."""
