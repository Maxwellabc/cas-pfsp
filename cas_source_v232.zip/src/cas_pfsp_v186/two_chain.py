"""Combine ordered joint-feasibility DP with supporting-price cost bounds."""
from cas_pfsp_v179.two_chain import CostChainTiming
from cas_pfsp_v186.dual_bound import CompetitionBound


class CompetitionChainTiming(CostChainTiming):
    def __init__(self, instance, order, anchor, machine_rows, checkpoint=lambda phase: None):
        super().__init__(instance, order, anchor, machine_rows, checkpoint=checkpoint)
        chains = [[dict(profile=self.ctx.powers[j][a], earliest=self.domains[j, a][0],
                        latest=self.domains[j, a][1]) for j, a in chain] for chain in self.chains]
        loads = [0] * self.h
        for j, job in enumerate(self.ctx.powers):
            for a, profile in enumerate(job):
                checkpoint('competition_anchor_load')
                for offset, power in enumerate(profile):
                    loads[self.owned_anchor.starts[j][a] + offset] += power
        self.cost_bound = CompetitionBound(self.cost_bound, chains, self.background,
            self.ctx.renewable, self.ctx.carbon, loads, checkpoint=checkpoint)

    def summary(self):
        out = super().summary()
        out.update(cost_pruning='maximum_of_marginal_and_two_fixed_supporting_price_bounds',
            supporting_prices=[list(x) for x in self.cost_bound.prices],
            competition_bound_evaluations=self.cost_bound.evaluations,
            competition_strict_strengthenings=self.cost_bound.strictly_stronger,
            optimized_dual_solution_claim=False, algorithmic_priority_established=False)
        return out
