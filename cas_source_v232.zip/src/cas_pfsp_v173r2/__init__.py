"""Paid ordered preparation with strict repair entry deadline guard."""
