"""Positive-chain timing with all zero nodes free and fixed exterior positives.

Finite-horizon product-state DP is a standard technique,not claimed new.
State=(next job position,consumed processing slots) on each selected machine.
Processing already started cannot pause. Ready zero-duration nodes close as
early as feasible;this cannot increase load or constrain a positive successor.
Only a completed search certifies the declared positive-start neighborhood optimum.
Full-grid windows leave every zero node variable;selected positive ancestors are
checked across both machines,even across a nonadjacent machine gap. Final zeros
are lifted to their earliest feasible values. Freeing zeros is established
precedence projection,not a claim that dummy-node elimination is new.
"""
from fractions import Fraction as F
from .residual_bound import relaxed_tables
import itertools,time
from cas_pfsp_v47.pair_timing import gross_profile,load_functional
from cas_pfsp_v53.minimum_closure import temporal_grid
from cas_pfsp_v49.timing_pairs import lift_zero_operations


def best_response(ctx,order,initial,machines,deadline=None,state_limit=2_000_000,on_improvement=None,fixed_positive_machines=(),bound_mode="residual",capture_bound_certificate=False):
    begun=time.perf_counter()
    if deadline is not None and begun>=deadline:raise TimeoutError('No joint DP started')
    if bound_mode not in ("background","residual"):raise ValueError("Unknown admissible bound")
    pair=tuple(sorted(machines));n=len(ctx.powers);m=len(ctx.powers[0]);h=ctx.horizon
    if len(pair)!=2 or len(set(pair))!=2 or any(type(a) is not int or not 0<=a<m for a in pair):
        raise ValueError('Two distinct machine indices required')
    if type(state_limit) is not int or state_limit<1:raise ValueError('Positive state limit required')
    if any(x<0 for x in ctx.carbon+ctx.renewable) or any(x<0 for job in ctx.powers for op in job for x in op):
        raise ValueError('Nonnegative CAS coefficients required')
    fixed=set(fixed_positive_machines)
    if not fixed<=set(pair) or len(fixed)==2:raise ValueError('At least one selected machine must have variable positive starts')
    grid=temporal_grid(ctx.durations,order,h);selected=set(pair)-fixed
    for j,a in grid.nodes:
        s=initial[j][a]
        if type(s) is not int or not grid.lower[j,a]<=s<=grid.upper[j,a]:raise ValueError('Feasible initial starts required')
        if any(s<initial[p][b]+ctx.durations[p][b] for p,b in grid.parents[j,a]):raise ValueError('Feasible initial precedence required')
    # Fixed exterior propagates exact necessary temporal windows through the DAG.
    lower={};upper={}
    for j,a in grid.nodes:
        base=0 if a in selected or ctx.durations[j][a]==0 else initial[j][a]
        lower[j,a]=max([base]+[lower[p,b]+ctx.durations[p][b] for p,b in grid.parents[j,a]])
        if a not in selected and ctx.durations[j][a]:assert lower[j,a]==initial[j][a]
    for j,a in reversed(grid.nodes):
        base=h-ctx.durations[j][a] if a in selected or ctx.durations[j][a]==0 else initial[j][a]
        upper[j,a]=min([base]+[upper[p,b]-ctx.durations[j][a] for p,b in grid.children[j,a]])
        if a not in selected and ctx.durations[j][a]:assert upper[j,a]==initial[j][a]
        assert lower[j,a]<=initial[j][a]<=upper[j,a]
    background=gross_profile(ctx,initial)
    for a in pair:
        for j in order:
            for k,p in enumerate(ctx.powers[j][a]):background[initial[j][a]+k]-=p
    assert all(q>=0 for q in background)
    suffix=[0]*(h+1)
    for t in range(h-1,-1,-1):suffix[t]=suffix[t+1]+ctx.carbon[t]*max(background[t]-ctx.renewable[t],0)
    stages=[]
    for a in pair:
        rows=[(i,r) for i,j in enumerate(order) for r in range(max(1,ctx.durations[j][a]))]+[(n,0)]
        ids={state:k for k,state in enumerate(rows)}
        remain=[0]*(n+1)
        for i in range(n-1,-1,-1):remain[i]=remain[i+1]+ctx.durations[order[i]][a]
        stages.append({'rows':rows,'ids':ids,'end':ids[n,0],'remaining':remain})
    required=[];last=-1
    for i,j in enumerate(order):
        if ctx.durations[j][pair[0]]:last=i
        required.append(last)
    width=len(stages[1]['rows'])
    def unpack(key):return [key//width,key%width]
    def pack(x):return x[0]*width+x[1]
    def ready(slot,i,t,x):
        a=pair[slot];j=order[i]
        if t<lower[j,a] or t>upper[j,a]:return False
        if slot==1 and required[i]>=0:
            up_i,_=stages[0]['rows'][x[0]]
            if up_i<=required[i]:return False
        return True
    def normalize(key,t):
        x=unpack(key);closed=[]
        for slot,a in enumerate(pair):
            while True:
                i,r=stages[slot]['rows'][x[slot]]
                if i==n:break
                j=order[i];d=ctx.durations[j][a]
                if r==0 and t>upper[j,a]:return None
                if d or not ready(slot,i,t,x):break
                closed.append((j,a));x[slot]=stages[slot]['ids'][i+1,0]
            i,r=stages[slot]['rows'][x[slot]]
            if t+stages[slot]['remaining'][i]-r>h:return None
        return pack(x),closed
    def choices(slot,state,t,x):
        i,r=stages[slot]['rows'][state];a=pair[slot]
        if i==n:return [(0,state,0)]
        j=order[i];op=ctx.powers[j][a];d=len(op)
        if not d:return [(0,state,0)]
        if r==0:
            options=[(0,state,0)]
            if not ready(slot,i,t,x):return options
        else:options=[]
        after=stages[slot]['ids'][i,r+1] if r+1<d else stages[slot]['ids'][i+1,0]
        options.append((op[r],after,1));return options
    best=[list(row) for row in initial];upper_value=load_functional(ctx,gross_profile(ctx,best))
    initial_value=upper_value;events=[];parents=[{}];current={0:0}
    generated=1;expanded=transitions=normalized_count=0;complete=True;stop='complete_exact_neighborhood'
    def reconstruct(t,key):
        s=[list(row) for row in initial];assigned=set()
        norm=normalize(key,t);assert norm is not None
        for op in norm[1]:s[op[0]][op[1]]=t;assigned.add(op)
        while t:
            previous,mask=parents[t][key];norm=normalize(previous,t-1);assert norm is not None
            x=unpack(norm[0])
            for op in norm[1]:
                assert op not in assigned;s[op[0]][op[1]]=t-1;assigned.add(op)
            for slot,a in enumerate(pair):
                i,r=stages[slot]['rows'][x[slot]]
                if mask>>slot&1 and i<n and r==0 and ctx.durations[order[i]][a]:
                    op=(order[i],a);assert op not in assigned;s[op[0]][op[1]]=t-1;assigned.add(op)
            key=previous;t-=1
        assert len(assigned)==2*n
        s=lift_zero_operations(ctx,order,s);assert s is not None
        for j,a in grid.nodes:
            assert all(s[j][a]>=s[p][b]+ctx.durations[p][b] for p,b in grid.parents[j,a])
        return s
    tables=None;bound_stats={'build_seconds':0.0,'entries':0,'finite_entries':0};bound_preparation_complete=True
    if upper_value and bound_mode=='residual':
        tick=time.perf_counter()
        try:tables,bound_stats=relaxed_tables(ctx,order,pair,lower,upper,stages,background,deadline)
        except TimeoutError:
            complete=False;stop='deadline_in_bound_preparation';bound_preparation_complete=False
            bound_stats['build_seconds']=time.perf_counter()-tick
    def lower_bound(t,key):
        value=suffix[t]
        if tables is not None:
            x=unpack(key)
            for slot in range(2):
                part=tables[slot][t][x[slot]]
                if part is None:return None
                value+=part
        return value
    if upper_value==0:stop='nonnegative_objective_zero_upper'
    elif not bound_preparation_complete:pass
    else:
        for t in range(h+1):
            normalized={}
            for key,cost in sorted(current.items()):
                if deadline is not None and time.perf_counter()>=deadline:
                    complete=False;stop='deadline';break
                future=lower_bound(t,key)
                if future is None or cost+future>=upper_value:continue
                norm=normalize(key,t)
                if norm is None:continue
                normalized_count+=1;x=unpack(norm[0])
                if all(x[k]==stages[k]['end'] for k in range(2)):
                    value=cost+suffix[t]
                    if value<upper_value:
                        candidate=reconstruct(t,key)
                        assert load_functional(ctx,gross_profile(ctx,candidate))==value
                        if deadline is not None and time.perf_counter()>=deadline:
                            complete=False;stop='deadline_during_incumbent_reconstruction';break
                        best,upper_value=candidate,value
                        event={'score_numerator':value,'starts':candidate,'available_seconds':time.perf_counter()-begun}
                        events.append(event)
                        if on_improvement is not None:on_improvement([list(row) for row in candidate],value)
                    continue
                existing=normalized.get(norm[0])
                if existing is None or cost<existing[0]:normalized[norm[0]]=(cost,key)
            if not complete:break
            if t==h:break
            following={};back={}
            for key,(cost,rawkey) in sorted(normalized.items()):
                if deadline is not None and time.perf_counter()>=deadline:
                    complete=False;stop='deadline';break
                expanded+=1;x=unpack(key)
                for left,right in itertools.product(choices(0,x[0],t,x),choices(1,x[1],t,x)):
                    transitions+=1
                    q=background[t]+left[0]+right[0]
                    value=cost+ctx.carbon[t]*max(q-ctx.renewable[t],0)
                    nxt=left[1]*width+right[1]
                    future=lower_bound(t+1,nxt)
                    if future is None or value+future>=upper_value:continue
                    if nxt not in following:
                        if generated>=state_limit:complete=False;stop='state_limit';break
                        generated+=1
                    if nxt not in following or value<following[nxt]:
                        following[nxt]=value;back[nxt]=(rawkey,left[2]+2*right[2])
                if not complete:break
            if not complete:break
            current=following;parents.append(back)
            if not current:break
    assert upper_value<=initial_value and load_functional(ctx,gross_profile(ctx,best))==upper_value
    if deadline is not None and time.perf_counter()>=deadline:
        complete=False;stop='deadline_before_return'
    return {'starts':best,'score_numerator':upper_value,'score_fraction':str(F(upper_value,ctx.denominator)),
            'initial_score_numerator':initial_value,'machines':list(pair),'complete':complete,'stop':stop,
            'states_generated':generated,'states_expanded':expanded,'normalized_states_processed':normalized_count,
            'transitions_considered':transitions,'improvements':events,'elapsed_seconds':time.perf_counter()-begun,
            'scope':'selected_positive_machine_chains_all_zero_nodes_free_exterior_positive_starts_and_permutation_fixed',
            'variable_positive_machines':sorted(selected),'all_zero_nodes_free':True,
            'bound_mode':bound_mode,'bound_preparation_complete':bound_preparation_complete,
            'bound_build_seconds':bound_stats['build_seconds'],'bound_entries':bound_stats['entries'],
            'bound_finite_entries':bound_stats['finite_entries'],
            'bound_certificate':({'tables':tables,**bound_stats} if capture_bound_certificate else None),
            'incomplete_run_provides_no_global_lower_bound_or_optimality_claim':True}
