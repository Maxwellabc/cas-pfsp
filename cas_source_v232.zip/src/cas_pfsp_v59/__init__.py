"""Residual-supply bounds and charged joint timing research."""
