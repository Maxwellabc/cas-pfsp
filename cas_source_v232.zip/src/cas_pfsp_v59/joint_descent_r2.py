"""Declared projected single/pair first-improvement timing descent.

Pairs are lexicographic,not retrospectively chosen. Every strict intermediate
incumbent observed before the deadline is retained,even from incomplete calls.
Locality is reported only after an entire unchanged scan completes exactly.
No timing feedback is injected into the native permutation population.
"""
from fractions import Fraction as F
import itertools,time
from cas_pfsp_v47.pair_timing import gross_profile,load_functional
from cas_pfsp_v59.projected_machine_dp import best_response
from cas_pfsp_v57.chain_dp_certificate import best_response as single_machine_response

def refine(ctx,order,initial,deadline,started,events,maximum_passes=32,state_limit=2_000_000):
    m=len(ctx.powers[0]);current=[list(row) for row in initial]
    score=load_functional(ctx,gross_profile(ctx,current));calls=[];accepted=0;local=False
    sequence=[]
    if m==1:sequence=[('single_machine',(0,),())]
    else:
        for a in range(m):
            dummy=next(b for b in range(m) if b!=a)
            sequence.append(('projected_single',tuple(sorted((a,dummy))),(dummy,)))
        sequence.extend(('projected_pair',pair,()) for pair in itertools.combinations(range(m),2))
    def retain(s,value,call_index,kind):
        nonlocal current,score,accepted
        observed=time.perf_counter()
        if observed>=deadline or value>=score:return
        assert load_functional(ctx,gross_profile(ctx,s))==value
        registered=time.perf_counter()
        if registered>=deadline:return
        current=[list(row) for row in s];score=value;accepted+=1
        events.append({'elapsed_seconds':registered-started,'source':'projected_joint_refinement',
          'permutation':list(order),'starts':[list(row) for row in current],'score_fraction':str(F(score,ctx.denominator)),
          'move':{'kind':kind,'call_index':call_index}})
    stop='pass_cap_without_locality'
    for turn in range(maximum_passes):
        changed=False
        for kind,pair,fixed in sequence:
            if time.perf_counter()>=deadline:stop='deadline_before_neighborhood';break
            call_index=len(calls);base=score;before=[list(row) for row in current];tick=time.perf_counter()
            try:
                if m==1:
                    result=single_machine_response(ctx,order,before,'machine',0,deadline=deadline)
                    retain(result['starts'],result['score_numerator'],call_index,kind)
                    complete=True
                else:
                    result=best_response(ctx,order,before,pair,deadline=deadline,state_limit=state_limit,
                      fixed_positive_machines=fixed,bound_mode=('background' if fixed else 'residual'),
                      on_improvement=lambda s,v:retain(s,v,call_index,kind))
                    complete=result['complete']
            except TimeoutError:
                calls.append({'pass':turn,'kind':kind,'machines':list(pair),'fixed_positive_machines':list(fixed),
                  'initial':before,'complete':False,'accepted':score<base,'seconds':time.perf_counter()-tick,
                  'result':None,'stop':'deadline_before_or_inside_single_machine_call'})
                stop='incomplete_neighborhood';break
            calls.append({'pass':turn,'kind':kind,'machines':list(pair),'fixed_positive_machines':list(fixed),
              'initial':before,'complete':complete,'accepted':score<base,'seconds':time.perf_counter()-tick,'result':result})
            if not complete:stop='incomplete_neighborhood';break
            if score<base:changed=True;break
            if time.perf_counter()>=deadline:stop='deadline_after_neighborhood';break
        else:local=True;stop='completed_projected_machine_single_pair_local';break
        if not changed:break
    assert load_functional(ctx,gross_profile(ctx,current))==score
    return {'starts':current,'score_fraction':str(F(score,ctx.denominator)),'local':local,'stop':stop,
      'calls':calls,'accepted_moves':accepted,'maximum_passes':maximum_passes,'arm':'ma_joint',
      'state_limit_per_product_call':state_limit,'pair_selection':'singles_by_machine_then_lexicographic_pairs_first_improvement',
      'all_zero_nodes_free_for_product_calls':True,'no_job_chain_locality_claim':True}
