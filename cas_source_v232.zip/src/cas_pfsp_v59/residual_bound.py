"""Admissible independent-chain future values for a shared renewable hinge."""
import time

def relaxed_tables(ctx,order,pair,lower,upper,stages,background,deadline=None):
    begun=time.perf_counter();h=ctx.horizon;n=len(order)
    residual=[max(ctx.renewable[t]-background[t],0) for t in range(h)]
    tables=[];entries=finite=0
    for slot,a in enumerate(pair):
        rows=stages[slot]['rows'];ids=stages[slot]['ids'];end=stages[slot]['end']
        values=[[None]*len(rows) for _ in range(h+1)]
        for t in range(h,-1,-1):
            if deadline is not None and time.perf_counter()>=deadline:raise TimeoutError('deadline_in_bound_preparation')
            values[t][end]=0;entries+=1;finite+=1
            for k in range(end-1,-1,-1):
                if k%256==0 and deadline is not None and time.perf_counter()>=deadline:raise TimeoutError('deadline_in_bound_preparation')
                i,r=rows[k];j=order[i];op=ctx.powers[j][a];d=len(op);options=[]
                if not d:
                    if lower[j,a]<=t<=upper[j,a]:
                        value=values[t][ids[i+1,0]]
                        if value is not None:options.append(value)
                    elif t<lower[j,a] and t<h:
                        value=values[t+1][k]
                        if value is not None:options.append(value)
                elif r==0 and t<=upper[j,a]:
                    if t<h:
                        if values[t+1][k] is not None:options.append(values[t+1][k])
                        if t>=lower[j,a]:
                            nxt=ids[i,r+1] if r+1<d else ids[i+1,0]
                            value=values[t+1][nxt]
                            if value is not None:options.append(ctx.carbon[t]*max(op[r]-residual[t],0)+value)
                elif r>0 and t<h and lower[j,a]<=t-r<=upper[j,a]:
                    nxt=ids[i,r+1] if r+1<d else ids[i+1,0]
                    value=values[t+1][nxt]
                    if value is not None:options.append(ctx.carbon[t]*max(op[r]-residual[t],0)+value)
                values[t][k]=min(options) if options else None
                entries+=1;finite+=values[t][k] is not None
        tables.append(values)
    return tables,{'build_seconds':time.perf_counter()-begun,'entries':entries,'finite_entries':finite,
                   'residual_supply':residual,
                   'windows':[[[lower[j,a],upper[j,a]] for j in order] for a in pair]}
