"""A fresh model per repair, copied from one base paid for within this run."""
from dataclasses import replace
import hashlib
from cas_pfsp_v118.compact_reference import build
from cas_pfsp_v146.extraction import operation_extraction,machine_extraction,job_extraction
from cas_pfsp_v152.history_model import permutation,HistoryModel


class ModelCache:
    def __init__(self,instance,checkpoint=lambda phase:None):
        checkpoint('cache_base_begin');self.instance=instance;self.base=build(instance,checkpoint=checkpoint)
        self.n,self.m,self.h=instance.n,instance.m,instance.horizon;self.d=instance.durations
        self.positive=[[j,a] for j in range(self.n) for a in range(self.m) if self.d[j][a]]
        self.base_variables=len(self.base.model.proto.variables);self.base_constraints=len(self.base.model.proto.constraints)
        self.clones_completed=0;checkpoint('cache_base_complete')

    def fingerprint(self):
        """Private integrity observation;not an unpaid runtime search input."""
        return hashlib.sha256(str(self.base.model.proto).encode()).hexdigest()

    def clone(self,proposal,checkpoint=lambda phase:None):
        checkpoint('cache_clone_begin');order=permutation(proposal['anchor_permutation'],self.n)
        kind=proposal['kind'];pairs=[]
        if kind=='rank':
            if proposal.get('free') is not None:raise ValueError('Rank-only extraction requires free=None')
            for pair in proposal['rank_pairs']:
                if not isinstance(pair,(list,tuple)) or len(pair)!=2 or any(type(j) is not int for j in pair) or not all(0<=j<self.n for j in pair) or pair[0]==pair[1]:raise ValueError('Distinct valid integer rank pair required')
                pairs.append(list(pair))
            if len(set(map(tuple,pairs)))!=len(pairs):raise ValueError('Duplicate rank pair')
            extraction={'kind':'rank_only_history_extraction','anchor_order':order,'preserved_operation_precedences':[],
                        'forced_rank_pairs':[],'extra_explicit_rank_pairs':[],'fixed_operation_starts':[]}
        else:
            methods={'operation':operation_extraction,'machine':machine_extraction,'job':job_extraction}
            if kind not in methods:raise ValueError('Unknown history extraction kind')
            if proposal.get('rank_pairs') not in (None,[]):raise ValueError('Unexpected extra rank pairs for non-rank extraction')
            extraction=methods[kind](order,self.d,proposal['free'],checkpoint)
        expected=set(map(tuple,self.positive));features=proposal.get('tabu_positive_features',[])
        if not isinstance(features,(list,tuple)):raise ValueError('History feature sequence required')
        rows=[];ids=[];unique=set()
        for feature in features:
            checkpoint('cache_history_feature');ident=feature['attempt_id']
            if type(ident) is not int or ident<0 or ident in ids:raise ValueError('Distinct nonnegative history IDs required')
            prior=permutation(feature['permutation'],self.n);positions=[prior.index(j) for j in range(self.n)];starts={}
            for triple in feature['positive_starts']:
                if not isinstance(triple,(list,tuple)) or len(triple)!=3 or any(type(x) is not int for x in triple):raise ValueError('Integer positive-start triples required')
                j,a,start=triple
                if (j,a) not in expected or (j,a) in starts:raise ValueError('Duplicate or nonpositive history operation')
                if not 0<=start<=self.h-self.d[j][a]:raise ValueError('History start outside horizon')
                starts[j,a]=start
            if set(starts)!=expected:raise ValueError('Every positive operation must appear in history')
            values=tuple(positions+[starts[j,a] for j,a in self.positive]);ids.append(ident)
            if values not in unique:unique.add(values);rows.append(list(values))
        checkpoint('cache_before_native_clone');model=self.base.model.clone()
        def rebind(var):
            checkpoint('cache_variable_rebind');return model.get_int_var_from_proto_index(var.index)
        built=replace(self.base,model=model,ranks=[rebind(v) for v in self.base.ranks],
            starts=[[rebind(v) for v in line] for line in self.base.starts],digits=[rebind(v) for v in self.base.digits],
            arithmetic=dict(self.base.arithmetic))
        for i,j,a in extraction['preserved_operation_precedences']:
            checkpoint('cache_extraction_time_edge');model.add(built.starts[i][a]+self.d[i][a]<=built.starts[j][a])
        for i,j in extraction['forced_rank_pairs']+extraction['extra_explicit_rank_pairs']+pairs:
            checkpoint('cache_extraction_rank_edge');model.add(built.ranks[i]<built.ranks[j])
        if rows:
            checkpoint('cache_before_tabu_table');model.add_forbidden_assignments(list(built.ranks)+[built.starts[j][a] for j,a in self.positive],rows)
        checkpoint('cache_clone_validation');error=model.validate()
        if error:raise ValueError('Cached history model validation:'+error)
        assert len(self.base.model.proto.variables)==self.base_variables and len(self.base.model.proto.constraints)==self.base_constraints
        checkpoint('cache_clone_complete');self.clones_completed+=1
        return HistoryModel(built,extraction,pairs,[x[:] for x in self.positive],rows,ids)
