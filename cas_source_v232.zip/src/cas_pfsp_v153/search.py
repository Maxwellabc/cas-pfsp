"""Experimental complete carbon-aware CP-ALNS with one paid root clock.

This adapts published mechanisms;it is not original source-code reproduction.
Only actually registered,globally timely physical points are returned. Model
setup/cloning,hints,callbacks,policy and logging are charged. Backend imports
and final JSON export are outside core,as in the other frozen frontends.
"""
from fractions import Fraction as F
from pathlib import Path
import math
import random
import time
from ortools.sat.python import cp_model
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v64.registry import PhysicalRegistry
from cas_pfsp_v76.search import PhaseSearch
from cas_pfsp_v116.timed import Budget,Expired,Collector
from cas_pfsp_v151.policy import AdaptivePolicy,OPERATORS
from .cached_model import ModelCache


class SliceExpired(Exception):pass


def point_key(point):
    return tuple(point['permutation']),tuple(v for row in point['starts'] for v in row),point['score_fraction']


def attempt_id(registry,point):
    return next(i for i,row in enumerate(registry.attempts) if row is point)


def unrestricted(order):
    return {'kind':'rank','free':None,'anchor_permutation':list(order),'rank_pairs':[],'tabu_positive_features':[]}


class RootCollector(Collector):
    def __init__(self,built,budget,registry,cache,stage,local_cutoff):
        super().__init__(built,budget,registry,cache,stage)
        self.local_cutoff=local_cutoff;self.stops_after_local_cutoff=0;self.stops_at_nonnegative_zero=0

    def on_solution_callback(self):
        if self.budget.now()>=self.budget.deadline:
            self.skipped_after_deadline+=1;self.stop_search();return
        self.record(self,'CP_solution_callback')
        if self.registry.best_value==0:
            self.stops_at_nonnegative_zero+=1;self.stop_search();return
        now=self.budget.now()
        if now>=self.local_cutoff:
            self.stops_after_local_cutoff+=1;self.stop_search()
        elif now>=self.budget.deadline:self.stop_search()


def window(model_cache,proposal,hint_id,budget,registry,cache,windows,mode,seconds):
    start=budget.now();cutoff=budget.deadline if seconds is None else min(budget.deadline,start+float(seconds))
    row={'id':len(windows),'mode':mode,'proposal':proposal,'paid_hint_attempt_id':hint_id,
        'started_seconds':start-budget.started,'slice_deadline_seconds':cutoff-budget.started,
        'slice_allocation_seconds':None if seconds is None else float(seconds),
        'registration_attempts_before':len(registry.attempts),'stages':[],
        'proved_optimal_prefix':[],'neighborhood_proved_optimal':False,
        'restricted_infeasibility_proved':False,'stop':None,'model_ready_seconds':None,
        'hint_assignments_added':0,'hints_complete':False,'candidate_attempt_ids':[]}
    windows.append(row);built=None;last_integer=None
    def poll(phase):
        budget.poll(phase)
        if budget.now()>=cutoff:raise SliceExpired(phase)
    try:
        poll('before_cached_neighborhood');result=model_cache.clone(proposal,poll);built=result.physical
        row.update(model_ready_seconds=budget.now()-budget.started,positive_operations=result.positive_operations,
            tabu_values=result.tabu_values,tabu_attempt_ids=result.tabu_attempt_ids,
            extraction=result.extraction,added_rank_pairs=result.rank_pairs,
            objective_base=built.base,objective_digits=len(built.digits),objective_denominator=str(built.objective_denominator))
        if hint_id is not None:
            anchor=registry.attempts[hint_id];assert anchor['eligible']
            for position,job in enumerate(anchor['permutation']):
                poll('paid_rank_hint');built.model.add_hint(built.ranks[job],position);row['hint_assignments_added']+=1
            for j,line in enumerate(built.starts):
                for a,var in enumerate(line):
                    poll('paid_start_hint');built.model.add_hint(var,anchor['starts'][j][a]);row['hint_assignments_added']+=1
            row['hints_complete']=True
        for level in reversed(range(len(built.digits))):
            poll('before_digit_objective');built.model.minimize(built.digits[level])
            solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.random_seed=0
            solver.parameters.cp_model_presolve=True;solver.parameters.absolute_gap_limit=0;solver.parameters.relative_gap_limit=0
            poll('before_CP_solve');called=budget.now();remaining=cutoff-called
            if remaining<=0:raise SliceExpired('before_CP_solve')
            solver.parameters.max_time_in_seconds=remaining
            collector=RootCollector(built,budget,registry,cache,level,cutoff)
            stage={'digit':level,'call_started_seconds':called-budget.started,'native_time_limit_seconds':remaining,
                'native_status':None,'returned_seconds':None,'events':collector.events,
                'proof_used':False,'proof_ready_seconds':None,'optimal_digit_value':None,
                'final_assignment_read_after_local_cutoff':False}
            row['stages'].append(stage);status=solver.solve(built.model,collector);returned=budget.now()
            stage.update(native_status=solver.status_name(status),returned_seconds=returned-budget.started,
                callbacks_skipped_after_global_deadline=collector.skipped_after_deadline,
                callback_stops_after_local_cutoff=collector.stops_after_local_cutoff,
                callback_stops_at_nonnegative_zero=collector.stops_at_nonnegative_zero)
            if status not in (cp_model.OPTIMAL,cp_model.FEASIBLE,cp_model.INFEASIBLE,cp_model.UNKNOWN):
                raise RuntimeError('Invalid native CP status:'+stage['native_status'])
            if returned>=budget.deadline:row['stop']='global_budget_after_CP_return';break
            if status==cp_model.INFEASIBLE:
                assert not row['proved_optimal_prefix'] and not any(s['events'] for s in row['stages']), 'Nonempty proved prefix became infeasible'
                poll('before_restricted_infeasibility_proof');ready=budget.now()
                stage.update(proof_ready_seconds=ready-budget.started,proof_used=ready<=cutoff and ready<=budget.deadline)
                row['restricted_infeasibility_proved']=stage['proof_used'];row['stop']='restricted_model_infeasible' if stage['proof_used'] else 'late_infeasibility_proof';break
            if status in (cp_model.OPTIMAL,cp_model.FEASIBLE):
                # Locally late but globally timely work may improve the root.
                # Such final reads never donate a local optimality certificate.
                budget.poll('before_CP_final_registration');stage['final_assignment_read_after_local_cutoff']=budget.now()>=cutoff
                last_integer,_=collector.record(solver,'CP_final_assignment')
                budget.poll('after_CP_final_registration')
            if budget.now()>=cutoff:row['stop']='slice_after_CP_return_or_registration';break
            if status==cp_model.UNKNOWN:row['stop']='native_unknown';break
            if status!=cp_model.OPTIMAL:row['stop']='native_feasible_without_digit_proof';break
            poll('before_digit_proof_pin');value=int(solver.value(built.digits[level]));stage['optimal_digit_value']=value
            built.model.add(built.digits[level]==value);ready=budget.now()
            stage.update(proof_ready_seconds=ready-budget.started,proof_used=ready<=cutoff and ready<=budget.deadline)
            if not stage['proof_used']:row['stop']='late_digit_proof';break
            row['proved_optimal_prefix'].append({'digit':level,'value':value,'ready_seconds':ready-budget.started})
        else:
            row['neighborhood_proved_optimal']=True;row['stop']='all_neighborhood_digits_proved'
    except SliceExpired as error:row['stop']='slice_at_'+str(error)
    except Expired as error:row['stop']='global_budget_at_'+str(error);raise
    finally:
        ids=[]
        for stage in row['stages']:
            for event in stage['events']:
                ident=event['attempt_id']
                if registry.attempts[ident]['eligible'] and ident not in ids:ids.append(ident)
        row.update(candidate_attempt_ids=ids,returned_seconds=budget.now()-budget.started,
            registration_attempts_after=len(registry.attempts),
            best_after_attempt_id=None if registry.best is None else attempt_id(registry,registry.best))
        if row['neighborhood_proved_optimal']:
            assert ids and last_integer is not None
            assert min(F(registry.attempts[i]['score_fraction']) for i in ids)==F(last_integer,built.objective_denominator)
    return row


def feed(policy,registry,ids,budget,events,source_window):
    for ident in ids:
        budget.poll('before_policy_offer');point=registry.attempts[ident];assert point['eligible']
        before=policy.snapshot();outcome=policy.offer(point,ident)
        events.append({'source_window_id':source_window,'attempt_id':ident,'before':before,'outcome':outcome,
                       'after':policy.snapshot(),'ready_seconds':budget.now()-budget.started})


def run_budgeted(loader,budget_seconds,seed=0,phase_fraction=.5,phase_max_evaluations=None,
                 max_iterations=None,forced_operator=None,diagnostic_slice_seconds=None,
                 policy_parameters=None,clock=time.perf_counter):
    if not math.isfinite(budget_seconds) or budget_seconds<=0:raise ValueError('Positive finite core budget required')
    if not math.isfinite(phase_fraction) or not 0<phase_fraction<1 or type(seed) is not int:raise ValueError('Valid phase fraction/integer seed required')
    for value in [phase_max_evaluations,max_iterations]:
        if value is not None and (type(value) is not int or value<1):raise ValueError('Positive integer diagnostic quota required')
    if forced_operator is not None and forced_operator not in OPERATORS:raise ValueError('Unknown diagnostic operator')
    if diagnostic_slice_seconds is not None and (not math.isfinite(diagnostic_slice_seconds) or diagnostic_slice_seconds<=0):raise ValueError('Positive finite diagnostic slice required')
    if policy_parameters is not None and not isinstance(policy_parameters,dict):raise ValueError('Policy options must be a dictionary')
    budget=Budget(float(budget_seconds),clock);cpu=time.process_time();rng=random.getstate()
    physical=ctx=registry=policy=model_cache=None;phase_out=None;setup={};cache={};windows=[];iterations=[]
    initial_policy=None;reason=None;policy_events=[]
    try:
        budget.poll('before_input_load');physical=loader();setup['input_loaded_seconds']=budget.now()-budget.started
        budget.poll('after_input_load');ctx=make_context(physical);setup['context_ready_seconds']=budget.now()-budget.started
        registry=PhysicalRegistry(ctx,budget.started,budget.deadline,clock=budget.now)
        budget.poll('before_phase_component')
        phase=PhaseSearch(ctx,budget.started,budget.started+phase_fraction*budget_seconds,'t1p1',seed,
                          clock=budget.now,max_evaluations=phase_max_evaluations)
        phase.registry=registry;phase_out=phase.run();phase_out.pop('registered_attempts');phase_best=phase_out.pop('best_registered')
        phase_out.update(physical_registry_attempt_range=[0,len(registry.attempts)],
            best_registered_attempt_id=None if phase_best is None else attempt_id(registry,phase_best),
            shared_root_physical_registry=True,returned_to_composition_seconds=budget.now()-budget.started)
        budget.poll('after_phase_component')
        if registry.best_value==0:reason='nonnegative_zero_attained'
        else:
            for i,point in enumerate(registry.attempts):
                budget.poll('paid_phase_cache_entry')
                if point['eligible']:cache.setdefault(point_key(point),i)
            budget.poll('before_paid_base_model')
            setup['base_model_started_seconds']=budget.now()-budget.started
            try:model_cache=ModelCache(physical,checkpoint=budget.poll)
            except ValueError as error:
                if str(error)!='Conservative CP-SAT int64 arithmetic guard exceeded':raise
                reason='unsupported_base_exact_integer_range'
            if model_cache is not None:
                setup.update(base_model_ready_seconds=budget.now()-budget.started,
                    base_variables=model_cache.base_variables,base_constraints=model_cache.base_constraints)
                if registry.best is None:
                    window(model_cache,unrestricted(range(physical.n)),None,budget,registry,cache,windows,'fallback_initializer',None)
                    budget.poll('after_CP_fallback_initializer')
                if registry.best is None:reason='no_paid_feasible_initializer'
                elif registry.best_value==0:reason='nonnegative_zero_attained'
                else:
                    policy=AdaptivePolicy(physical.durations,physical.horizon,seed=seed,checkpoint=budget.poll,**(policy_parameters or {}))
                    initial_id=attempt_id(registry,registry.best);before=policy.snapshot();outcome=policy.offer(registry.best,initial_id)
                    initial_policy={'attempt_id':initial_id,'before':before,'outcome':outcome,'after':policy.snapshot(),
                                    'ready_seconds':budget.now()-budget.started}
                    while True:
                        budget.poll('before_adaptive_iteration')
                        if registry.best_value==0:reason='nonnegative_zero_attained';break
                        if policy.stagnation>=policy.stagnation_limit:reason='stagnation_limit';break
                        if max_iterations is not None and len(iterations)>=max_iterations:reason='diagnostic_iteration_quota';break
                        row={'id':len(iterations),'started_seconds':budget.now()-budget.started,'policy_before':policy.snapshot(),
                            'selection':None,'repair_window_id':None,'improvement_window_id':None,
                            'policy_event_range_start':len(policy_events),'finish':None,'policy_after':None}
                        iterations.append(row);before_score=F(registry.best['score_fraction'])
                        selection=policy.begin_iteration(forced_operator);row['selection']=selection
                        row['selection_ready_seconds']=budget.now()-budget.started
                        seconds=float(policy.theta) if diagnostic_slice_seconds is None else diagnostic_slice_seconds
                        hint_id=policy.current.attempt_id
                        repair=window(model_cache,selection,hint_id,budget,registry,cache,windows,'repair',seconds)
                        row['repair_window_id']=repair['id'];feed(policy,registry,repair['candidate_attempt_ids'],budget,policy_events,repair['id'])
                        candidates=repair['candidate_attempt_ids']
                        current=None if not candidates else min(candidates,key=lambda i:(F(registry.attempts[i]['score_fraction']),i))
                        if F(registry.best['score_fraction'])<before_score and registry.best_value!=0:
                            budget.poll('before_unrestricted_improvement');anchor=attempt_id(registry,registry.best)
                            improve=window(model_cache,unrestricted(registry.best['permutation']),anchor,budget,registry,cache,windows,'unrestricted_improvement',seconds)
                            row['improvement_window_id']=improve['id']
                            feed(policy,registry,improve['candidate_attempt_ids'],budget,policy_events,improve['id'])
                            # Paid original-feasible anchor remains a valid fallback
                            # only in this unrestricted improvement phase.
                            current=min([anchor]+improve['candidate_attempt_ids'],key=lambda i:(F(registry.attempts[i]['score_fraction']),i))
                            row['unrestricted_paid_anchor_fallback_id']=anchor
                        budget.poll('before_policy_finish')
                        row['proposed_current_attempt_id']=current
                        row['finish']=policy.finish_iteration(current,proved_optimal=repair['neighborhood_proved_optimal'])
                        row.update(policy_after=policy.snapshot(),policy_event_range_end=len(policy_events),
                            finished_seconds=budget.now()-budget.started,best_after_attempt_id=attempt_id(registry,registry.best))
    except Expired as error:reason='global_budget_at_'+str(error)
    assert random.getstate()==rng
    best=None if registry is None else registry.best;zero=best is not None and F(best['score_fraction'])==0
    elapsed=budget.now()-budget.started
    return {'status':'OPTIMAL' if zero else 'FEASIBLE' if best is not None else 'UNKNOWN',
        'stop_reason':reason,'seed':seed,'budget_seconds':budget_seconds,'phase_fraction':phase_fraction,
        'phase_max_evaluations':phase_max_evaluations,'max_iterations':max_iterations,'forced_operator':forced_operator,
        'diagnostic_slice_seconds':diagnostic_slice_seconds,'policy_parameters':policy_parameters,
        'diagnostic_options_used':any(v is not None for v in [phase_max_evaluations,max_iterations,forced_operator,diagnostic_slice_seconds,policy_parameters]),
        'setup':setup,'phase_component':phase_out,'policy_initialization':initial_policy,
        'windows':windows,'iterations':iterations,'policy_events':policy_events,
        'policy_final':None if policy is None else policy.snapshot(),
        'registered_attempts':[] if registry is None else registry.attempts,'best_registered':best,
        'registration_seconds':0. if registry is None else registry.registration_seconds,
        'input_sha256':None if physical is None else physical.input_sha256,
        'base_models_built':int(model_cache is not None),
        'within_run_clones_completed':0 if model_cache is None else model_cache.clones_completed,
        'algorithm_wall_seconds':elapsed,'algorithm_cpu_seconds':time.process_time()-cpu,
        'overshoot_seconds':max(0.,elapsed-budget_seconds),'checkpoint_counts':budget.polls,'last_checkpoint':budget.last_phase,
        'zero_global_objective_certified':zero,'positive_global_optimum_or_original_infeasibility_claim':False,
        'global_Python_RNG_unchanged':True,'donated_initializer_or_external_model_cache':False,
        'base_model_built_once_inside_root_clock':True,'selection_and_postsolve_policy_charged_to_root':True,
        'local_slice_covers_clone_binding_hints_solver_registration_and_proof_work':True,
        'globally_timely_local_overrun_incumbents_retained_without_local_proof_donation':True,
        'root_eligibility':'available_seconds<=budget_seconds',
        'hard_return_deadline_guaranteed':False,'original_published_source_code_reproduced':False,
        'complete_paid_policy_public_runtime_or_gain_qualified':False}


def run_file(path,budget_seconds,**kwargs):
    path=Path(path).resolve()
    if 'neso_' in str(path).lower():raise ValueError('Reserved path before content access')
    return run_budgeted(lambda:load_instance(path),budget_seconds,**kwargs)
