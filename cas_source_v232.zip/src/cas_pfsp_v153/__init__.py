"""Complete experimental adapted CP-ALNS; public qualification remains pending."""
