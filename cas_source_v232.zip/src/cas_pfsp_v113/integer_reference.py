"""Global common-permutation CAS model with exactly scaled integer coefficients.

This is a standard reference formulation, not a new scheduling method. The
solver limit covers solver work only; it is not an end-to-end budget contract.
No float-valued response bound is exposed as a rational certificate.
"""
from dataclasses import dataclass
from fractions import Fraction as F
import itertools
import math
import time
from cas_pfsp_v45.model import validate_instance
from cas_pfsp_v45.timestep_accounting_r1 import check_benchmark_schedule

LIMIT = 2**60


def exact(value):
    if type(value) not in (int, F):
        raise ValueError('Exact integer or Fraction coefficients required')
    return F(value)


@dataclass
class Built:
    model: object
    instance: object
    ranks: list
    starts: list
    grid: list
    carbon_integer: list
    power_scale: int
    objective_denominator: int
    arithmetic: dict


def build(instance, optimize=True):
    validate_instance(instance)
    n, m, h, d = instance.n, instance.m, instance.horizon, instance.durations
    powers = [[[exact(v) for v in op] for op in job] for job in instance.powers]
    renewable = [exact(v) for v in instance.renewable]
    carbon = [exact(v) for v in instance.carbon]
    power_scale = math.lcm(1, *(v.denominator for job in powers for op in job for v in op),
                           *(v.denominator for v in renewable))
    carbon_scale = math.lcm(1, *(v.denominator for v in carbon))
    p = [[[int(v * power_scale) for v in op] for op in job] for job in powers]
    r = [int(v * power_scale) for v in renewable]
    c = [int(v * carbon_scale) for v in carbon]
    cap = sum(max(op, default=0) for job in p for op in job)
    coefficient_mass = sum(max(0, h - sum(d[j]) + 1) * sum(p[j][a])
                           for j in range(n) for a in range(m))
    bounds = {'gross_upper_bound': cap, 'objective_upper_bound': cap * sum(c),
              'convolution_coefficient_mass': coefficient_mass,
              'maximum_carbon_coefficient': max(c, default=0), 'horizon': h}
    if any(v > LIMIT for v in bounds.values()):
        raise ValueError('Conservative CP-SAT int64 arithmetic guard exceeded')
    from ortools.sat.python import cp_model
    model = cp_model.CpModel()
    ranks = [model.new_int_var(0, n - 1, f'rank_{j}') for j in range(n)]
    model.add_all_different(ranks)
    starts = [[model.new_int_var(0, h, f'start_{j}_{a}') for a in range(m)] for j in range(n)]
    choices = {}
    for j, a in itertools.product(range(n), range(m)):
        lo, hi = sum(d[j][:a]), h - sum(d[j][a:])
        model.add(starts[j][a] >= lo)
        model.add(starts[j][a] <= hi)
        if a + 1 < m:
            model.add(starts[j][a + 1] >= starts[j][a] + d[j][a])
        if d[j][a]:
            choices[j, a] = {s: model.new_bool_var(f'at_{j}_{a}_{s}') for s in range(lo, hi + 1)}
            model.add_exactly_one(choices[j, a].values())
            model.add(starts[j][a] == sum(s * x for s, x in choices[j, a].items()))
    for i, j in itertools.combinations(range(n), 2):
        before = model.new_bool_var(f'before_{i}_{j}')
        model.add(ranks[i] < ranks[j]).only_enforce_if(before)
        model.add(ranks[i] > ranks[j]).only_enforce_if(~before)
        for a in range(m):
            model.add(starts[j][a] >= starts[i][a] + d[i][a]).only_enforce_if(before)
            model.add(starts[i][a] >= starts[j][a] + d[j][a]).only_enforce_if(~before)
    grid = []
    for t in range(h):
        load = model.new_int_var(0, cap, f'load_{t}')
        terms = [p[j][a][t - s] * x for (j, a), at in choices.items()
                 for s, x in at.items() if 0 <= t - s < d[j][a] and p[j][a][t - s]]
        model.add(load == sum(terms))
        g = model.new_int_var(0, cap, f'grid_{t}')
        # Clipping supply at a valid demand upper bound is exact and avoids
        # oversized irrelevant constants when renewable supply dominates load.
        model.add_max_equality(g, [0, load - min(r[t], cap)])
        grid.append(g)
    if optimize:
        model.minimize(sum(v * g for v, g in zip(c, grid)))
    error = model.validate()
    if error:
        raise ValueError('CP-SAT model validation: ' + error)
    return Built(model, instance, ranks, starts, grid, c, power_scale,
                 4 * power_scale * carbon_scale, bounds)


def certificate(built, reader):
    positions = [reader.value(v) for v in built.ranks]
    assert sorted(positions) == list(range(len(positions)))
    order = sorted(range(len(positions)), key=positions.__getitem__)
    starts = [[reader.value(v) for v in row] for row in built.starts]
    integer_objective = sum(c * reader.value(g) for c, g in zip(built.carbon_integer, built.grid))
    score = F(integer_objective, built.objective_denominator)
    receipt = check_benchmark_schedule(built.instance, order, starts)
    assert F(receipt['benchmark_score_fraction']) == score
    return {'permutation': order, 'starts': starts, 'scaled_integer_objective': integer_objective,
            'physical_score_fraction': str(score)}


def solve(instance, solver_seconds=30.0, presolve=True):
    if not math.isfinite(solver_seconds) or solver_seconds <= 0:
        raise ValueError('Positive finite solver-time limit required')
    started = time.perf_counter()
    built = build(instance)
    from ortools.sat.python import cp_model
    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    solver.parameters.random_seed = 0
    solver.parameters.cp_model_presolve = bool(presolve)
    solver.parameters.max_time_in_seconds = solver_seconds
    solver.parameters.absolute_gap_limit = 0
    solver.parameters.relative_gap_limit = 0
    ready = time.perf_counter()
    status = solver.solve(built.model)
    result = {'status': solver.status_name(status), 'presolve': bool(presolve),
        'solver_time_limit_seconds': solver_seconds,
        'build_seconds_including_imports': ready - started,
        'solver_and_export_seconds': None, 'certificate': None,
        'power_scale': built.power_scale, 'objective_denominator': built.objective_denominator,
        'arithmetic': built.arithmetic, 'float_bound_used_as_exact_certificate': False,
        'end_to_end_wall_budget_qualified': False,
        'scope': 'standard global integer reference; no novelty or public-performance claim'}
    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        result['certificate'] = certificate(built, solver)
    result['solver_and_export_seconds'] = time.perf_counter() - ready
    return result
