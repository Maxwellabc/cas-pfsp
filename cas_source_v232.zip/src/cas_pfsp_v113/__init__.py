"""Private qualification of a standard integer CP-SAT reference."""
