"""Keep exact renewable fractions without scaling every load by their denominator.

The positive deficit over an integer load is split into integer excess and one
threshold correction. Arbitrarily wide nonnegative integer objectives are
added in small-base digits and minimized lexicographically. This is a standard
arithmetic/reference encoding, not a proposed scheduling heuristic.
"""
from dataclasses import dataclass
from fractions import Fraction as F
import itertools
import math
import time
from cas_pfsp_v45.model import validate_instance
from cas_pfsp_v45.timestep_accounting_r1 import check_benchmark_schedule
from cas_pfsp_v113.integer_reference import exact, LIMIT


@dataclass
class Built:
    model: object
    instance: object
    ranks: list
    starts: list
    digits: list
    base: int
    power_scale: int
    objective_denominator: int
    objective_upper_bound: int
    arithmetic: dict


def digit_sum(model, weighted):
    """Unique base-B representation of a nonnegative integer linear sum."""
    weighted = [(int(c), x, int(ub)) for c, x, ub in weighted if c and ub]
    upper = sum(c * ub for c, _, ub in weighted)
    mass = sum(ub for _, _, ub in weighted)
    if 4 * mass > LIMIT:
        raise ValueError('Conservative CP-SAT int64 arithmetic guard exceeded')
    k = max(1, min(20, (LIMIT // max(1, 2 * mass)).bit_length() - 1))
    base = 2**k
    count = max(1, (upper.bit_length() + k - 1) // k)
    digits, carry, carry_ub = [], 0, 0
    largest_row_bound = 0
    for level in range(count):
        limb = [(c // (base**level) % base, x, ub) for c, x, ub in weighted]
        bound = carry_ub + sum(c * ub for c, _, ub in limb)
        next_ub = bound // base
        digit = model.new_int_var(0, base - 1, f'objective_digit_{level}')
        next_carry = model.new_int_var(0, next_ub, f'objective_carry_{level+1}')
        model.add(sum(c * x for c, x, _ in limb if c) + carry == digit + base * next_carry)
        largest_row_bound = max(largest_row_bound, bound + base * next_ub + base - 1)
        digits.append(digit); carry, carry_ub = next_carry, next_ub
    assert carry_ub == 0
    if largest_row_bound > 2 * LIMIT:
        raise ValueError('Conservative CP-SAT int64 arithmetic guard exceeded')
    return digits, base, upper, largest_row_bound


def build(instance):
    validate_instance(instance)
    n, m, h, d = instance.n, instance.m, instance.horizon, instance.durations
    powers = [[[exact(v) for v in op] for op in job] for job in instance.powers]
    renewable, carbon = [exact(v) for v in instance.renewable], [exact(v) for v in instance.carbon]
    dp = math.lcm(1, *(v.denominator for job in powers for op in job for v in op))
    p = [[[int(v * dp) for v in op] for op in job] for job in powers]
    cap = sum(max(op, default=0) for job in p for op in job)
    convolution_mass = sum(max(0, h - sum(d[j]) + 1) * sum(p[j][a])
                           for j in range(n) for a in range(m))
    if max(cap, convolution_mass, h) > LIMIT:
        raise ValueError('Conservative CP-SAT int64 arithmetic guard exceeded')
    from ortools.sat.python import cp_model
    model = cp_model.CpModel()
    ranks = [model.new_int_var(0, n - 1, f'rank_{j}') for j in range(n)]
    model.add_all_different(ranks)
    starts = [[model.new_int_var(0, h, f'start_{j}_{a}') for a in range(m)] for j in range(n)]
    choices = {}
    for j, a in itertools.product(range(n), range(m)):
        lo, hi = sum(d[j][:a]), h - sum(d[j][a:])
        model.add(starts[j][a] >= lo); model.add(starts[j][a] <= hi)
        if a + 1 < m:
            model.add(starts[j][a+1] >= starts[j][a] + d[j][a])
        if d[j][a]:
            at = {s: model.new_bool_var(f'at_{j}_{a}_{s}') for s in range(lo, hi + 1)}
            choices[j, a] = at
            model.add_exactly_one(at.values())
            model.add(starts[j][a] == sum(s * x for s, x in at.items()))
    for i, j in itertools.combinations(range(n), 2):
        before = model.new_bool_var(f'before_{i}_{j}')
        model.add(ranks[i] < ranks[j]).only_enforce_if(before)
        model.add(ranks[i] > ranks[j]).only_enforce_if(~before)
        for a in range(m):
            model.add(starts[j][a] >= starts[i][a] + d[i][a]).only_enforce_if(before)
            model.add(starts[i][a] >= starts[j][a] + d[j][a]).only_enforce_if(~before)
    terms = []
    for t in range(h):
        load = model.new_int_var(0, cap, f'load_{t}')
        model.add(load == sum(p[j][a][t-s] * x for (j, a), at in choices.items()
            for s, x in at.items() if 0 <= t-s < d[j][a] and p[j][a][t-s]))
        r = dp * renewable[t]
        if r >= cap:
            continue
        floor = r.numerator // r.denominator; f = r - floor
        excess = model.new_int_var(0, cap - floor, f'excess_{t}')
        model.add_max_equality(excess, [0, load - floor])
        if f == 0:
            terms.append((carbon[t], excess, cap - floor))
        else:
            positive = model.new_bool_var(f'positive_deficit_{t}')
            model.add(excess >= 1).only_enforce_if(positive)
            model.add(excess == 0).only_enforce_if(~positive)
            whole = model.new_int_var(0, max(0, cap-floor-1), f'whole_deficit_{t}')
            model.add(whole == excess - positive)
            terms.extend([(carbon[t], whole, max(0, cap-floor-1)),
                          (carbon[t] * (1-f), positive, 1)])
    cost_scale = math.lcm(1, *(c.denominator for c, _, _ in terms))
    weighted = [(int(c * cost_scale), var, ub) for c, var, ub in terms]
    digits, base, upper, max_row = digit_sum(model, weighted)
    error = model.validate()
    if error:
        raise ValueError('CP-SAT model validation: ' + error)
    return Built(model, instance, ranks, starts, digits, base, dp, 4*dp*cost_scale, upper,
        {'gross_upper_bound': cap, 'convolution_coefficient_mass': convolution_mass,
         'largest_digit_constraint_bound': max_row, 'objective_bits': upper.bit_length(),
         'objective_digits': len(digits), 'objective_base': base})


def certificate(built, reader):
    positions = [reader.value(v) for v in built.ranks]
    assert sorted(positions) == list(range(len(positions)))
    order = sorted(range(len(positions)), key=positions.__getitem__)
    starts = [[reader.value(v) for v in row] for row in built.starts]
    values = [reader.value(v) for v in built.digits]
    integer = sum(v * built.base**k for k, v in enumerate(values))
    score = F(integer, built.objective_denominator)
    physical = check_benchmark_schedule(built.instance, order, starts)
    assert F(physical['benchmark_score_fraction']) == score
    return {'permutation': order, 'starts': starts, 'objective_digits': values,
            'scaled_integer_objective': integer, 'physical_score_fraction': str(score)}


def solve(instance, solver_seconds=30., presolve=True):
    if not math.isfinite(solver_seconds) or solver_seconds <= 0:
        raise ValueError('Positive finite solver-time limit required')
    begin = time.perf_counter(); built = build(instance)
    from ortools.sat.python import cp_model
    ready = time.perf_counter(); best = None; stages = []; complete = True
    status_name = 'UNKNOWN'
    for level in reversed(range(len(built.digits))):
        remaining = solver_seconds - (time.perf_counter() - ready)
        if remaining <= 0:
            complete = False; break
        built.model.minimize(built.digits[level])
        solver = cp_model.CpSolver()
        solver.parameters.num_search_workers = 1; solver.parameters.random_seed = 0
        solver.parameters.cp_model_presolve = bool(presolve)
        solver.parameters.max_time_in_seconds = remaining
        solver.parameters.absolute_gap_limit = 0; solver.parameters.relative_gap_limit = 0
        status = solver.solve(built.model)
        status_name = solver.status_name(status)
        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE, cp_model.INFEASIBLE, cp_model.UNKNOWN):
            raise RuntimeError('Unexpected CP-SAT status: ' + status_name)
        stages.append({'digit': level, 'status': status_name, 'value': None})
        if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            current = certificate(built, solver)
            if best is None or current['scaled_integer_objective'] < best['scaled_integer_objective']:
                best = current
            stages[-1]['value'] = solver.value(built.digits[level])
        if status == cp_model.OPTIMAL:
            built.model.add(built.digits[level] == stages[-1]['value'])
        elif status == cp_model.INFEASIBLE:
            assert best is None, 'A previously feasible optimal prefix cannot become infeasible'
            complete = False; break
        else:
            complete = False; break
    if best is not None:
        status_name = 'OPTIMAL' if complete else 'FEASIBLE'
    elif status_name != 'INFEASIBLE':
        status_name = 'UNKNOWN'
    return {'status': status_name, 'certificate': best, 'presolve': bool(presolve),
        'solver_time_limit_seconds_shared_by_all_digits': solver_seconds,
        'all_digits_proved_optimal': complete and best is not None,
        'stages': stages, 'power_scale': built.power_scale,
        'objective_denominator': built.objective_denominator, 'objective_base': built.base,
        'objective_digits': len(built.digits), 'arithmetic': built.arithmetic,
        'build_seconds_including_imports': ready - begin,
        'solver_and_export_seconds': time.perf_counter() - ready,
        'float_bound_used_as_exact_certificate': False, 'end_to_end_wall_budget_qualified': False,
        'scope': 'standard exact arithmetic reference; not a new algorithm or qualified public baseline'}
