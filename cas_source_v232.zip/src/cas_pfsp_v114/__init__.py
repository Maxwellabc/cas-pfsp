"""Exact wide-objective arithmetic for a standard CAS-PFSP reference."""
