"""Fixed-permutation timing oracles; standard minimum-closure methods, not novelty."""
