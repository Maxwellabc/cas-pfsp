"""Exact integer unary timing via the established minimum-closure reduction.

Credit: Mohring, Schulz, Stork, Uetz (2003), Management Science49(3):330-350,
doi:10.1287/mnsc.49.3.330.12737. No claim that the reduction or maxflow is new.
The expanded graph is polynomial in the grid horizon, not strongly polynomial
in the binary scheduling input. Zero-duration operations remain temporal nodes.
"""
from collections import deque
from dataclasses import dataclass
import time


@dataclass
class TemporalGrid:
    durations: tuple
    order: tuple
    horizon: int
    nodes: tuple
    parents: dict
    children: dict
    lower: dict
    upper: dict


def temporal_grid(durations, order, horizon):
    d=tuple(tuple(row) for row in durations);order=tuple(order)
    if not d or not d[0] or any(len(row)!=len(d[0]) for row in d):
        raise ValueError('Nonempty rectangular durations required')
    if type(horizon) is not int or horizon<0 or any(type(x) is not int or x<0 for row in d for x in row):
        raise ValueError('Nonnegative integer durations/horizon required')
    if any(type(j) is not int for j in order) or sorted(order)!=list(range(len(d))):
        raise ValueError('Complete permutation required')
    nodes=tuple((j,a) for j in order for a in range(len(d[0])))
    parents={op:[] for op in nodes};children={op:[] for op in nodes}
    for pos,j in enumerate(order):
        for a in range(len(d[0])):
            op=(j,a)
            if pos:parents[op].append((order[pos-1],a))
            if a:parents[op].append((j,a-1))
            for pred in parents[op]:children[pred].append(op)
    lo={};hi={}
    for op in nodes:lo[op]=max([0]+[lo[p]+d[p[0]][p[1]] for p in parents[op]])
    for op in reversed(nodes):
        duration=d[op[0]][op[1]]
        hi[op]=min([horizon-duration]+[hi[q]-duration for q in children[op]])
    if any(lo[op]>hi[op] for op in nodes):raise ValueError('Fixed order has no feasible timing')
    return TemporalGrid(d,order,horizon,nodes,parents,children,lo,hi)


class IntegerFlow:
    """Dinic with iterative augmenting paths and arbitrary-size Python integers."""
    def __init__(self,n,deadline=None):
        self.adj=[[] for _ in range(n)];self.original=[];self.deadline=deadline

    def check_time(self):
        if self.deadline is not None and time.perf_counter()>=self.deadline:
            raise TimeoutError('Exact flow incomplete; no optimum or bound returned')

    def add(self,u,v,c):
        assert type(c) is int and c>=0 and u!=v
        k=len(self.adj[u]);r=len(self.adj[v])
        self.adj[u].append([v,r,c]);self.adj[v].append([u,k,0])
        self.original.append((u,k,c))

    def solve(self,source,sink):
        total=0;rounds=0;augmentations=0
        while True:
            self.check_time();level=[-1]*len(self.adj);level[source]=0;q=deque([source])
            while q:
                u=q.popleft()
                if u%1024==0:self.check_time()
                for v,_,cap in self.adj[u]:
                    if cap and level[v]<0:level[v]=level[u]+1;q.append(v)
            if level[sink]<0:break
            ptr=[0]*len(self.adj);rounds+=1
            while True:
                self.check_time();stack=[source];path=[]
                while stack and stack[-1]!=sink:
                    u=stack[-1]
                    while ptr[u]<len(self.adj[u]):
                        v,_,cap=self.adj[u][ptr[u]]
                        if cap and level[v]==level[u]+1:break
                        ptr[u]+=1
                    if ptr[u]==len(self.adj[u]):
                        level[u]=-1;stack.pop()
                        if path:
                            parent,_=path.pop();ptr[parent]+=1
                    else:
                        path.append((u,ptr[u]));stack.append(self.adj[u][ptr[u]][0])
                if not stack:break
                amount=min(self.adj[u][k][2] for u,k in path)
                assert amount>0
                for u,k in path:
                    v,r,_=self.adj[u][k]
                    self.adj[u][k][2]-=amount;self.adj[v][r][2]+=amount
                total+=amount;augmentations+=1
        reachable={source};q=deque([source])
        while q:
            u=q.popleft()
            for v,_,cap in self.adj[u]:
                if cap and v not in reachable:reachable.add(v);q.append(v)
        assert sink not in reachable
        edges=[[u,self.adj[u][k][0],cap,cap-self.adj[u][k][2]] for u,k,cap in self.original]
        cut=sum(c for u,v,c,_ in edges if u in reachable and v not in reachable)
        assert cut==total
        return total,reachable,edges,{'level_rounds':rounds,'augmentations':augmentations}


def minimum_unary(grid,costs,certificate=True,deadline=None):
    """costs[op][s] is an INTEGER cost for every raw feasible start s=0..H-d.

    Returned optimum certified by equal feasible flow and cut values; a deadline
    raises instead of treating an incomplete min-cost calculation as a lower bound.
    """
    labels=[];index={};weights=[];base=0
    for op in grid.nodes:
        row=costs[op]
        if len(row)!=grid.horizon-grid.durations[op[0]][op[1]]+1 or any(type(c) is not int for c in row):
            raise ValueError('Exact integer cost table with correct raw horizon required')
        base+=row[grid.lower[op]]
        for t in range(grid.lower[op]+1,grid.upper[op]+1):
            index[op,t]=len(labels);labels.append([*op,t]);weights.append(row[t]-row[t-1])
    inf=1+sum(abs(x) for x in weights)
    source=len(labels);sink=source+1;flow=IntegerFlow(sink+1,deadline)
    for node,w in enumerate(weights):
        if w>0:flow.add(node,sink,w)
        elif w<0:flow.add(source,node,-w)
    for op in grid.nodes:
        for t in range(grid.lower[op]+1,grid.upper[op]+1):
            node=index[op,t]
            if t>grid.lower[op]+1:flow.add(node,index[op,t-1],inf)
            d=grid.durations[op[0]][op[1]]
            for after in grid.children[op]:
                target=t+d
                if target<=grid.lower[after]:continue
                assert target<=grid.upper[after]
                flow.add(node,index[after,target],inf)
    value,selected,edges,counts=flow.solve(source,sink)
    starts=[[0]*len(grid.durations[0]) for _ in grid.durations]
    for op in grid.nodes:
        starts[op[0]][op[1]]=grid.lower[op]+sum(index[op,t] in selected for t in range(grid.lower[op]+1,grid.upper[op]+1))
    objective=sum(costs[op][starts[op[0]][op[1]]] for op in grid.nodes)
    offset=base+sum(w for w in weights if w<0)
    assert objective==offset+value
    for op in grid.nodes:
        s=starts[op[0]][op[1]]
        assert grid.lower[op]<=s<=grid.upper[op]
        assert all(s>=starts[p[0]][p[1]]+grid.durations[p[0]][p[1]] for p in grid.parents[op])
    result={'starts':starts,'unary_optimum':objective,'flow_value':value,'objective_offset':offset,
            'threshold_nodes':len(labels),'network_edges':len(edges),'flow_counts':counts}
    if certificate:result['certificate']={'threshold_labels':labels,'edges_capacity_flow':edges,
        'source':source,'sink':sink,'source_side':sorted(selected),'infinite_capacity':inf}
    return result
