"""Exact fixed-order timing neighborhood with paid-scope timing unqualified.

External operation durations and precedence remain intact. Only free positive
profile entries enter the two cumulative constraints. Fixed demand contributes
both an objective constant and a nonnegative residual renewable profile.
This is a generic exact neighborhood primitive, not a complete new algorithm.
"""
from fractions import Fraction as F
import math
import time
from cas_pfsp_v45.model import validate_instance
from cas_pfsp_v45.timestep_accounting_r1 import check_benchmark_schedule
from cas_pfsp_v113.integer_reference import exact, LIMIT
from cas_pfsp_v114.wide_reference import Built, certificate
from cas_pfsp_v116.model import digit_sum


def build(instance, order, anchor, free_operations, checkpoint=lambda phase: None):
    checkpoint('neighborhood_begin'); validate_instance(instance)
    check_benchmark_schedule(instance, order, anchor)
    n, m, h, d = instance.n, instance.m, instance.horizon, instance.durations
    listed = list(free_operations)
    if any(not isinstance(op, (tuple, list)) or len(op) != 2 or
        any(type(x) is not int for x in op) or not (0 <= op[0] < n and 0 <= op[1] < m) for op in listed):
        raise ValueError('Valid integer operation pairs required')
    free = {tuple(op) for op in listed}
    if len(free) != len(listed): raise ValueError('Duplicate free operation')
    powers = [[[exact(v) for v in op] for op in job] for job in instance.powers]
    renewable, carbon = list(map(exact, instance.renewable)), list(map(exact, instance.carbon))
    dp = math.lcm(1, *(v.denominator for job in powers for op in job for v in op))
    p = [[[int(v*dp) for v in op] for op in job] for job in powers]
    background = [0]*h
    for j in range(n):
        for a in range(m):
            checkpoint('background_operation')
            if (j, a) not in free:
                for k, power in enumerate(p[j][a]): background[anchor[j][a]+k] += power
    residual = [max(F(0), dp*r-b) for r, b in zip(renewable, background)]
    background_cost = sum((c*max(F(0), b-dp*r) for b, r, c in zip(background, renewable, carbon)), F(0))
    cap = sum(max(p[j][a], default=0) for j, a in free)
    energy = sum(sum(p[j][a]) for j, a in free)
    mass = 2*energy+2*h*cap
    if max(mass, h) > LIMIT: raise ValueError('Conservative CP-SAT int64 arithmetic guard exceeded')
    from ortools.sat.python import cp_model
    model = cp_model.CpModel()
    positions = {j: k for k, j in enumerate(order)}
    ranks = [positions[j] for j in range(n)]
    starts = [[model.new_int_var(0, h, f'start_{j}_{a}') if (j, a) in free else
        model.new_int_var(anchor[j][a], anchor[j][a], f'start_{j}_{a}') for a in range(m)] for j in range(n)]
    active, demands, complement, opposite = [], [], [], []
    for j in range(n):
        for a in range(m):
            checkpoint('precedence_operation')
            model.add(starts[j][a] >= sum(d[j][:a])); model.add(starts[j][a] <= h-sum(d[j][a:]))
            if a: model.add(starts[j][a] >= starts[j][a-1]+d[j][a-1])
            if (j, a) not in free: continue
            for k, power in enumerate(p[j][a]):
                if not power: continue
                unit = model.new_int_var(0, h-1, f'unit_{j}_{a}_{k}')
                model.add(unit == starts[j][a]+k)
                active.append(model.new_fixed_size_interval_var(unit, 1, f'active_{j}_{a}_{k}')); demands.append(power)
                complement += [model.new_interval_var(0, unit, unit, f'prefix_{j}_{a}_{k}'),
                    model.new_interval_var(unit+1, h-unit-1, h, f'suffix_{j}_{a}_{k}')]
                opposite += [power, power]
    for before, after in zip(order, order[1:]):
        checkpoint('fixed_order_edge')
        for a in range(m): model.add(starts[after][a] >= starts[before][a]+d[before][a])
    terms = []
    if background_cost:
        one = model.new_int_var(1, 1, 'background_one')
        terms.append((background_cost, one, 1))
    for t, r in enumerate(residual):
        checkpoint('residual_calendar_slot')
        if r >= cap: continue
        floor = r.numerator//r.denominator; fraction = r-floor
        excess = model.new_int_var(0, cap-floor, f'excess_{t}')
        positive = model.new_bool_var(f'positive_deficit_{t}')
        model.add(excess >= positive); model.add(excess <= (cap-floor)*positive)
        calendar = model.new_fixed_size_interval_var(t, 1, f'calendar_{t}')
        active.append(calendar); demands.append(cap-floor-excess)
        reverse = model.new_int_var(0, 2*cap, f'reverse_calendar_{t}')
        model.add(reverse == floor+excess+cap*positive)
        complement.append(calendar); opposite.append(reverse)
        if fraction == 0: terms.append((carbon[t], excess, cap-floor))
        else:
            whole = model.new_int_var(0, max(0, cap-floor-1), f'whole_deficit_{t}')
            model.add(whole == excess-positive)
            terms += [(carbon[t], whole, max(0, cap-floor-1)), (carbon[t]*(1-fraction), positive, 1)]
    model.add_cumulative(active, demands, cap); model.add_cumulative(complement, opposite, energy+cap)
    scale = math.lcm(1, *(c.denominator for c, _, _ in terms))
    digits, base, upper, row_bound = digit_sum(model, [(int(c*scale), var, ub) for c, var, ub in terms], checkpoint)
    checkpoint('model_validation'); error = model.validate()
    if error: raise ValueError('CP-SAT model validation: '+error)
    checkpoint('model_complete')
    return Built(model, instance, ranks, starts, digits, base, dp, 4*dp*scale, upper,
        {'fixed_order': list(order), 'anchor': [list(row) for row in anchor], 'free_operations': [list(op) for op in sorted(free)],
         'scaled_background_load': background, 'scaled_residual_renewable': list(map(str, residual)),
         'background_score_fraction': str(background_cost/(4*dp)), 'free_gross_upper_bound': cap,
         'free_total_scaled_profile_power': energy, 'conservative_cumulative_mass': mass,
         'profile_intervals': len(active), 'complement_intervals': len(complement),
         'objective_digits': len(digits), 'objective_base': base, 'largest_digit_constraint_bound': row_bound,
         'time_indexed_start_choice_booleans': 0, 'variable_permutation_ranks': 0})


def solve(instance, order, anchor, free_operations, solver_seconds=5., presolve=True):
    """Private exact neighborhood policy; its budget covers solver stages only."""
    if not math.isfinite(solver_seconds) or solver_seconds <= 0:
        raise ValueError('Positive finite solver-time limit required')
    begin = time.perf_counter(); built = build(instance, order, anchor, free_operations)
    from ortools.sat.python import cp_model
    ready = time.perf_counter(); best = None; stages = []; complete = True
    for level in reversed(range(len(built.digits))):
        remaining = solver_seconds-(time.perf_counter()-ready)
        if remaining <= 0: complete = False; break
        built.model.minimize(built.digits[level]); solver = cp_model.CpSolver()
        solver.parameters.num_search_workers = 1; solver.parameters.random_seed = 0
        solver.parameters.cp_model_presolve = bool(presolve); solver.parameters.max_time_in_seconds = remaining
        solver.parameters.absolute_gap_limit = 0; solver.parameters.relative_gap_limit = 0
        status = solver.solve(built.model); name = solver.status_name(status)
        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE, cp_model.UNKNOWN):
            raise RuntimeError('Valid anchored neighborhood lost feasibility or model validity: '+name)
        stage = {'digit': level, 'status': name, 'value': None}; stages.append(stage)
        if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            current = certificate(built, solver)
            if best is None or current['scaled_integer_objective'] < best['scaled_integer_objective']: best = current
            stage['value'] = int(solver.value(built.digits[level]))
        if status == cp_model.OPTIMAL: built.model.add(built.digits[level] == stage['value'])
        else: complete = False; break
    return {'status': 'OPTIMAL' if complete and best else 'FEASIBLE' if best else 'UNKNOWN',
        'certificate': best, 'presolve': bool(presolve), 'all_digits_proved_optimal': complete and best is not None,
        'stages': stages, 'objective_denominator': built.objective_denominator, 'objective_base': built.base,
        'objective_digits': len(built.digits), 'arithmetic': built.arithmetic,
        'build_seconds_including_imports': ready-begin, 'solver_and_export_seconds': time.perf_counter()-ready,
        'core_budget_interface_qualified': False, 'float_bound_used_as_exact_certificate': False,
        'complete_algorithm_or_public_quality_qualified': False}
