"""Private fixed-background exact timing neighborhoods for accepted CAS."""
