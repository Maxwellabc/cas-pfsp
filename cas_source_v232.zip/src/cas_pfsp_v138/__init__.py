"""Exact machine-row timing with necessary deadline viability cuts."""
