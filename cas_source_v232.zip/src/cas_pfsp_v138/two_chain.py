"""Remove prefix work states that cannot meet necessary future deadlines.

Same feasible row neighborhood as v135; conventional feasibility pruning, not
a paid complete policy, runtime superiority or priority qualification.
"""
import itertools
from cas_pfsp_v135.two_chain import ChainTiming


class ViableChainTiming(ChainTiming):
    def __init__(self,instance,order,anchor,machine_rows,checkpoint=lambda phase:None):
        super().__init__(instance,order,anchor,machine_rows,checkpoint=checkpoint)
        self.latest_boundary=[];self.pruned_transition_targets=0;self.pruned_targets=set();self.cut_trace_requested=False
        for chain,total in zip(self.chains,self.goal):
            starts={self.work[op][1]:self.domains[op][1]-self.work[op][1] for op in chain}
            bound=self.h-total;table=[None]*(total+1)
            for work in reversed(range(total+1)):
                checkpoint('viability_prepare_work')
                if work in starts:bound=min(bound,starts[work])
                table[work]=work+bound
            assert table[0]>=0 and table[-1]==self.h
            self.latest_boundary.append(table)
        checkpoint('viability_prepare_complete')

    def viable(self,time,work):
        return all(time<=table[k] for table,k in zip(self.latest_boundary,work))

    def run(self,trace_frontiers=False,trace_viability_cuts=False,on_improvement=lambda point:None):
        if self.started:raise ValueError('A chain DP object is single-use')
        if type(trace_frontiers) is not bool or type(trace_viability_cuts) is not bool:
            raise ValueError('Boolean frontier and viability trace options required')
        self.started=True;self.cut_trace_requested=trace_viability_cuts
        def trace(t):
            if trace_frontiers:
                self.frontier_trace.append({'time':t,'states':[{'work':list(k),'prefix_numerator':r['cost']}
                    for k,r in sorted(self.layers[t].items())]})
        trace(0);self.checkpoint('chain_search_begin')
        for t in range(self.h):
            following={}
            for state,record in self.layers[t].items():
                self.checkpoint('chain_frontier_state');choices=[]
                for index,k in enumerate(state):
                    op,offset,active=self.chain_tables[index][k]
                    if active:
                        j,a=op;choices.append([(1,self.ctx.powers[j][a][offset],None)])
                    else:
                        options=[(0,0,None)]
                        if op is not None:
                            low,high=self.domains[op]
                            if low<=t<=high and all(done>=need for done,need in zip(state,self.requirements[op])):
                                j,a=op;options.append((1,self.ctx.powers[j][a][0],op))
                        choices.append(options)
                for chosen in itertools.product(*choices):
                    self.checkpoint('chain_transition');self.transitions+=1
                    target=tuple(k+item[0] for k,item in zip(state,chosen))
                    if not self.viable(t+1,target):
                        self.pruned_transition_targets+=1
                        if trace_viability_cuts:self.pruned_targets.add((t+1,target))
                        continue
                    load=self.background[t]+sum(item[1] for item in chosen)
                    value=record['cost']+self.ctx.carbon[t]*max(0,load-self.ctx.renewable[t])
                    if target not in following or value<following[target]['cost']:
                        following[target]={'cost':value,'parent':state,
                            'starts':[list(item[2]) for item in chosen if item[2] is not None]}
                        self.state_updates+=1
            assert following
            self.layers.append(following);trace(t+1)
            if self.goal in following:
                value=following[self.goal]['cost']+self.background_tail[t+1]
                if value<self.best_value:
                    self.checkpoint('chain_before_physical_candidate');point=self.point(t+1,self.goal,value)
                    on_improvement(point)
                    self.best_value=value;self.best_starts=[row[:] for row in point['starts']];self.improvements+=1
                    self.checkpoint('chain_after_candidate')
            self.checkpoint('chain_layer_complete')
        assert self.goal in self.layers[-1]
        assert self.best_value==self.layers[-1][self.goal]['cost']
        self.checkpoint('chain_search_complete');self.complete=True
        return self.summary()

    def summary(self):
        out=super().summary()
        out.update(viability_cut_kind='remaining_chain_work_horizon_and_unstarted_operation_latest_start',
            viability_latest_boundary_tables=[table[:] for table in self.latest_boundary],
            viability_pruned_transition_targets_with_overlap=self.pruned_transition_targets,
            viability_cut_trace_requested=self.cut_trace_requested,
            viability_unique_pruned_targets=[{'time':t,'work':list(k)} for t,k in sorted(self.pruned_targets)],
            unchanged_feasible_machine_row_neighborhood=True,paid_complete_pruned_policy_qualified=False)
        return out
