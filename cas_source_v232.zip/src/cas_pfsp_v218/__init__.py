"""Controlled component deletions of the frozen v197 policy."""
