"""Exact common phase search for positive-duration operations.

Zero-duration temporal nodes are reconstructed, not translated. An orbit
optimum is not a fixed-permutation timing optimum. Calendar translation and
memoization have prior art; this module makes no priority claim.
"""
from collections import OrderedDict
from dataclasses import dataclass
import time

from cas_pfsp_v64.registry import physical_numerator
from cas_pfsp_v69.projection import matrix


def zero_aware_transplant(grid, target):
    n, m = len(grid.durations), len(grid.durations[0])
    if len(target) != n or any(len(row) != m for row in target):
        raise ValueError('Rectangular target required')
    if any(type(s) is not int for row in target for s in row):
        raise ValueError('Integer target required')
    chosen = {}
    for j, a in grid.nodes:
        lo = max([0] + [chosen[p] + grid.durations[p[0]][p[1]]
                        for p in grid.parents[j, a]])
        chosen[j, a] = (max(lo, min(target[j][a], grid.upper[j, a]))
                        if grid.durations[j][a] else lo)
        assert grid.lower[j, a] <= chosen[j, a] <= grid.upper[j, a]
    return matrix(grid, chosen)


@dataclass(frozen=True)
class Geometry:
    anchor: int
    span: int
    relative: tuple
    profile: tuple
    positive_operations: int

    @property
    def key(self):
        # Duration of zero-power positive operations remains in span/profile.
        return self.span, self.profile

    def phases(self, horizon):
        return range(horizon - self.span + 1) if self.positive_operations else range(1)

    def materialize(self, grid, phase):
        if type(phase) is not int or phase not in self.phases(grid.horizon):
            raise ValueError('Phase outside positive-operation orbit')
        chosen = {}
        for op in grid.nodes:
            j, a = op
            lo = max([0] + [chosen[p] + grid.durations[p[0]][p[1]]
                            for p in grid.parents[op]])
            chosen[op] = self.relative[j][a] + phase if grid.durations[j][a] else lo
            if not lo <= chosen[op] <= grid.upper[op]:
                raise ValueError('Invalid positive-operation geometry')
        return matrix(grid, chosen)


def geometry(ctx, grid, starts):
    physical_numerator(ctx, grid.order, starts)
    positives = [(j, a) for j, a in grid.nodes if ctx.durations[j][a] > 0]
    anchor = min((starts[j][a] for j, a in positives), default=0)
    end = max((starts[j][a] + ctx.durations[j][a] for j, a in positives), default=0)
    relative = tuple(tuple(starts[j][a] - anchor if ctx.durations[j][a] else None
                           for a in range(len(ctx.durations[j])))
                     for j in range(len(ctx.durations)))
    profile = [0] * (end - anchor)
    for j, a in positives:
        for offset, power in enumerate(ctx.powers[j][a]):
            profile[relative[j][a] + offset] += power
    return Geometry(anchor, end - anchor, relative, tuple(profile), len(positives))


def phase_value(ctx, shape, phase):
    if type(phase) is not int or phase not in shape.phases(ctx.horizon):
        raise ValueError('Phase outside positive-operation orbit')
    return sum(ctx.carbon[phase + u] * max(load - ctx.renewable[phase + u], 0)
               for u, load in enumerate(shape.profile))


class PhaseScanner:
    """Current-instance, current-run bounded cache of complete certificates.

    register(starts,value,origin) must perform actual physical registration.
    A scalar computed before the deadline is not an eligible schedule by itself.
    """
    def __init__(self, ctx, started, deadline, clock=time.perf_counter, capacity=128):
        if type(capacity) is not int or capacity < 1 or deadline <= started:
            raise ValueError('Positive cache capacity and wall budget required')
        self.ctx, self.started, self.deadline, self.clock = ctx, started, deadline, clock
        self.capacity, self.cache, self.calls = capacity, OrderedDict(), []

    def scan(self, grid, starts, raw_value, register, origin):
        row = {'id': len(self.calls), 'origin': origin, 'phase_values': [],
               'registrations': [], 'cache_source_call': None,
               'all_phases_scanned': False, 'orbit_optimality_certified': False,
               'certificate_available_before_deadline': False,
               'started_seconds': self.clock() - self.started}
        self.calls.append(row)
        if self.clock() >= self.deadline:
            row.update(stop='deadline_before_geometry', returned_seconds=self.clock()-self.started)
            return row
        shape = geometry(self.ctx, grid, starts)
        row.update(anchor=shape.anchor, span=shape.span, profile=list(shape.profile),
                   positive_operations=shape.positive_operations,
                   phase_domain_size=len(shape.phases(self.ctx.horizon)))
        best, phase = None, None
        local_registered = raw_value
        if shape.key in self.cache:
            old = self.cache[shape.key]
            self.cache.move_to_end(shape.key)
            best, phase = old['value'], old['phase']
            row.update(cache_source_call=old['call'], orbit_optimality_certified=True,
                       stop='complete_current_run_orbit_cache')
            if self.clock() < self.deadline and best < raw_value:
                receipt = register(shape.materialize(grid, phase), best,
                    {'kind': 'phase_cache', 'phase_call': row['id'], 'source_call': old['call'], 'phase': phase})
                row['registrations'].append(receipt)
        else:
            for t in shape.phases(self.ctx.horizon):
                if self.clock() >= self.deadline:
                    row['stop'] = 'deadline_before_phase'
                    break
                value = phase_value(self.ctx, shape, t)
                row['phase_values'].append([t, value])
                if best is None or value < best:
                    best, phase = value, t
                if self.clock() < self.deadline and value < local_registered:
                    receipt = register(shape.materialize(grid, t), value,
                        {'kind': 'phase_scan', 'phase_call': row['id'], 'phase': t})
                    row['registrations'].append(receipt)
                    if receipt['eligible']:
                        local_registered = value
                if value == 0:
                    row.update(stop='nonnegative_objective_zero_orbit_certificate',
                               orbit_optimality_certified=True)
                    break
            row['all_phases_scanned'] = len(row['phase_values']) == row['phase_domain_size']
            if row['all_phases_scanned']:
                row.update(orbit_optimality_certified=True, stop='all_phases_scanned')
            if row['orbit_optimality_certified'] and self.clock() < self.deadline:
                if len(self.cache) >= self.capacity:
                    self.cache.popitem(last=False)
                self.cache[shape.key] = {'value': best, 'phase': phase, 'call': row['id']}
        certified_at = self.clock()
        available = bool(row['orbit_optimality_certified'] and certified_at < self.deadline)
        row.update(best_computed_value=best, best_computed_phase=phase,
                   certificate_available_before_deadline=available,
                   certificate_available_seconds=certified_at-self.started if available else None,
                   returned_seconds=self.clock() - self.started)
        return row
