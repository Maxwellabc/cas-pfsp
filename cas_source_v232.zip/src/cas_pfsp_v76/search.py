"""Complete experimental insertion search with phase/transfer components.

All five policies include earliest and latest timing of each permutation.
Trace rows reference paid registration IDs to avoid duplicating start matrices.
Generic insertion search, calendar translation and caching are not novelty claims.
"""
from fractions import Fraction as F
import random
import time

from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v53.minimum_closure import temporal_grid
from cas_pfsp_v64.registry import PhysicalRegistry, physical_numerator
from cas_pfsp_v69.projection import initial_orders, matrix, transplant
from cas_pfsp_v69.search import insertion_orders, rng_sha
from cas_pfsp_v70.runtime import finish_metrics
from .phase import PhaseScanner, zero_aware_transplant

POLICIES = {'t0p0': (False, False, False), 't0p1': (False, True, False),
            't1p0': (True, False, True), 't1p1': (True, True, True),
            't1p1z0': (True, True, False)}


class PhaseSearch:
    def __init__(self, ctx, started, deadline, policy, seed, clock=time.perf_counter,
                 max_evaluations=None, stop_at_zero=True, phase_cache_capacity=128):
        if policy not in POLICIES or deadline <= started:
            raise ValueError('Valid policy and positive budget required')
        if max_evaluations is not None and (type(max_evaluations) is not int or max_evaluations < 1):
            raise ValueError('Positive diagnostic evaluation quota required')
        self.ctx, self.started, self.deadline, self.clock = ctx, started, deadline, clock
        self.policy, self.seed, self.rng = policy, seed, random.Random(seed)
        self.transfer, self.phase, self.zero_aware = POLICIES[policy]
        self.max_evaluations, self.stop_at_zero = max_evaluations, stop_at_zero
        self.registry = PhysicalRegistry(ctx, started, deadline, clock=clock)
        self.scanner = PhaseScanner(ctx, started, deadline, clock, phase_cache_capacity)
        self.evaluations, self.current, self.best_search = [], None, None

    def live(self):
        return (self.clock() < self.deadline
                and (self.max_evaluations is None or len(self.evaluations) < self.max_evaluations)
                and not (self.stop_at_zero and self.registry.best_value == 0))

    def register(self, order, starts, value, origin):
        ix = len(self.registry.attempts)
        r = self.registry.register(order, starts, str(F(value, self.ctx.denominator)), origin)
        return {'attempt_id': ix, 'eligible': r['eligible'],
                'available_seconds': r['available_seconds']}

    def score(self, ix):
        return self.registry.attempts[ix]['score_numerator']

    def evaluate(self, order, reason, move=None):
        ix = len(self.evaluations)
        row = {'id': ix, 'order': list(order), 'reason': reason, 'move': move,
               'rng_before_sha256': rng_sha(self.rng), 'current_before_attempt_id': self.current,
               'witnesses': [], 'phase_calls': [], 'accepted': False,
               'started_seconds': self.clock() - self.started}
        self.evaluations.append(row)
        try:
            grid = temporal_grid(self.ctx.durations, order, self.ctx.horizon)
        except ValueError as e:
            if str(e) != 'Fixed order has no feasible timing':
                raise
            row.update(status='infeasible_order', returned_seconds=self.clock()-self.started)
            return False
        proposed = [('earliest', matrix(grid, grid.lower)), ('latest', matrix(grid, grid.upper))]
        if self.transfer and self.current is not None:
            target = self.registry.attempts[self.current]['starts']
            proposed.append(('transplant', transplant(grid, target)))
            if self.zero_aware:
                proposed.append(('zero_aware_transplant', zero_aware_transplant(grid, target)))
        seen, eligible, raw = set(), [], []
        # Give all distinct raw alternatives a chance before any orbit scan.
        for source, starts in proposed:
            key = tuple(tuple(r) for r in starts)
            if key in seen:
                continue
            seen.add(key)
            if self.clock() >= self.deadline:
                break
            value = physical_numerator(self.ctx, order, starts)
            r = self.register(order, starts, value, {'kind': 'raw_witness', 'evaluation': ix, 'source': source})
            row['witnesses'].append({'source': source, **r})
            if r['eligible']:
                eligible.append(r['attempt_id'])
                raw.append((source, starts, value))
        if self.phase:
            for source, starts, value in raw:
                if self.clock() >= self.deadline:
                    break
                call = self.scanner.scan(grid, starts, value,
                    lambda s, v, o: self.register(order, s, v, {**o, 'evaluation': ix, 'source': source}),
                    {'evaluation': ix, 'source': source})
                row['phase_calls'].append(call['id'])
                eligible.extend(r['attempt_id'] for r in call['registrations'] if r['eligible'])
        selected = min(eligible, key=self.score) if eligible else None
        ready = self.clock()
        strict = selected is not None and (self.current is None or self.score(selected) < self.score(self.current))
        accepted = selected is not None and ready < self.deadline and (strict or reason == 'shake')
        if accepted:
            self.current = selected
        if selected is not None and ready < self.deadline and (self.best_search is None
                                                               or self.score(selected) < self.score(self.best_search)):
            self.best_search = selected
        row.update(status='evaluated', selected_attempt_id=selected, decision_ready_seconds=ready-self.started,
                   accepted=bool(accepted), strict_improvement=bool(accepted and strict),
                   current_after_attempt_id=self.current, returned_seconds=self.clock()-self.started)
        return accepted

    def run(self):
        before = random.getstate()
        for order in initial_orders(self.ctx):
            if not self.live():
                break
            self.evaluate(order, 'initialization')
        while self.live():
            if self.current is None:
                order = list(range(len(self.ctx.durations)))
                self.rng.shuffle(order)
                self.evaluate(order, 'feasibility_search')
                continue
            order = self.registry.attempts[self.current]['permutation']
            improved = False
            for proposed, move in insertion_orders(order, self.rng):
                if not self.live():
                    break
                if self.evaluate(proposed, 'insertion', move):
                    improved = True
                    break
            if not self.live():
                break
            if improved:
                continue
            order = list(self.registry.attempts[self.best_search]['permutation'])
            for _ in range(min(3, len(order))):
                if len(order) > 1:
                    i, j = self.rng.sample(range(len(order)), 2)
                    job = order.pop(i)
                    order.insert(j, job)
            self.evaluate(order, 'shake')
        assert random.getstate() == before
        return {'policy': self.policy, 'seed': self.seed, 'transfer_enabled': self.transfer,
                'phase_enabled': self.phase, 'zero_aware_enabled': self.zero_aware,
                'evaluations': self.evaluations, 'phase_calls': self.scanner.calls,
                'registered_attempts': self.registry.attempts, 'best_registered': self.registry.best,
                'current_attempt_id': self.current, 'best_search_attempt_id': self.best_search,
                'rng_after_sha256': rng_sha(self.rng), 'global_Python_rng_unchanged': True,
                'budget_seconds': self.deadline-self.started, 'max_evaluations': self.max_evaluations,
                'stop_at_zero': self.stop_at_zero, 'algorithm_wall_seconds': self.clock()-self.started,
                'phase_cache_capacity': self.scanner.capacity,
                'physical_denominator_for_audit': self.ctx.denominator,
                'all_setup_registration_cache_and_logging_charged': True,
                'donated_initializer_or_external_cache': False, 'timing_DP_calls': 0,
                'global_or_fixed_order_timing_optimum_claim': False}


def run_search(input_path, policy, seed, budget_seconds, **options):
    if 'neso_' in str(input_path).lower():
        raise ValueError('Reserved path before read')
    if budget_seconds <= 0:
        raise ValueError('Positive wall budget required')
    started, cpu = time.perf_counter(), time.process_time()
    physical = load_instance(input_path)
    ctx = make_context(physical)
    result = PhaseSearch(ctx, started, started+budget_seconds, policy, seed, **options).run()
    return finish_metrics(result, cpu, physical.input_sha256)
