"""Experimental phase-aware timing inheritance; not a promoted method."""
