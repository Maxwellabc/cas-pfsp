"""Independent-chain marginal suffix costs for a shared-import lower bound.

Nonnegative scaled integer coefficients. Domains already encode fixed exterior
positives; cross-row precedence is relaxed. None denotes an infinite bound.
The input time/work state must represent a legal history before this bound is
used for pruning. This is not a reachability test or a physical incumbent.
"""


def _integers(values):
    try:values=tuple(values)
    except TypeError:raise ValueError('Integer coefficient sequence required') from None
    if any(type(v) is not int or v<0 for v in values):
        raise ValueError('Nonnegative exact integer coefficients required')
    return values


class MarginalSuffixBound:
    def __init__(self,chains,background,renewable,carbon,checkpoint=lambda phase:None):
        checkpoint('marginal_bound_begin')
        bg,r,c=map(_integers,(background,renewable,carbon))
        if not len(bg)==len(r)==len(c) or not bg:raise ValueError('Equal positive horizons required')
        try:chains=tuple(tuple(chain) for chain in chains)
        except TypeError:raise ValueError('One or two operation chains required') from None
        if len(chains) not in (1,2):raise ValueError('One or two operation chains required')
        self.h=len(c);self.background=bg;self.renewable=r;self.carbon=c
        self.background_tail=[0]*(self.h+1)
        for t in reversed(range(self.h)):
            checkpoint('marginal_background_tail')
            self.background_tail[t]=self.background_tail[t+1]+c[t]*max(0,bg[t]-r[t])
        self.tables=[];self.work_units=[];self.goals=[];self.prepared_cells=0
        for chain in chains:
            units=[]
            for operation in chain:
                checkpoint('marginal_operation')
                profile=_integers(operation['profile'])
                low,high=operation['earliest'],operation['latest']
                if not profile:raise ValueError('Chains contain positive-duration operations only')
                if any(type(v) is not int for v in (low,high)) or not 0<=low<=high<=self.h-len(profile):
                    raise ValueError('Valid integer fixed-exterior start domains required')
                units.extend((power,offset!=0,low,high) for offset,power in enumerate(profile))
            total=len(units)
            if total>self.h:raise ValueError('Chain work exceeds the anchored horizon')
            table=[[None]*(total+1) for _ in range(self.h+1)]
            table[self.h][total]=0
            for t in reversed(range(self.h)):
                table[t][total]=0
                base=max(0,bg[t]-r[t])
                for k,(power,active,low,high) in enumerate(units):
                    checkpoint('marginal_suffix_cell');self.prepared_cells+=1
                    options=[]
                    if not active and table[t+1][k] is not None:options.append(table[t+1][k])
                    if (active or low<=t<=high) and table[t+1][k+1] is not None:
                        delta=c[t]*(max(0,bg[t]+power-r[t])-base)
                        assert delta>=0
                        options.append(delta+table[t+1][k+1])
                    table[t][k]=min(options) if options else None
            self.work_units.append(units);self.goals.append(total);self.tables.append(table)
        self.goals=tuple(self.goals)
        checkpoint('marginal_bound_complete')

    def remaining(self,time,work):
        if type(time) is not int or not 0<=time<=self.h:raise ValueError('Integer time within horizon required')
        try:work=tuple(work)
        except TypeError:raise ValueError('One work coordinate per chain required') from None
        if len(work)!=len(self.goals) or any(type(k) is not int or not 0<=k<=d for k,d in zip(work,self.goals)):
            raise ValueError('Integer work coordinates within chain bounds required')
        values=[table[time][k] for table,k in zip(self.tables,work)]
        if any(value is None for value in values):return None
        return self.background_tail[time]+sum(values)

    def full_lower(self,time,work,prefix_numerator):
        if type(prefix_numerator) is not int or prefix_numerator<0:raise ValueError('Nonnegative integer prefix cost required')
        value=self.remaining(time,work)
        return None if value is None else prefix_numerator+value

    def cannot_strictly_improve(self,time,work,prefix_numerator,incumbent_numerator):
        if type(incumbent_numerator) is not int or incumbent_numerator<0:
            raise ValueError('Nonnegative integer feasible incumbent cost required')
        value=self.full_lower(time,work,prefix_numerator)
        return value is None or value>=incumbent_numerator

    def summary(self):
        return dict(chain_work_totals=list(self.goals),background_tail=list(self.background_tail),
            marginal_tables=[[row[:] for row in table] for table in self.tables],
            prepared_work_cells=self.prepared_cells,cross_row_precedence_relaxed=True,
            arbitrary_states_certified_reachable=False,shared_import_bound_not_a_physical_schedule=True,
            complete_paid_search_or_public_quality_or_priority_qualified=False)
