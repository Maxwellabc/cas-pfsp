"""Private marginal-cost lower-bound component; no complete search policy."""
