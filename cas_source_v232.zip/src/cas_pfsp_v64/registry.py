"""An exact physical incumbent,available only after real registration work."""
import copy,time
from fractions import Fraction as F
from cas_pfsp_v47.pair_timing import gross_profile,load_functional


def physical_numerator(ctx,order,starts):
    n=len(ctx.powers);m=len(ctx.powers[0]);h=ctx.horizon
    if len(order)!=n or any(type(j) is not int for j in order) or sorted(order)!=list(range(n)):
        raise ValueError('Complete integer permutation required')
    if len(starts)!=n or any(len(row)!=m for row in starts) or any(type(s) is not int for row in starts for s in row):
        raise ValueError('Integer start matrix required')
    for j in order:
        for a in range(m):
            s=starts[j][a]
            if not 0<=s<=h-ctx.durations[j][a]:raise ValueError('Start outside horizon')
            if a and s<starts[j][a-1]+ctx.durations[j][a-1]:raise ValueError('Job precedence')
    for before,after in zip(order,order[1:]):
        if any(starts[after][a]<starts[before][a]+ctx.durations[before][a] for a in range(m)):
            raise ValueError('Permutation-machine precedence')
    return load_functional(ctx,gross_profile(ctx,starts))


class PhysicalRegistry:
    def __init__(self,ctx,started,deadline=None,clock=time.perf_counter):
        self.ctx,self.started,self.deadline,self.clock=ctx,started,deadline,clock
        self.attempts=[];self.best=None;self.best_value=None;self.registration_seconds=0.

    def register(self,order,starts,score_fraction,origin):
        began=self.clock();order=list(order);starts=copy.deepcopy(starts)
        value=physical_numerator(self.ctx,order,starts)
        if F(score_fraction)!=F(value,self.ctx.denominator):raise ValueError('Physical score/starts mismatch')
        row={'permutation':order,'starts':starts,'score_fraction':str(F(value,self.ctx.denominator)),
             'score_numerator':value,'origin':copy.deepcopy(origin),
             'registration_started_seconds':began-self.started}
        strict=self.best_value is None or value<self.best_value
        previous,previous_value=self.best,self.best_value
        self.attempts.append(row)
        if strict:self.best,self.best_value=row,value
        available=self.clock()
        eligible=self.deadline is None or available<=self.deadline
        row.update(available_seconds=available-self.started,eligible=bool(eligible),
                   strict_global_incumbent=bool(eligible and strict))
        if not eligible and strict:self.best,self.best_value=previous,previous_value
        self.registration_seconds+=self.clock()-began
        return row
