"""Exact strict-improvement search with a relaxed marginal suffix cost bound.

The bound is valid for reachable histories with nonnegative profiles and carbon
coefficients. It relaxes cross-row precedence and shared renewable competition.
Neither generic lower bounding nor this combination has established priority.
"""
import itertools
from cas_pfsp_v172.two_chain import JointViableChainTiming
from cas_pfsp_v166.marginal_bound import MarginalSuffixBound


class CostChainTiming(JointViableChainTiming):
    def __init__(self, instance, order, anchor, machine_rows, checkpoint=lambda phase: None):
        super().__init__(instance, order, anchor, machine_rows, checkpoint=checkpoint)
        chains = [[dict(profile=self.ctx.powers[j][a], earliest=self.domains[j, a][0],
                        latest=self.domains[j, a][1]) for j, a in chain] for chain in self.chains]
        self.cost_bound = MarginalSuffixBound(chains, self.background, self.ctx.renewable,
                                             self.ctx.carbon, checkpoint=checkpoint)
        self.cost_cuts = 0
        self.cost_cut_trace = []
        self.empty_frontier_certificate = False

    def run(self, trace_frontiers=False, trace_viability_cuts=False,
            trace_cost_cuts=False, on_improvement=lambda point: None):
        if self.started: raise ValueError('A chain DP object is single-use')
        if any(type(v) is not bool for v in (trace_frontiers, trace_viability_cuts, trace_cost_cuts)):
            raise ValueError('Boolean trace flags required')
        self.started = True; self.cut_trace_requested = trace_viability_cuts
        def trace(t):
            if trace_frontiers:
                self.frontier_trace.append(dict(time=t, states=[dict(work=list(k), prefix_numerator=r['cost'])
                    for k, r in sorted(self.layers[t].items())]))
        trace(0); self.checkpoint('chain_search_begin')
        for t in range(self.h):
            following = {}
            for state, record in self.layers[t].items():
                self.checkpoint('chain_frontier_state'); choices = []
                for index, k in enumerate(state):
                    op, offset, active = self.chain_tables[index][k]
                    if active:
                        j, a = op; choices.append([(1, self.ctx.powers[j][a][offset], None)])
                    else:
                        options = [(0, 0, None)]
                        if op is not None:
                            low, high = self.domains[op]
                            if low <= t <= high and all(done >= need for done, need in zip(state, self.requirements[op])):
                                j, a = op; options.append((1, self.ctx.powers[j][a][0], op))
                        choices.append(options)
                for chosen in itertools.product(*choices):
                    self.checkpoint('chain_transition'); self.transitions += 1
                    target = tuple(k + item[0] for k, item in zip(state, chosen))
                    if not self.viable(t + 1, target):
                        self.pruned_transition_targets += 1
                        if trace_viability_cuts: self.pruned_targets.add((t + 1, target))
                        continue
                    load = self.background[t] + sum(item[1] for item in chosen)
                    value = record['cost'] + self.ctx.carbon[t] * max(0, load - self.ctx.renewable[t])
                    self.checkpoint('marginal_cost_pruning_check')
                    lower = self.cost_bound.full_lower(t + 1, target, value)
                    if lower is None or lower >= self.best_value:
                        self.cost_cuts += 1
                        if trace_cost_cuts:
                            self.cost_cut_trace.append(dict(time=t + 1, work=list(target), prefix=value,
                                lower=lower, incumbent=self.best_value))
                        continue
                    if target not in following or value < following[target]['cost']:
                        following[target] = dict(cost=value, parent=state,
                            starts=[list(item[2]) for item in chosen if item[2] is not None])
                        self.state_updates += 1
            self.layers.append(following); trace(t + 1)
            if not following:
                self.checkpoint('chain_search_complete')
                self.empty_frontier_certificate = self.complete = True
                return self.summary()
            if self.goal in following:
                value = following[self.goal]['cost'] + self.background_tail[t + 1]
                if value < self.best_value:
                    self.checkpoint('chain_before_physical_candidate')
                    point = self.point(t + 1, self.goal, value)
                    on_improvement(point)
                    self.best_value = value; self.best_starts = [row[:] for row in point['starts']]
                    self.improvements += 1; self.checkpoint('chain_after_candidate')
            self.checkpoint('chain_layer_complete')
        assert self.goal in self.layers[-1]
        assert self.best_value == self.layers[-1][self.goal]['cost']
        self.checkpoint('chain_search_complete'); self.complete = True
        return self.summary()

    def summary(self):
        out = super().summary()
        out.update(cost_pruning='independent_chain_marginal_suffix_cost_plus_fixed_background',
            cost_pruned_transition_targets=self.cost_cuts, cost_cut_trace=self.cost_cut_trace,
            cost_bound_prepared_work_cells=self.cost_bound.prepared_cells,
            empty_strict_improvement_frontier_certificate=self.empty_frontier_certificate,
            unchanged_feasible_neighborhood_but_only_strict_improvements_retained=True,
            complete_paid_algorithm_or_common_core_budget_qualified=False,
            public_quality_or_priority_qualified=False)
        return out
