"""Experimental joint deadline and marginal-cost pruning inside paid row repair."""
