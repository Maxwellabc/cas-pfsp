"""Preserve extraction constraints and forbid positive-work history features.

This is a mathematical constrained-neighborhood builder, not a complete paid
ALNS. A forbidden/history region may be infeasible although the original CAS
instance is feasible. Permutation lists are converted to job-indexed ranks.
"""
from dataclasses import dataclass
from cas_pfsp_v45.model import validate_instance
from cas_pfsp_v118.compact_reference import build
from cas_pfsp_v147.extracted_model import build_extracted


def permutation(value,n):
    if not isinstance(value,(list,tuple)) or len(value)!=n or any(type(j) is not int for j in value) or sorted(value)!=list(range(n)):
        raise ValueError('Complete integer permutation required')
    return list(value)


@dataclass
class HistoryModel:
    physical:object
    extraction:dict
    rank_pairs:list
    positive_operations:list
    tabu_values:list
    tabu_attempt_ids:list


def build_history(instance,proposal,checkpoint=lambda phase:None):
    checkpoint('history_model_begin');validate_instance(instance)
    n,m,h,d=instance.n,instance.m,instance.horizon,instance.durations
    order=permutation(proposal['anchor_permutation'],n);kind=proposal['kind']
    if kind not in ('operation','machine','job','rank'):raise ValueError('Unknown history extraction kind')
    pairs=[]
    if kind=='rank':
        if proposal.get('free') is not None:raise ValueError('Rank-only extraction requires free=None')
        supplied=proposal['rank_pairs']
        for pair in supplied:
            if not isinstance(pair,(list,tuple)) or len(pair)!=2 or any(type(j) is not int for j in pair) or not all(0<=j<n for j in pair) or pair[0]==pair[1]:
                raise ValueError('Distinct valid integer rank pair required')
            pairs.append(list(pair))
        if len({tuple(pair) for pair in pairs})!=len(pairs):raise ValueError('Duplicate rank pair')
    elif proposal.get('rank_pairs') not in (None,[]):raise ValueError('Unexpected extra rank pairs for non-rank extraction')
    positive=[[j,a] for j in range(n) for a in range(m) if d[j][a]]
    expected={tuple(op) for op in positive};features=proposal.get('tabu_positive_features',[])
    if not isinstance(features,(list,tuple)):raise ValueError('History feature sequence required')
    values=[];ids=[];seen=set()
    for feature in features:
        checkpoint('history_feature_validate')
        ident=feature['attempt_id']
        if type(ident) is not int or ident<0 or ident in ids:raise ValueError('Distinct nonnegative history attempt IDs required')
        prior=permutation(feature['permutation'],n);positions=[0]*n
        for position,job in enumerate(prior):positions[job]=position
        start_map={}
        for row in feature['positive_starts']:
            if not isinstance(row,(list,tuple)) or len(row)!=3 or any(type(x) is not int for x in row):
                raise ValueError('Integer positive-start triples required')
            j,a,start=row
            if (j,a) not in expected or (j,a) in start_map:raise ValueError('Duplicate or nonpositive history operation')
            if not 0<=start<=h-d[j][a]:raise ValueError('History start outside horizon')
            start_map[j,a]=start
        if set(start_map)!=expected:raise ValueError('Every positive operation must appear in history')
        row=tuple(positions+[start_map[j,a] for j,a in positive]);ids.append(ident)
        if row not in seen:seen.add(row);values.append(list(row))
    checkpoint('history_before_physical_model')
    if kind=='rank':
        built=build(instance,checkpoint=checkpoint)
        extraction={'kind':'rank_only_history_extraction','anchor_order':order,'preserved_operation_precedences':[],
                    'forced_rank_pairs':[],'extra_explicit_rank_pairs':[],'fixed_operation_starts':[]}
        for i,j in pairs:
            checkpoint('history_rank_edge');built.model.add(built.ranks[i]<built.ranks[j])
    else:
        out=build_extracted(instance,order,kind,proposal['free'],checkpoint=checkpoint)
        built,extraction=out.physical,out.descriptor
    checkpoint('history_before_tabu_table')
    if values:
        columns=list(built.ranks)+[built.starts[j][a] for j,a in positive]
        built.model.add_forbidden_assignments(columns,values)
    checkpoint('history_model_validation');error=built.model.validate()
    if error:raise ValueError('History model validation:'+error)
    checkpoint('history_model_complete')
    return HistoryModel(built,extraction,pairs,positive,values,ids)
