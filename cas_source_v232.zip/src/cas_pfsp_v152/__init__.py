"""Exact extraction/history binding for a separately adapted CP control."""
