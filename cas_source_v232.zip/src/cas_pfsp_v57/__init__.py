"""Exact-chain research methods;generic DP is established prior art."""
