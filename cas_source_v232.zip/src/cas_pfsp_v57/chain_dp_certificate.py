"""Exact machine/job-chain timing best response, with the exterior fixed.

The serial timing DP is established (e.g., Vidal et al., Networks 2015,
doi:10.1002/net.21587). Neither DP nor chain neighborhoods are claimed new.
The CAS reduction uses the non-overlap of operations on the selected chain;
shared renewable supply is deducted only once from the aggregate load.
This module is NOT part of the frozen v56 five-arm quality experiment.
"""
from fractions import Fraction
import time

from cas_pfsp_v47.pair_timing import gross_profile, load_functional, marginal
from cas_pfsp_v53.minimum_closure import temporal_grid


def best_response(ctx, order, starts, kind, index, deadline=None):
    """Return the exact minimum over one whole machine or job timing chain.

    All other starts and the permutation stay fixed. Zero-duration nodes remain
    in the chain and its time windows. An incomplete DP raises TimeoutError;
    it never reports a neighborhood optimum or lower bound.
    """
    def check_time():
        if deadline is not None and time.perf_counter() >= deadline:
            raise TimeoutError('Chain DP incomplete; no optimality claim')

    check_time()
    grid = temporal_grid(ctx.durations, order, ctx.horizon)
    n, m = len(ctx.powers), len(ctx.powers[0])
    if len(starts) != n or any(len(row) != m for row in starts):
        raise ValueError('Rectangular feasible start matrix required')
    for j, a in grid.nodes:
        s = starts[j][a]
        if type(s) is not int or not grid.lower[j, a] <= s <= grid.upper[j, a]:
            raise ValueError('Feasible integer starts required')
        if any(s < starts[p][b] + ctx.durations[p][b] for p, b in grid.parents[j, a]):
            raise ValueError('Feasible precedence required')
    if type(index) is not int:
        raise ValueError('Integer chain index required')
    if kind == 'machine' and 0 <= index < m:
        chain = [(j, index) for j in order]
    elif kind == 'job' and 0 <= index < n:
        chain = [(index, a) for a in range(m)]
    else:
        raise ValueError('Valid machine or job chain required')
    members = set(chain)
    background = gross_profile(ctx, starts)
    for j, a in chain:
        for k, power in enumerate(ctx.powers[j][a]):
            background[starts[j][a] + k] -= power
    assert all(q >= 0 for q in background)
    base = load_functional(ctx, background)
    windows, costs, back, values = [], [], [], []
    previous = None
    states = 0
    for i, (j, a) in enumerate(chain):
        check_time()
        lo, hi = 0, ctx.horizon - ctx.durations[j][a]
        for p, b in grid.parents[j, a]:
            if (p, b) not in members:
                lo = max(lo, starts[p][b] + ctx.durations[p][b])
        for p, b in grid.children[j, a]:
            if (p, b) not in members:
                hi = min(hi, starts[p][b] - ctx.durations[j][a])
        assert lo <= starts[j][a] <= hi
        windows.append([lo, hi])
        row = [None] * (ctx.horizon + 1)
        parent = [None] * (ctx.horizon + 1)
        unary = [None] * (ctx.horizon + 1)
        best_value = best_time = None
        for t in range(hi + 1):
            if t % 32 == 0:
                check_time()
            if i:
                eligible = t - ctx.durations[chain[i-1][0]][chain[i-1][1]]
                if eligible >= 0 and previous[eligible] is not None:
                    value = previous[eligible]
                    if best_value is None or value < best_value:
                        best_value, best_time = value, eligible
            if t < lo or (i and best_value is None):
                continue
            unary[t] = marginal(ctx, background, (j, a), t)
            row[t] = unary[t] + (best_value if i else 0)
            parent[t] = best_time if i else None
            states += 1
        costs.append(unary)
        back.append(parent)
        values.append(row)
        previous = row
    value, t = min((v, t) for t, v in enumerate(previous) if v is not None)
    result = [list(row) for row in starts]
    for i in range(len(chain)-1, -1, -1):
        j, a = chain[i]
        result[j][a] = t
        if i:
            t = back[i][t]
    score = load_functional(ctx, gross_profile(ctx, result))
    assert score == base + value
    assert score <= load_functional(ctx, gross_profile(ctx, starts))
    check_time()
    return {'kind': kind, 'index': index, 'chain': [list(op) for op in chain],
            'starts': result, 'score_numerator': score,
            'score_fraction': str(Fraction(score, ctx.denominator)),
            'background_score_numerator': base, 'chain_increment_numerator': value,
            'external_windows': windows, 'DP_states': states,
            'scope': 'exact_selected_chain_exterior_and_permutation_fixed',
            'complete': True, 'frozen_v56_quality_policy_uses_this_module': False,
            'certificate': {'state_values': values, 'meaning': 'Finite Bellman labels; independently check every reachable state and physical objective'}}
