"""One core clock for internally initialized search and exact joint repairs.

This is an experimental complete heuristic, not a qualified new contribution.
The existing phase search provides paid ordering exploration, then deterministic
criticality-ranked cyclic windows select fixed-background timing neighborhoods.
Only a registered zero objective implies whole-problem optimality.
"""
from fractions import Fraction as F
from pathlib import Path
import math
import random
import time
from ortools.sat.python import cp_model
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context, gross_profile
from cas_pfsp_v64.registry import PhysicalRegistry
from cas_pfsp_v76.search import PhaseSearch
from cas_pfsp_v116.timed import Budget, Expired, Collector
from cas_pfsp_v122.neighborhood import build


class SliceExpired(Exception):
    pass


def point_key(row):
    return tuple(row['permutation']), tuple(x for line in row['starts'] for x in line), row['score_fraction']


def attempt_id(registry, point):
    return next(i for i, row in enumerate(registry.attempts) if row is point)


def select(ctx, anchor, maximum, attempted, poll, row):
    poll('selection_begin')
    gross = gross_profile(ctx, anchor['starts']); ranked = []; zero = []
    for j in range(len(ctx.powers)):
        for a in range(len(ctx.powers[0])):
            poll('selection_operation')
            if not ctx.durations[j][a]: zero.append((j, a)); continue
            loss = 0
            for offset, power in enumerate(ctx.powers[j][a]):
                t = anchor['starts'][j][a]+offset
                loss += ctx.carbon[t]*(max(0, gross[t]-ctx.renewable[t])-max(0, gross[t]-power-ctx.renewable[t]))
            ranked.append(((j, a), loss))
    ranked.sort(key=lambda item: (-item[1], item[0]))
    row['ranking'] = [{'operation': list(op), 'removal_score_fraction': str(F(loss, ctx.denominator))} for op, loss in ranked]
    operations = [op for op, _ in ranked]
    for size in reversed(range(1, min(maximum, len(operations))+1)):
        for offset in range(len(operations)):
            poll('selection_window')
            chosen = tuple(sorted(operations[(offset+k)%len(operations)] for k in range(size)))
            exterior = tuple((j, a, anchor['starts'][j][a]) for j, a in sorted(operations) if (j, a) not in chosen)
            key = tuple(anchor['permutation']), chosen, exterior
            if key in attempted: continue
            row.update(selected_positive_operations=[list(op) for op in chosen],
                free_operations=[list(op) for op in sorted(zero+list(chosen))],
                descriptor={'order': anchor['permutation'], 'positive_free': [list(op) for op in chosen],
                    'fixed_positive_starts': [list(x) for x in exterior]})
            return key
    return None


def repair(physical, ctx, registry, budget, cache, attempted, repairs, maximum, slice_seconds):
    anchor = registry.best; start = budget.now(); cutoff = min(budget.deadline, start+slice_seconds)
    row = {'id': len(repairs), 'anchor_attempt_id': attempt_id(registry, anchor),
        'started_seconds': start-budget.started, 'slice_deadline_seconds': cutoff-budget.started,
        'ranking': [], 'selected_positive_operations': None, 'free_operations': None,
        'descriptor': None, 'stages': [], 'proved_optimal_prefix': [],
        'neighborhood_proved_optimal': False, 'stop': None, 'returned_seconds': None,
        'registration_attempts_before': len(registry.attempts)}
    repairs.append(row); before = F(anchor['score_fraction']); built = None; last_integer = None

    def poll(phase):
        budget.poll(phase)
        if budget.now() >= cutoff: raise SliceExpired(phase)

    try:
        key = select(ctx, anchor, maximum, attempted, poll, row)
        row['selection_ready_seconds'] = budget.now()-budget.started
        if key is None:
            row['stop'] = 'declared_windows_exhausted'; return False
        attempted.add(key)
        poll('before_neighborhood_build')
        try:
            built = build(physical, anchor['permutation'], anchor['starts'], row['free_operations'], checkpoint=poll)
        except ValueError as error:
            if str(error) != 'Conservative CP-SAT int64 arithmetic guard exceeded': raise
            row['stop'] = 'unsupported_exact_integer_range'; return True
        row.update(model_ready_seconds=budget.now()-budget.started, arithmetic=built.arithmetic,
            objective_denominator=str(built.objective_denominator), objective_base=built.base, objective_digits=len(built.digits))
        for level in reversed(range(len(built.digits))):
            poll('before_digit_objective'); built.model.minimize(built.digits[level])
            solver = cp_model.CpSolver(); solver.parameters.num_search_workers = 1; solver.parameters.random_seed = 0
            solver.parameters.cp_model_presolve = True
            solver.parameters.absolute_gap_limit = 0; solver.parameters.relative_gap_limit = 0
            poll('before_CP_solve'); called = budget.now(); remaining = cutoff-called
            if remaining <= 0: raise SliceExpired('before_CP_solve')
            solver.parameters.max_time_in_seconds = remaining
            collector = Collector(built, budget, registry, cache, level)
            stage = {'digit': level, 'call_started_seconds': called-budget.started,
                'native_time_limit_seconds': remaining, 'native_status': None, 'returned_seconds': None,
                'events': collector.events, 'proof_used': False, 'proof_ready_seconds': None, 'optimal_digit_value': None}
            row['stages'].append(stage)
            status = solver.solve(built.model, collector)
            returned = budget.now(); stage.update(native_status=solver.status_name(status),
                returned_seconds=returned-budget.started, callbacks_skipped_after_deadline=collector.skipped_after_deadline)
            if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE, cp_model.UNKNOWN):
                raise RuntimeError('Valid anchored model lost feasibility or validity: '+stage['native_status'])
            if returned >= cutoff:
                row['stop'] = 'slice_after_CP_return'; break
            if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE): row['stop'] = 'native_unknown'; break
            last_integer, _ = collector.record(solver, 'CP_final_assignment')
            poll('after_final_registration')
            if status != cp_model.OPTIMAL: row['stop'] = 'native_feasible_without_digit_proof'; break
            value = int(solver.value(built.digits[level])); stage['optimal_digit_value'] = value
            built.model.add(built.digits[level] == value)
            ready = budget.now(); stage.update(proof_ready_seconds=ready-budget.started,
                proof_used=ready <= cutoff and ready <= budget.deadline)
            if not stage['proof_used']: row['stop'] = 'late_digit_proof'; break
            row['proved_optimal_prefix'].append({'digit': level, 'value': value, 'ready_seconds': ready-budget.started})
        else:
            row.update(neighborhood_proved_optimal=True, stop='all_neighborhood_digits_proved')
            assert last_integer is not None and F(registry.best['score_fraction']) == F(last_integer, built.objective_denominator)
    except SliceExpired as error:
        row['stop'] = 'slice_at_'+str(error)
    except Expired as error:
        row['stop'] = 'global_budget_at_'+str(error)
        raise
    finally:
        row.update(returned_seconds=budget.now()-budget.started, registration_attempts_after=len(registry.attempts),
            best_after_attempt_id=attempt_id(registry, registry.best),
            improved_global_best=F(registry.best['score_fraction']) < before)
    return True


def run_budgeted(loader, budget_seconds, seed=0, phase_fraction=.5, max_positive_free=3,
        repair_slice_seconds=.5, phase_max_evaluations=None, max_repairs=None, clock=time.perf_counter):
    if not math.isfinite(budget_seconds) or budget_seconds <= 0: raise ValueError('Positive finite core budget required')
    if not math.isfinite(phase_fraction) or not 0 < phase_fraction < 1: raise ValueError('Phase fraction must be strictly between0and1')
    if not math.isfinite(repair_slice_seconds) or repair_slice_seconds <= 0: raise ValueError('Positive finite repair slice required')
    if type(seed) is not int or type(max_positive_free) is not int or max_positive_free not in (1, 2, 3):
        raise ValueError('Integer seed and maximum positive free count1,2or3 required')
    for value in (phase_max_evaluations, max_repairs):
        if value is not None and (type(value) is not int or value < 1): raise ValueError('Positive integer diagnostic quota required')
    budget = Budget(float(budget_seconds), clock); cpu = time.process_time(); rng = random.getstate()
    physical = ctx = registry = None; phase_out = None; repairs = []; cache = {}; attempted = set(); setup = {}; reason = None
    try:
        budget.poll('before_input_load'); physical = loader()
        setup['input_loaded_seconds'] = budget.now()-budget.started
        budget.poll('after_input_load'); ctx = make_context(physical)
        setup['context_ready_seconds'] = budget.now()-budget.started
        registry = PhysicalRegistry(ctx, budget.started, budget.deadline, clock=budget.now)
        budget.poll('before_phase_component')
        phase_deadline = budget.started+phase_fraction*budget_seconds
        phase = PhaseSearch(ctx, budget.started, phase_deadline, 't1p1', seed, clock=budget.now,
            max_evaluations=phase_max_evaluations)
        # Shared dependency injection preserves every actually paid, globally
        # timely initializer incumbent, including a local-phase overrun.
        phase.registry = registry
        phase_out = phase.run()
        phase_out.pop('registered_attempts'); phase_best = phase_out.pop('best_registered')
        phase_out.update(physical_registry_attempt_range=[0, len(registry.attempts)],
            best_registered_attempt_id=None if phase_best is None else attempt_id(registry, phase_best),
            shared_root_physical_registry=True, returned_to_composition_seconds=budget.now()-budget.started)
        budget.poll('after_phase_component')
        for i, point in enumerate(registry.attempts): cache.setdefault(point_key(point), i)
        while True:
            budget.poll('before_repair')
            if registry.best is None: reason = 'no_paid_feasible_initializer'; break
            if registry.best_value == 0: reason = 'nonnegative_zero_attained'; break
            if max_repairs is not None and len(repairs) >= max_repairs: reason = 'diagnostic_repair_quota'; break
            if not repair(physical, ctx, registry, budget, cache, attempted, repairs, max_positive_free, repair_slice_seconds):
                reason = 'declared_windows_exhausted'; break
    except Expired as error:
        reason = 'global_budget_at_'+str(error)
    assert random.getstate() == rng
    best = None if registry is None else registry.best
    zero = best is not None and F(best['score_fraction']) == 0
    elapsed = budget.now()-budget.started
    return {'status': 'OPTIMAL' if zero else 'FEASIBLE' if best is not None else 'UNKNOWN', 'stop_reason': reason,
        'seed': seed, 'budget_seconds': budget_seconds, 'phase_fraction': phase_fraction, 'max_positive_free': max_positive_free,
        'repair_slice_seconds': repair_slice_seconds, 'phase_max_evaluations': phase_max_evaluations, 'max_repairs': max_repairs,
        'setup': setup, 'phase_component': phase_out, 'repairs': repairs,
        'registered_attempts': [] if registry is None else registry.attempts, 'best_registered': best,
        'registration_seconds': 0. if registry is None else registry.registration_seconds,
        'input_sha256': None if physical is None else physical.input_sha256,
        'algorithm_wall_seconds': elapsed, 'algorithm_cpu_seconds': time.process_time()-cpu,
        'overshoot_seconds': max(0., elapsed-budget_seconds), 'checkpoint_counts': budget.polls, 'last_checkpoint': budget.last_phase,
        'zero_global_objective_certified': zero, 'positive_global_optimum_claim': False,
        'all_initialization_selection_model_solver_callbacks_registration_and_policy_charged': True,
        'module_loading_and_final_JSON_serialization_excluded_like_frozen_core_contract': True,
        'shared_root_eligibility': 'available_seconds<=budget_seconds',
        'donated_initializer_or_external_cache': False, 'global_Python_RNG_unchanged': True,
        'hard_return_deadline_guaranteed': False, 'public_quality_or_algorithmic_priority_qualified': False}


def run_file(path, budget_seconds, **kwargs):
    path = Path(path).resolve()
    if 'neso_' in str(path).lower(): raise ValueError('Reserved path before content access')
    return run_budgeted(lambda: load_instance(path), budget_seconds, **kwargs)
