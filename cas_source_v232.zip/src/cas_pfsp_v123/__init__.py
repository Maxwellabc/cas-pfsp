"""Experimental paid phase search plus exact fixed-background CP repair."""
