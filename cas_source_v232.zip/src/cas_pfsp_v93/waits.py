"""Lean temporal construction of the already specified v92 wait controls.

Build only the chosen wait vector, without power/energy access, ancestor masks
or both raw and normalized encodings. The diagnostic v92 implementation is a
separate reference for all private source states.
"""


def wait_vector(durations, order, horizon, starts, normalized):
    if type(normalized) is not bool:
        raise ValueError('Boolean source normalization required')
    if type(horizon) is not int or horizon < 0:
        raise ValueError('Nonnegative integer horizon required')
    try:
        d=tuple(tuple(row) for row in durations)
        pi=tuple(order)
        s=tuple(tuple(row) for row in starts)
    except TypeError:
        raise ValueError('Rectangular temporal inputs required') from None
    n=len(d);m=len(d[0]) if n else 0
    if not n or not m or any(len(row)!=m for row in d):
        raise ValueError('Nonempty rectangular durations required')
    if any(type(x) is not int or x<0 for row in d for x in row):
        raise ValueError('Nonnegative integer durations required')
    if len(s)!=n or any(len(row)!=m for row in s):
        raise ValueError('Matching rectangular source starts required')
    if len(pi)!=n or any(type(j) is not int or not 0<=j<n for j in pi) or len(set(pi))!=n:
        raise ValueError('Complete integer source permutation required')
    anchor=None
    for pos,j in enumerate(pi):
        for a in range(m):
            value=s[j][a]
            if type(value) is not int or not 0<=value<=horizon-d[j][a]:
                raise ValueError('Integer source start inside horizon required')
            if a and value<s[j][a-1]+d[j][a-1]:
                raise ValueError('Source job precedence')
            if pos and value<s[pi[pos-1]][a]+d[pi[pos-1]][a]:
                raise ValueError('Source permutation-machine precedence')
            if normalized and d[j][a] and (anchor is None or value<anchor):anchor=value
    anchor=0 if anchor is None else anchor
    canonical=[[0]*m for _ in d];waits=[[0]*m for _ in d]
    for pos,j in enumerate(pi):
        for a in range(m):
            low=max(canonical[j][a-1]+d[j][a-1] if a else 0,
                    canonical[pi[pos-1]][a]+d[pi[pos-1]][a] if pos else 0)
            value=s[j][a]-anchor if d[j][a] else low
            if not low<=value<=horizon-d[j][a]:
                raise ArithmeticError('Canonical wait-source feasibility invariant')
            canonical[j][a]=value
            waits[j][a]=value-low if d[j][a] else 0
    return waits


def decode_on_grid(grid, waits):
    """Use the destination bounds already paid for by the complete search."""
    n=len(grid.durations);m=len(grid.durations[0])
    try:w=tuple(tuple(row) for row in waits)
    except TypeError:raise ValueError('Rectangular local waits required') from None
    if len(w)!=n or any(len(row)!=m for row in w):
        raise ValueError('Matching rectangular local waits required')
    if any(type(x) is not int or x<0 for row in w for x in row):
        raise ValueError('Nonnegative integer local waits required')
    if any(w[j][a] and not grid.durations[j][a] for j,a in grid.nodes):
        raise ValueError('Zero-duration nodes have no own wait')
    chosen={};result=[[0]*m for _ in range(n)]
    for op in grid.nodes:
        j,a=op
        low=max([0]+[chosen[p]+grid.durations[p[0]][p[1]] for p in grid.parents[op]])
        value=min(low+w[j][a],grid.upper[op]) if grid.durations[j][a] else low
        if not grid.lower[op]<=low<=value<=grid.upper[op]:
            raise ArithmeticError('Local-wait destination feasibility invariant')
        chosen[op]=result[j][a]=value
    return result
