"""Complete matched controls: one extra raw or normalized local-wait witness.

Keep all four v76 base witnesses and the inherited sequencing/phase policies.
Relative waits are established representation ideas; this is an explicit CAS
control, not a literal reproduction of another paper or a new encoding claim.
"""
import math
from pathlib import Path
import time

from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v53.minimum_closure import temporal_grid
from cas_pfsp_v64.registry import physical_numerator
from cas_pfsp_v69.projection import matrix,transplant
from cas_pfsp_v69.search import rng_sha
from cas_pfsp_v70.runtime import finish_metrics
from cas_pfsp_v76.phase import zero_aware_transplant
from cas_pfsp_v76.search import PhaseSearch
from .waits import wait_vector,decode_on_grid

MODES=('raw','normalized')


class RelativeWaitSearch(PhaseSearch):
    def __init__(self,ctx,started,deadline,mode,seed,**options):
        if mode not in MODES:raise ValueError('Unknown relative-wait mode')
        if type(started) not in (int,float) or type(deadline) not in (int,float) or not math.isfinite(started) or not math.isfinite(deadline) or deadline<=started:
            raise ValueError('Finite start and positive deadline required')
        if type(seed) is not int:raise ValueError('Typed integer private seed required')
        if 'stop_at_zero' in options and type(options['stop_at_zero']) is not bool:
            raise ValueError('Boolean zero-stop choice required')
        super().__init__(ctx,started,deadline,'t1p1',seed,**options)
        self.wait_mode=mode;self.wait_records=[];self._wait_cache=None

    def wait_target(self,source_id,evaluation):
        if type(source_id) is not int or not 0<=source_id<len(self.registry.attempts) or type(self.current) is not int or source_id!=self.current:
            raise ValueError('Typed current-run current source identifier required')
        if type(evaluation) is not int or evaluation<0:
            raise ValueError('Nonnegative typed evaluation identifier required')
        source=self.registry.attempts[source_id]
        if source['eligible'] is not True:raise ValueError('Eligible paid current source required')
        began=self.clock()
        if began>=self.deadline:return None,False,began-self.started
        if self._wait_cache is not None and self._wait_cache['source_attempt_id']==source_id:
            return self._wait_cache,True,began-self.started
        waits=wait_vector(self.ctx.durations,source['permutation'],self.ctx.horizon,source['starts'],
                          self.wait_mode=='normalized')
        record={'id':len(self.wait_records),'source_attempt_id':source_id,
                'built_on_evaluation':evaluation,'waits':waits,'started_seconds':began-self.started}
        self.wait_records.append(record)
        record['available_seconds']=self.clock()-self.started
        record['cache_admitted_at_availability_check']=record['available_seconds']<self.deadline-self.started
        if record['cache_admitted_at_availability_check']:self._wait_cache=record
        return record,False,began-self.started

    def evaluate(self,order,reason,move=None):
        ix=len(self.evaluations)
        row={'id':ix,'order':list(order),'reason':reason,'move':move,
             'rng_before_sha256':rng_sha(self.rng),'current_before_attempt_id':self.current,
             'witnesses':[],'phase_calls':[],'accepted':False,'wait_decision':None,
             'started_seconds':self.clock()-self.started}
        self.evaluations.append(row)
        try:grid=temporal_grid(self.ctx.durations,order,self.ctx.horizon)
        except ValueError as error:
            if str(error)!='Fixed order has no feasible timing':raise
            row.update(status='infeasible_order',returned_seconds=self.clock()-self.started)
            return False
        proposed=[('earliest',matrix(grid,grid.lower)),('latest',matrix(grid,grid.upper))]
        if self.current is not None:
            target=self.registry.attempts[self.current]['starts']
            proposed.extend([('transplant',transplant(grid,target)),
                             ('zero_aware_transplant',zero_aware_transplant(grid,target))])
            requested=self.clock()-self.started
            record,hit,began=self.wait_target(self.current,ix)
            included=record is not None and record['available_seconds']<self.deadline-self.started
            event={'source_attempt_id':self.current,'requested_seconds':requested,
                   'lookup_started_seconds':began,'wait_record_id':None if record is None else record['id'],
                   'cache_hit':hit,'wait_witness_constructed':included}
            row['wait_decision']=event
            if included:
                proposed.append(('local_wait_'+self.wait_mode,decode_on_grid(grid,record['waits'])))
            event['construction_finished_seconds']=self.clock()-self.started
        seen,eligible,raw=set(),[],[]
        for source,starts in proposed:
            key=tuple(tuple(r) for r in starts)
            if key in seen:continue
            seen.add(key)
            if self.clock()>=self.deadline:break
            value=physical_numerator(self.ctx,order,starts)
            receipt=self.register(order,starts,value,{'kind':'raw_witness','evaluation':ix,'source':source})
            row['witnesses'].append({'source':source,**receipt})
            if receipt['eligible']:
                eligible.append(receipt['attempt_id']);raw.append((source,starts,value))
        for source,starts,value in raw:
            if self.clock()>=self.deadline:break
            call=self.scanner.scan(grid,starts,value,
                lambda s,v,o:self.register(order,s,v,{**o,'evaluation':ix,'source':source}),
                {'evaluation':ix,'source':source})
            row['phase_calls'].append(call['id'])
            eligible.extend(z['attempt_id'] for z in call['registrations'] if z['eligible'])
        selected=min(eligible,key=self.score) if eligible else None
        ready=self.clock()
        strict=selected is not None and (self.current is None or self.score(selected)<self.score(self.current))
        accept=selected is not None and ready<self.deadline and (strict or reason=='shake')
        if accept:self.current=selected
        if selected is not None and ready<self.deadline and (self.best_search is None or self.score(selected)<self.score(self.best_search)):
            self.best_search=selected
        row.update(status='evaluated',selected_attempt_id=selected,decision_ready_seconds=ready-self.started,
                   accepted=bool(accept),strict_improvement=bool(accept and strict),
                   current_after_attempt_id=self.current,returned_seconds=self.clock()-self.started)
        return accept

    def run(self):
        result=super().run()
        result.update(relative_wait_mode=self.wait_mode,wait_records=self.wait_records,
                      wait_source_cache_capacity=1,wait_sources_current_run_only=True,
                      additional_wait_witness_policy='always_after_four_base_witnesses',
                      relative_wait_control_not_literal_prior_solver=True)
        result['algorithm_wall_seconds']=self.clock()-self.started
        return result


def run_search(input_path,mode,seed,budget_seconds,**options):
    p=Path(input_path).resolve()
    if 'neso_' in str(p).lower():raise ValueError('Reserved path before read')
    if type(budget_seconds) not in (int,float) or not math.isfinite(budget_seconds) or budget_seconds<=0:
        raise ValueError('Finite positive wall budget required')
    if mode not in MODES:raise ValueError('Unknown relative-wait mode')
    if type(seed) is not int:raise ValueError('Typed integer private seed required')
    started,cpu=time.perf_counter(),time.process_time()
    physical=load_instance(p);ctx=make_context(physical)
    result=RelativeWaitSearch(ctx,started,started+budget_seconds,mode,seed,**options).run()
    return finish_metrics(result,cpu,physical.input_sha256)
