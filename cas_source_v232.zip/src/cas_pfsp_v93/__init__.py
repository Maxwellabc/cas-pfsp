"""Complete relative-wait control policies in the accepted CAS model."""
