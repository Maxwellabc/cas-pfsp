"""Exact local-record registration pruning with a hybrid phase kernel."""
