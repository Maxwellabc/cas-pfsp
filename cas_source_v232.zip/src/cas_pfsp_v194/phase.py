"""Exact v192 scan with an explicit safe dominance threshold update.

A skipped phase point is never eligible. Its exact score may still tighten the
per-orbit request threshold when an earlier physically eligible evaluation point
already dominates it. Selection only references actually registered candidates.
"""
from cas_pfsp_v76.phase import PhaseScanner, geometry
from cas_pfsp_v192.phase import ExactPhaseKernel

class PrunedBatchScanner(PhaseScanner):
    batch_size = 16

    def scan(self, grid, starts, raw_value, register, origin):
        row = {'id': len(self.calls), 'origin': origin, 'phase_values': [],
               'registrations': [], 'cache_source_call': None,
               'all_phases_scanned': False, 'orbit_optimality_certified': False,
               'certificate_available_before_deadline': False,
               'started_seconds': self.clock() - self.started, 'batch_kernels': []}
        self.calls.append(row)
        if self.clock() >= self.deadline:
            row.update(stop='deadline_before_geometry', returned_seconds=self.clock() - self.started)
            return row
        shape = geometry(self.ctx, grid, starts)
        row.update(anchor=shape.anchor, span=shape.span, profile=list(shape.profile),
                   positive_operations=shape.positive_operations,
                   phase_domain_size=len(shape.phases(self.ctx.horizon)))
        best, phase, local_registered = None, None, raw_value
        if shape.key in self.cache:
            old = self.cache[shape.key]
            self.cache.move_to_end(shape.key)
            best, phase = old['value'], old['phase']
            row.update(cache_source_call=old['call'], orbit_optimality_certified=True,
                       stop='complete_current_run_orbit_cache')
            if self.clock() < self.deadline and best < raw_value:
                receipt = register(shape.materialize(grid, phase), best,
                    {'kind': 'phase_cache', 'phase_call': row['id'], 'source_call': old['call'], 'phase': phase})
                row['registrations'].append(receipt)
        else:
            domain = shape.phases(self.ctx.horizon)
            stopped = False
            for begin in range(0, len(domain), self.batch_size):
                if self.clock() >= self.deadline:
                    row['stop'] = 'deadline_before_batch'
                    break
                ts = domain[begin:begin + self.batch_size]
                if not hasattr(self, '_exact_kernel'):
                    self._exact_kernel = ExactPhaseKernel(self.ctx)
                values, kernel = self._exact_kernel.values(shape, ts)
                row['batch_kernels'].append(kernel)
                for t, value in zip(ts, values):
                    if self.clock() >= self.deadline:
                        row['stop'] = 'deadline_before_phase_consumption'
                        stopped = True
                        break
                    row['phase_values'].append([t, value])
                    if best is None or value < best:
                        best, phase = value, t
                    if self.clock() < self.deadline and value < local_registered:
                        receipt = register(shape.materialize(grid, t), value,
                            {'kind': 'phase_scan', 'phase_call': row['id'], 'phase': t})
                        row['registrations'].append(receipt)
                        if receipt['eligible'] or receipt.get('safely_dominated', False):
                            local_registered = value
                    if value == 0:
                        row.update(stop='nonnegative_objective_zero_orbit_certificate', orbit_optimality_certified=True)
                        stopped = True
                        break
                if stopped:
                    break
            row['all_phases_scanned'] = len(row['phase_values']) == row['phase_domain_size']
            if row['all_phases_scanned']:
                row.update(orbit_optimality_certified=True, stop='all_phases_scanned')
            if row['orbit_optimality_certified'] and self.clock() < self.deadline:
                if len(self.cache) >= self.capacity:
                    self.cache.popitem(last=False)
                self.cache[shape.key] = {'value': best, 'phase': phase, 'call': row['id']}
        at = self.clock()
        available = bool(row['orbit_optimality_certified'] and at < self.deadline)
        row.update(best_computed_value=best, best_computed_phase=phase,
                   certificate_available_before_deadline=available,
                   certificate_available_seconds=at - self.started if available else None,
                   returned_seconds=self.clock() - self.started)
        return row
