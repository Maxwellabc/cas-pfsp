"""Skip physically registering phase points dominated within one evaluation.

Every raw witness is still physically registered, all phase shapes are scanned,
and every strict evaluation record is physically registered. A skipped phase
point cannot affect the selected physical schedule under nonbinding clocks.
This is incumbent-based implementation pruning, not a new metaheuristic claim.
"""
from pathlib import Path
import math
import time
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v70.runtime import finish_metrics
from cas_pfsp_v193.search import HybridWaitSearch, HybridKernel
from .phase import PrunedBatchScanner


class RecordPrunedWaitSearch(HybridWaitSearch):
    def __init__(self, ctx, started, deadline, seed, **options):
        super().__init__(ctx, started, deadline, seed, **options)
        self.scanner = PrunedBatchScanner(ctx, started, deadline, self.clock, self.scanner.capacity)
        self.scanner._exact_kernel = HybridKernel(ctx)
        self._bound_evaluation = None
        self._bound_score = self._bound_attempt = None
        self.dominated_registration_events = []

    def register(self, order, starts, value, origin):
        evaluation = origin['evaluation']
        if evaluation != self._bound_evaluation:
            self._bound_evaluation = evaluation
            self._bound_score = self._bound_attempt = None
        if (origin['kind'] in ('phase_scan', 'phase_cache') and self._bound_score is not None
                and value >= self._bound_score):
            available = self.clock() - self.started
            self.dominated_registration_events.append(dict(
                evaluation=evaluation, origin=dict(origin), score_numerator=value,
                dominating_attempt_id=self._bound_attempt,
                dominating_score_numerator=self._bound_score, decided_seconds=available))
            return dict(attempt_id=None, eligible=False, available_seconds=available,
                        skipped_as_evaluation_dominated=True, safely_dominated=True)
        receipt = super().register(order, starts, value, origin)
        if receipt['eligible'] and (self._bound_score is None or value < self._bound_score):
            self._bound_score, self._bound_attempt = value, receipt['attempt_id']
        return receipt

    def run(self):
        out = super().run()
        out.update(exact_acceleration_version='v194',
            dominated_registration_events=self.dominated_registration_events,
            pruning_rule='phase_value>=earlier_eligible_same_evaluation_record',
            raw_witnesses_and_all_phase_shapes_retained=True,
            nonbinding_clock_selected_schedule_equivalence_claim=True,
            universal_walltime_superiority_claim=False)
        return out


def run_file(input_path, budget_seconds, seed=0, **options):
    p = Path(input_path).resolve()
    if 'neso_' in str(p).lower(): raise ValueError('Reserved path before read')
    if type(budget_seconds) not in (int, float) or not math.isfinite(budget_seconds) or budget_seconds <= 0:
        raise ValueError('Finite positive wall budget required')
    started, cpu = time.perf_counter(), time.process_time()
    physical = load_instance(p); ctx = make_context(physical)
    result = RecordPrunedWaitSearch(ctx, started, started + budget_seconds, seed, **options).run()
    return finish_metrics(result, cpu, physical.input_sha256)
