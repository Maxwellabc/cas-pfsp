"""Lazy initial witnesses and exact forward/backward NEH insertion costs.

NEH and its forward/backward acceleration are established methods, not new
algorithms. Ties follow the original full permutation lexicographic rule.
"""


def insertion_makespans(durations, order, job):
    m, k = len(durations[0]), len(order)
    forward = [[0] * m for _ in range(k + 1)]
    backward = [[0] * m for _ in range(k + 1)]
    for i, j in enumerate(order):
        for a in range(m):
            forward[i + 1][a] = max(forward[i][a], forward[i + 1][a - 1] if a else 0) + durations[j][a]
    for i in range(k - 1, -1, -1):
        for a in range(m - 1, -1, -1):
            backward[i][a] = max(backward[i + 1][a], backward[i][a + 1] if a + 1 < m else 0) + durations[order[i]][a]
    costs = []
    for p in range(k + 1):
        end, cost = 0, 0
        for a in range(m):
            end = max(end, forward[p][a]) + durations[job][a]
            cost = max(cost, end + backward[p][a])
        costs.append(cost)
    return costs


def accelerated_neh(durations):
    ranked = sorted(range(len(durations)), key=lambda j: (-sum(durations[j]), j))
    order = []
    for job in ranked:
        costs = insertion_makespans(durations, order, job)
        best = min(costs)
        order = min(order[:p] + [job] + order[p:] for p, c in enumerate(costs) if c == best)
    return order, ranked


def initial_orders(ctx):
    n, seen = len(ctx.durations), set()
    for order in (list(range(n)), list(reversed(range(n)))):
        key = tuple(order)
        if key not in seen:
            seen.add(key)
            yield order
    # No NEH work precedes the two cheap witnesses above.
    neh, ranked = accelerated_neh(ctx.durations)
    for order in (neh, ranked, list(reversed(ranked))):
        key = tuple(order)
        if key not in seen:
            seen.add(key)
            yield order
