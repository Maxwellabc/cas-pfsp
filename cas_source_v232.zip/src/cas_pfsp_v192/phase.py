"""Bounded exact phase batches, including coefficients exceeding int64.

Limb subtraction is exact. Every limb-weighted carbon sum is bounded before
int64 arithmetic. Unsupported magnitudes use the arbitrary-integer reference.
Physical registrations, geometry validation, deadline checks and orbit cache
remain charged. No scalar score becomes an incumbent without registration.
"""
import numpy as np
from cas_pfsp_v76.phase import PhaseScanner, geometry, phase_value

LIMIT = (1 << 63) - 1


class ExactPhaseKernel:
    def __init__(self, ctx):
        self.ctx = ctx
        self.cmax = max(ctx.carbon, default=0)
        max_digit = LIMIT // max(1, ctx.horizon * self.cmax)
        self.bits = min(26, (max_digit + 1).bit_length() - 1)
        self.fallback = self.bits < 1 or self.cmax > LIMIT
        self.carbon = None if self.fallback else np.asarray(ctx.carbon, dtype=np.int64)
        load_bound = sum(p for job in ctx.powers for op in job for p in op)
        largest = max(load_bound, max(ctx.renewable, default=0))
        self.direct = not self.fallback and largest <= LIMIT and ctx.horizon * load_bound * self.cmax <= LIMIT
        self.renewable = None
        self.digits = []
        if self.direct:
            self.renewable = np.asarray(ctx.renewable, dtype=np.int64)
        elif not self.fallback:
            base = 1 << self.bits
            assert ctx.horizon * (base - 1) * self.cmax <= LIMIT
            limbs = max(1, (largest.bit_length() + self.bits - 1) // self.bits)
            self.digits = [np.asarray([(v >> (l * self.bits)) & (base - 1) for v in ctx.renewable], dtype=np.int64) for l in range(limbs)]

    def values(self, shape, phases):
        phases = tuple(phases)
        if not phases:
            return [], 'empty'
        if not shape.profile or not self.cmax:
            return [0] * len(phases), 'zero_or_empty'
        if self.fallback:
            return [phase_value(self.ctx, shape, t) for t in phases], 'python_integer_fallback'
        width = len(shape.profile)
        # Scanner batches are consecutive; advanced indexing also supports QA probes.
        contiguous = phases == tuple(range(phases[0], phases[0] + len(phases)))
        select = slice(phases[0], phases[-1] + 1) if contiguous else list(phases)
        windows = np.lib.stride_tricks.sliding_window_view
        carbon = windows(self.carbon, width)[select]
        if self.direct:
            q = np.asarray(shape.profile, dtype=np.int64)
            r = windows(self.renewable, width)[select]
            out = np.sum(np.maximum(q - r, 0) * carbon, axis=1, dtype=np.int64)
            return [int(v) for v in out], 'bounded_int64_direct'
        base, digits = 1 << self.bits, []
        borrow = np.zeros((len(phases), width), dtype=np.int64)
        for l, renewable in enumerate(self.digits):
            q = np.asarray([(v >> (l * self.bits)) & (base - 1) for v in shape.profile], dtype=np.int64)
            r = windows(renewable, width)[select]
            delta = q - r - borrow
            borrow = (delta < 0).astype(np.int64)
            digits.append(delta + borrow * base)
        positive = borrow == 0
        sums = [np.sum(np.where(positive, d, 0) * carbon, axis=1, dtype=np.int64) for d in digits]
        values = [sum(int(sums[l][i]) << (l * self.bits) for l in range(len(digits))) for i in range(len(phases))]
        return values, 'bounded_int64_limbs'


def batch_values(ctx, shape, phases):
    return ExactPhaseKernel(ctx).values(shape, phases)


class ExactBatchScanner(PhaseScanner):
    batch_size = 16

    def scan(self, grid, starts, raw_value, register, origin):
        row = {'id': len(self.calls), 'origin': origin, 'phase_values': [],
               'registrations': [], 'cache_source_call': None,
               'all_phases_scanned': False, 'orbit_optimality_certified': False,
               'certificate_available_before_deadline': False,
               'started_seconds': self.clock() - self.started, 'batch_kernels': []}
        self.calls.append(row)
        if self.clock() >= self.deadline:
            row.update(stop='deadline_before_geometry', returned_seconds=self.clock() - self.started)
            return row
        shape = geometry(self.ctx, grid, starts)
        row.update(anchor=shape.anchor, span=shape.span, profile=list(shape.profile),
                   positive_operations=shape.positive_operations,
                   phase_domain_size=len(shape.phases(self.ctx.horizon)))
        best, phase, local_registered = None, None, raw_value
        if shape.key in self.cache:
            old = self.cache[shape.key]
            self.cache.move_to_end(shape.key)
            best, phase = old['value'], old['phase']
            row.update(cache_source_call=old['call'], orbit_optimality_certified=True,
                       stop='complete_current_run_orbit_cache')
            if self.clock() < self.deadline and best < raw_value:
                receipt = register(shape.materialize(grid, phase), best,
                    {'kind': 'phase_cache', 'phase_call': row['id'], 'source_call': old['call'], 'phase': phase})
                row['registrations'].append(receipt)
        else:
            domain = shape.phases(self.ctx.horizon)
            stopped = False
            for begin in range(0, len(domain), self.batch_size):
                if self.clock() >= self.deadline:
                    row['stop'] = 'deadline_before_batch'
                    break
                ts = domain[begin:begin + self.batch_size]
                if not hasattr(self, '_exact_kernel'):
                    self._exact_kernel = ExactPhaseKernel(self.ctx)
                values, kernel = self._exact_kernel.values(shape, ts)
                row['batch_kernels'].append(kernel)
                for t, value in zip(ts, values):
                    if self.clock() >= self.deadline:
                        row['stop'] = 'deadline_before_phase_consumption'
                        stopped = True
                        break
                    row['phase_values'].append([t, value])
                    if best is None or value < best:
                        best, phase = value, t
                    if self.clock() < self.deadline and value < local_registered:
                        receipt = register(shape.materialize(grid, t), value,
                            {'kind': 'phase_scan', 'phase_call': row['id'], 'phase': t})
                        row['registrations'].append(receipt)
                        if receipt['eligible']:
                            local_registered = value
                    if value == 0:
                        row.update(stop='nonnegative_objective_zero_orbit_certificate', orbit_optimality_certified=True)
                        stopped = True
                        break
                if stopped:
                    break
            row['all_phases_scanned'] = len(row['phase_values']) == row['phase_domain_size']
            if row['all_phases_scanned']:
                row.update(orbit_optimality_certified=True, stop='all_phases_scanned')
            if row['orbit_optimality_certified'] and self.clock() < self.deadline:
                if len(self.cache) >= self.capacity:
                    self.cache.popitem(last=False)
                self.cache[shape.key] = {'value': best, 'phase': phase, 'call': row['id']}
        at = self.clock()
        available = bool(row['orbit_optimality_certified'] and at < self.deadline)
        row.update(best_computed_value=best, best_computed_phase=phase,
                   certificate_available_before_deadline=available,
                   certificate_available_seconds=at - self.started if available else None,
                   returned_seconds=self.clock() - self.started)
        return row
