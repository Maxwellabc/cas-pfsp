"""A complete raw-wait search with exact acceleration and unchanged decisions.

No new representation or metaheuristic priority claim. With nonbinding clocks,
the initializer permutations, phase order, physical candidates, RNG decisions
and incumbent sequence must equal v93 at each completed evaluation.
"""
from pathlib import Path
import math
import random
import time
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v69.search import insertion_orders, rng_sha
from cas_pfsp_v70.runtime import finish_metrics
from cas_pfsp_v93.search import RelativeWaitSearch
from .initialization import initial_orders
from .phase import ExactBatchScanner


class AcceleratedWaitSearch(RelativeWaitSearch):
    def __init__(self, ctx, started, deadline, seed, **options):
        super().__init__(ctx, started, deadline, 'raw', seed, **options)
        self.scanner = ExactBatchScanner(ctx, started, deadline, self.clock, self.scanner.capacity)

    def run(self):
        before = random.getstate()
        for order in initial_orders(self.ctx):
            if not self.live():
                break
            self.evaluate(order, 'initialization')
        while self.live():
            if self.current is None:
                order = list(range(len(self.ctx.durations)))
                self.rng.shuffle(order)
                self.evaluate(order, 'feasibility_search')
                continue
            order = self.registry.attempts[self.current]['permutation']
            improved = False
            for proposed, move in insertion_orders(order, self.rng):
                if not self.live():
                    break
                if self.evaluate(proposed, 'insertion', move):
                    improved = True
                    break
            if not self.live():
                break
            if improved:
                continue
            order = list(self.registry.attempts[self.best_search]['permutation'])
            for _ in range(min(3, len(order))):
                if len(order) > 1:
                    i, j = self.rng.sample(range(len(order)), 2)
                    job = order.pop(i)
                    order.insert(j, job)
            self.evaluate(order, 'shake')
        assert random.getstate() == before
        return {'policy': self.policy, 'seed': self.seed, 'transfer_enabled': self.transfer,
                'phase_enabled': self.phase, 'zero_aware_enabled': self.zero_aware,
                'evaluations': self.evaluations, 'phase_calls': self.scanner.calls,
                'registered_attempts': self.registry.attempts, 'best_registered': self.registry.best,
                'current_attempt_id': self.current, 'best_search_attempt_id': self.best_search,
                'rng_after_sha256': rng_sha(self.rng), 'global_Python_rng_unchanged': True,
                'budget_seconds': self.deadline - self.started, 'max_evaluations': self.max_evaluations,
                'stop_at_zero': self.stop_at_zero, 'algorithm_wall_seconds': self.clock() - self.started,
                'phase_cache_capacity': self.scanner.capacity,
                'physical_denominator_for_audit': self.ctx.denominator,
                'all_setup_registration_cache_and_logging_charged': True,
                'donated_initializer_or_external_cache': False, 'timing_DP_calls': 0,
                'global_or_fixed_order_timing_optimum_claim': False,
                'relative_wait_mode': 'raw', 'wait_records': self.wait_records,
                'wait_source_cache_capacity': 1, 'wait_sources_current_run_only': True,
                'additional_wait_witness_policy': 'always_after_four_base_witnesses',
                'relative_wait_control_not_literal_prior_solver': True,
                'exact_acceleration_version': 'v192', 'lazy_NEH': True,
                'new_metaheuristic_priority_claim': False}


def run_file(input_path, budget_seconds, seed=0, **options):
    p = Path(input_path).resolve()
    if 'neso_' in str(p).lower():
        raise ValueError('Reserved path before read')
    if type(budget_seconds) not in (int, float) or not math.isfinite(budget_seconds) or budget_seconds <= 0:
        raise ValueError('Finite positive wall budget required')
    started, cpu = time.perf_counter(), time.process_time()
    physical = load_instance(p)
    ctx = make_context(physical)
    result = AcceleratedWaitSearch(ctx, started, started + budget_seconds, seed, **options).run()
    return finish_metrics(result, cpu, physical.input_sha256)
