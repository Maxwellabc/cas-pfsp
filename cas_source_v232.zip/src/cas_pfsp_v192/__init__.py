"""Exact arithmetic and initialization acceleration of the raw-wait control."""
