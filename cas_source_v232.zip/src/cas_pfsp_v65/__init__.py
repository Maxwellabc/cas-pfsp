"""Experimental resumable fixed-permutation timing primitives."""
