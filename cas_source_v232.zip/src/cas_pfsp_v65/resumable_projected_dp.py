"""In-memory suspension of the accepted positive-chain product DP.

The generator keeps construction cursors,partial layers and backpointers.
Suspension is cooperative,not hard real time. A checkpoint is neither a DP
state nor an optimality certificate. Only terminal exhaustive traversal (or
a zero feasible upper bound) proves the declared neighborhood optimum.

The search domain includes the instance,permutation,selected/fixed machines
and fixed exterior positive starts. All zero-time nodes remain free. A
strictly tighter feasible incumbent in that same domain can only strengthen
upper-bound pruning: states previously cut at cost+LB>=oldU remain cut at
newU<=oldU. State limits apply cumulatively to the entire engine lifetime.

This is an adaptation of the frozen v59 DP,not a claim that generator-based
suspension,DP or precedence projection is new. No native search is invoked.
"""
import copy
from fractions import Fraction as F
import hashlib
import itertools
import json
import time

from cas_pfsp_v47.pair_timing import gross_profile, load_functional
from cas_pfsp_v49.timing_pairs import lift_zero_operations
from cas_pfsp_v53.minimum_closure import temporal_grid
from cas_pfsp_v64.registry import physical_numerator


def domain_signature(ctx, order, initial, machines, fixed_positive_machines=()):
    """Exact immutable signature,including model coefficients and zero policy."""
    n, m = len(ctx.powers), len(ctx.powers[0])
    pair = tuple(sorted(machines))
    fixed = tuple(sorted(fixed_positive_machines))
    if (len(pair) != 2 or len(set(pair)) != 2 or
        any(type(a) is not int or not 0 <= a < m for a in pair)):
        raise ValueError('Two distinct machine indices required')
    if len(set(fixed)) != len(fixed) or not set(fixed) <= set(pair) or len(fixed) == 2:
        raise ValueError('At least one selected machine must remain variable')
    if any(type(a) is not int for a in fixed):
        raise ValueError('Integer fixed machine indices required')
    # Validates the complete permutation,dimensions,H/zero and precedence.
    physical_numerator(ctx, order, initial)
    variable = set(pair) - set(fixed)
    exterior = tuple((j, a, initial[j][a]) for j in order for a in range(m)
                     if a not in variable and ctx.durations[j][a])
    return (ctx.powers, ctx.renewable, ctx.carbon, ctx.denominator,
            ctx.horizon, ctx.durations, tuple(order), pair, fixed, exterior,
            'all_zero_nodes_free')


class ResumableProjectedDP:
    def __init__(self, ctx, order, initial, machines, fixed_positive_machines=(),
                 bound_mode='residual', state_limit=2_000_000, clock=time.perf_counter):
        self.clock = clock
        self.begun = clock()
        if bound_mode not in ('background', 'residual'):
            raise ValueError('Unknown admissible bound')
        if type(state_limit) is not int or state_limit < 1:
            raise ValueError('Positive cumulative state limit required')
        if any(x < 0 for x in ctx.carbon + ctx.renewable) or any(
                x < 0 for job in ctx.powers for op in job for x in op):
            raise ValueError('Nonnegative CAS coefficients required')
        self.signature = domain_signature(ctx, order, initial, machines, fixed_positive_machines)
        self.fingerprint = hashlib.sha256(json.dumps(self.signature, separators=(',', ':')).encode()).hexdigest()
        self.ctx, self.order = ctx, tuple(order)
        self.initial = [list(row) for row in initial]
        self.pair = tuple(sorted(machines))
        self.fixed = tuple(sorted(fixed_positive_machines))
        self.mode, self.state_limit = bound_mode, state_limit
        self.best = copy.deepcopy(self.initial)
        self.initial_value = self.upper_value = physical_numerator(ctx, list(order), initial)
        self.events, self.offers = [], []
        self.published = 0
        self.generated, self.expanded, self.transitions, self.normalized_count = 1, 0, 0, 0
        self.checkpoints = self.advance_calls = 0
        self.phase, self.time_layer = 'not_started', None
        self.tables = None
        self.bound_entries = self.bound_finite = 0
        self.bound_complete = bound_mode == 'background' or self.upper_value == 0
        self.bound_metadata = None
        self.kernel_step_seconds = self.bound_step_seconds = 0.
        self.terminal_reason = None
        self._iterator = self._work()

    def matches(self, ctx, order, starts, machines=None, fixed_positive_machines=None):
        pair = self.pair if machines is None else machines
        fixed = self.fixed if fixed_positive_machines is None else fixed_positive_machines
        return domain_signature(ctx, order, starts, pair, fixed) == self.signature

    def offer_incumbent(self, ctx, order, starts):
        """Tighten only with a fully feasible schedule in exactly this domain."""
        if not self.matches(ctx, order, starts):
            raise ValueError('Changed instance,permutation or fixed exterior invalidates the frontier')
        value = physical_numerator(self.ctx, list(self.order), starts)
        if value >= self.upper_value:
            return False
        if self.terminal_reason in ('complete_exact_neighborhood', 'nonnegative_objective_zero_upper'):
            raise ValueError('A strict improvement contradicts the completed neighborhood certificate')
        self.best, self.upper_value = [list(row) for row in starts], value
        self.offers.append({'starts': copy.deepcopy(self.best), 'score_numerator': value,
                            'after_checkpoints': self.checkpoints})
        return True

    def _publish(self, deadline, on_improvement):
        # A solution reconstructed during a nonpreemptible overrun can be
        # published at a later call. Nothing is backdated to the earlier slice.
        while self.published < len(self.events):
            if deadline is not None and self.clock() >= deadline:
                return
            event = self.events[self.published]
            if on_improvement is not None:
                on_improvement(copy.deepcopy(event['starts']), event['score_numerator'])
            self.published += 1

    def advance(self, deadline=None, maximum_checkpoints=None, on_improvement=None,
                capture_bound_certificate=False):
        """Run paid cooperative units,then return a copy of the current state.

        maximum_checkpoints is a deterministic test/work quota,not a time
        budget or a reset of state_limit. A partially processed layer and its
        iterator remain alive;no sorted-prefix or bound-table rebuild occurs.
        """
        if maximum_checkpoints is not None and (type(maximum_checkpoints) is not int or maximum_checkpoints < 0):
            raise ValueError('Nonnegative checkpoint quota required')
        self.advance_calls += 1
        first = self.checkpoints
        self._publish(deadline, on_improvement)
        stop = 'checkpoint_quota'
        while self.terminal_reason is None:
            if deadline is not None and self.clock() >= deadline:
                stop = 'deadline'
                break
            if maximum_checkpoints is not None and self.checkpoints - first >= maximum_checkpoints:
                break
            tick, phase = self.clock(), self.phase
            try:
                next(self._iterator)
                self.checkpoints += 1
            except StopIteration as done:
                self.terminal_reason = done.value
            spent = self.clock() - tick
            self.kernel_step_seconds += spent
            if phase == 'bound_preparation' or self.phase == 'bound_preparation':
                self.bound_step_seconds += spent
            self._publish(deadline, on_improvement)
        if self.terminal_reason is not None:
            stop = self.terminal_reason
        result = self.snapshot(capture_bound_certificate)
        result['advance_checkpoint_delta'] = self.checkpoints - first
        result['stop'] = stop
        if deadline is not None and self.clock() >= deadline:
            result['complete'] = False
            result['stop'] = 'deadline_before_return'
        return result

    def snapshot(self, capture_bound_certificate=False):
        exact = self.terminal_reason in ('complete_exact_neighborhood', 'nonnegative_objective_zero_upper')
        certificate = None
        if capture_bound_certificate:
            certificate = {'tables': copy.deepcopy(self.tables), 'entries': self.bound_entries,
                           'finite_entries': self.bound_finite,
                           **copy.deepcopy(self.bound_metadata or {})}
        return {
            'starts': copy.deepcopy(self.best), 'score_numerator': self.upper_value,
            'score_fraction': str(F(self.upper_value, self.ctx.denominator)),
            'initial_score_numerator': self.initial_value, 'machines': list(self.pair),
            'complete': exact, 'stop': self.terminal_reason or 'suspended',
            'algorithm_terminal': self.terminal_reason is not None,
            'states_generated': self.generated, 'states_expanded': self.expanded,
            'normalized_states_processed': self.normalized_count,
            'transitions_considered': self.transitions, 'improvements': copy.deepcopy(self.events),
            'offered_incumbents': copy.deepcopy(self.offers),
            'elapsed_seconds_including_pauses': self.clock() - self.begun,
            'kernel_step_seconds_excluding_pauses_snapshots_callbacks': self.kernel_step_seconds,
            'scope': 'selected_positive_machine_chains_all_zero_nodes_free_exterior_positive_starts_and_permutation_fixed',
            'variable_positive_machines': sorted(set(self.pair) - set(self.fixed)),
            'all_zero_nodes_free': True, 'bound_mode': self.mode,
            'bound_preparation_complete': self.bound_complete,
            'bound_entries': self.bound_entries, 'bound_finite_entries': self.bound_finite,
            'bound_build_active_step_seconds': self.bound_step_seconds,
            'bound_certificate': certificate, 'domain_fingerprint': self.fingerprint,
            'cumulative_state_limit': self.state_limit, 'checkpoint_count': self.checkpoints,
            'advance_calls': self.advance_calls, 'phase': self.phase, 'time_layer': self.time_layer,
            'in_memory_frontier_retained': self.terminal_reason is None,
            'incomplete_run_provides_no_global_lower_bound_or_optimality_claim': True,
            'cooperative_suspension_not_a_hard_deadline_guarantee': True,
        }

    def _work(self):
        ctx, order, initial, pair = self.ctx, self.order, self.initial, self.pair
        n, h = len(order), ctx.horizon
        selected = set(pair) - set(self.fixed)
        self.phase = 'preparation'
        yield
        grid = temporal_grid(ctx.durations, order, h)
        lower, upper = {}, {}
        for j, a in grid.nodes:
            base = 0 if a in selected or ctx.durations[j][a] == 0 else initial[j][a]
            lower[j, a] = max([base] + [lower[p, b] + ctx.durations[p][b] for p, b in grid.parents[j, a]])
            if a not in selected and ctx.durations[j][a]:
                assert lower[j, a] == initial[j][a]
        for j, a in reversed(grid.nodes):
            base = h - ctx.durations[j][a] if a in selected or ctx.durations[j][a] == 0 else initial[j][a]
            upper[j, a] = min([base] + [upper[p, b] - ctx.durations[j][a] for p, b in grid.children[j, a]])
            assert lower[j, a] <= initial[j][a] <= upper[j, a]
        background = gross_profile(ctx, initial)
        for a in pair:
            for j in order:
                for k, power in enumerate(ctx.powers[j][a]):
                    background[initial[j][a] + k] -= power
        assert all(q >= 0 for q in background)
        suffix = [0] * (h + 1)
        for t in range(h - 1, -1, -1):
            suffix[t] = suffix[t + 1] + ctx.carbon[t] * max(background[t] - ctx.renewable[t], 0)
        stages = []
        for a in pair:
            rows = [(i, r) for i, j in enumerate(order) for r in range(max(1, ctx.durations[j][a]))] + [(n, 0)]
            ids = {state: k for k, state in enumerate(rows)}
            remaining = [0] * (n + 1)
            for i in range(n - 1, -1, -1):
                remaining[i] = remaining[i + 1] + ctx.durations[order[i]][a]
            stages.append({'rows': rows, 'ids': ids, 'end': ids[n, 0], 'remaining': remaining})
        required, last = [], -1
        for i, j in enumerate(order):
            if ctx.durations[j][pair[0]]:
                last = i
            required.append(last)
        width = len(stages[1]['rows'])

        def unpack(key):
            return [key // width, key % width]

        def pack(x):
            return x[0] * width + x[1]

        def ready(slot, i, t, x):
            a, j = pair[slot], order[i]
            if t < lower[j, a] or t > upper[j, a]:
                return False
            if slot == 1 and required[i] >= 0:
                upstream_i, _ = stages[0]['rows'][x[0]]
                if upstream_i <= required[i]:
                    return False
            return True

        def normalize(key, t):
            x, closed = unpack(key), []
            for slot, a in enumerate(pair):
                while True:
                    i, r = stages[slot]['rows'][x[slot]]
                    if i == n:
                        break
                    j, duration = order[i], ctx.durations[order[i]][a]
                    if r == 0 and t > upper[j, a]:
                        return None
                    if duration or not ready(slot, i, t, x):
                        break
                    closed.append((j, a))
                    x[slot] = stages[slot]['ids'][i + 1, 0]
                i, r = stages[slot]['rows'][x[slot]]
                if t + stages[slot]['remaining'][i] - r > h:
                    return None
            return pack(x), closed

        def choices(slot, state, t, x):
            i, r = stages[slot]['rows'][state]
            a = pair[slot]
            if i == n:
                return [(0, state, 0)]
            j, op = order[i], ctx.powers[order[i]][a]
            d = len(op)
            if not d:
                return [(0, state, 0)]
            if r == 0:
                options = [(0, state, 0)]
                if not ready(slot, i, t, x):
                    return options
            else:
                options = []
            after = stages[slot]['ids'][i, r + 1] if r + 1 < d else stages[slot]['ids'][i + 1, 0]
            options.append((op[r], after, 1))
            return options

        parents, current = [{}], {0: 0}

        def reconstruct(t, key):
            s, assigned = [list(row) for row in initial], set()
            norm = normalize(key, t)
            assert norm is not None
            for op in norm[1]:
                s[op[0]][op[1]] = t
                assigned.add(op)
            while t:
                previous, mask = parents[t][key]
                norm = normalize(previous, t - 1)
                assert norm is not None
                x = unpack(norm[0])
                for op in norm[1]:
                    assert op not in assigned
                    s[op[0]][op[1]] = t - 1
                    assigned.add(op)
                for slot, a in enumerate(pair):
                    i, r = stages[slot]['rows'][x[slot]]
                    if mask >> slot & 1 and i < n and r == 0 and ctx.durations[order[i]][a]:
                        op = (order[i], a)
                        assert op not in assigned
                        s[op[0]][op[1]] = t - 1
                        assigned.add(op)
                key, t = previous, t - 1
            assert len(assigned) == 2 * n
            s = lift_zero_operations(ctx, order, s)
            assert s is not None
            assert physical_numerator(ctx, list(order), s) == load_functional(ctx, gross_profile(ctx, s))
            return s

        if self.upper_value == 0:
            self.bound_complete = True
            self.phase = 'terminal'
            return 'nonnegative_objective_zero_upper'
        if self.mode == 'residual':
            self.phase = 'bound_preparation'
            residual = [max(ctx.renewable[t] - background[t], 0) for t in range(h)]
            self.bound_metadata = {'residual_supply': residual,
                                   'windows': [[[lower[j, a], upper[j, a]] for j in order] for a in pair]}
            tables = []
            for slot, a in enumerate(pair):
                rows, ids, end = stages[slot]['rows'], stages[slot]['ids'], stages[slot]['end']
                values = [[None] * len(rows) for _ in range(h + 1)]
                for t in range(h, -1, -1):
                    yield
                    values[t][end] = 0
                    self.bound_entries += 1
                    self.bound_finite += 1
                    for k in range(end - 1, -1, -1):
                        yield
                        i, r = rows[k]
                        j, op = order[i], ctx.powers[order[i]][a]
                        d, options = len(op), []
                        if not d:
                            if lower[j, a] <= t <= upper[j, a]:
                                value = values[t][ids[i + 1, 0]]
                                if value is not None:
                                    options.append(value)
                            elif t < lower[j, a] and t < h:
                                value = values[t + 1][k]
                                if value is not None:
                                    options.append(value)
                        elif r == 0 and t <= upper[j, a]:
                            if t < h:
                                if values[t + 1][k] is not None:
                                    options.append(values[t + 1][k])
                                if t >= lower[j, a]:
                                    nxt = ids[i, r + 1] if r + 1 < d else ids[i + 1, 0]
                                    value = values[t + 1][nxt]
                                    if value is not None:
                                        options.append(ctx.carbon[t] * max(op[r] - residual[t], 0) + value)
                        elif r > 0 and t < h and lower[j, a] <= t - r <= upper[j, a]:
                            nxt = ids[i, r + 1] if r + 1 < d else ids[i + 1, 0]
                            value = values[t + 1][nxt]
                            if value is not None:
                                options.append(ctx.carbon[t] * max(op[r] - residual[t], 0) + value)
                        values[t][k] = min(options) if options else None
                        self.bound_entries += 1
                        self.bound_finite += values[t][k] is not None
                tables.append(values)
            self.tables = tables
            self.bound_complete = True

        def lower_bound(t, key):
            value = suffix[t]
            if self.tables is not None:
                x = unpack(key)
                for slot in range(2):
                    part = self.tables[slot][t][x[slot]]
                    if part is None:
                        return None
                    value += part
            return value

        for t in range(h + 1):
            self.time_layer, self.phase = t, 'normalization'
            normalized = {}
            for key, cost in sorted(current.items()):
                yield
                future = lower_bound(t, key)
                if future is None or cost + future >= self.upper_value:
                    continue
                norm = normalize(key, t)
                if norm is None:
                    continue
                self.normalized_count += 1
                x = unpack(norm[0])
                if all(x[k] == stages[k]['end'] for k in range(2)):
                    value = cost + suffix[t]
                    if value < self.upper_value:
                        self.phase = 'incumbent_reconstruction'
                        candidate = reconstruct(t, key)
                        assert physical_numerator(ctx, list(order), candidate) == value
                        self.best, self.upper_value = candidate, value
                        self.events.append({'score_numerator': value, 'starts': copy.deepcopy(candidate),
                            'available_seconds': self.clock() - self.begun,
                            'after_checkpoints': self.checkpoints})
                        self.phase = 'normalization'
                    continue
                existing = normalized.get(norm[0])
                if existing is None or cost < existing[0]:
                    normalized[norm[0]] = cost, key
            if t == h:
                break
            following, back = {}, {}
            self.phase = 'transitions'
            for key, (cost, rawkey) in sorted(normalized.items()):
                yield
                self.expanded += 1
                x = unpack(key)
                for left, right in itertools.product(choices(0, x[0], t, x), choices(1, x[1], t, x)):
                    yield
                    self.transitions += 1
                    q = background[t] + left[0] + right[0]
                    value = cost + ctx.carbon[t] * max(q - ctx.renewable[t], 0)
                    nxt = left[1] * width + right[1]
                    future = lower_bound(t + 1, nxt)
                    if future is None or value + future >= self.upper_value:
                        continue
                    if nxt not in following:
                        if self.generated >= self.state_limit:
                            self.phase = 'terminal'
                            return 'state_limit'
                        self.generated += 1
                    if nxt not in following or value < following[nxt]:
                        following[nxt] = value
                        back[nxt] = rawkey, left[2] + 2 * right[2]
            current = following
            parents.append(back)
            if not current:
                break
        self.phase = 'terminal'
        assert physical_numerator(ctx, list(order), self.best) == self.upper_value <= self.initial_value
        return 'complete_exact_neighborhood'
