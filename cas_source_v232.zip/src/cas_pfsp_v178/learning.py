"""UCBx controller transfer, not reproduction of the full multiobjective LgMOEA.

Source: Information Sciences731(2026),122884, author LeMOEAk.py KAB.UCB1x.
The original four objective-specific operators need replacement in single-
objective CAS. We retain the five-round initialization, UCB rule and gamma=.5;
operators, reward and physical decoder are explicitly different.
"""
import math, random, time
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v69.projection import initial_orders
from cas_pfsp_v76.search import PhaseSearch


class UCBController:
    def __init__(self, arms=4, gamma=.5):
        if type(arms) is not int or arms < 1 or not math.isfinite(gamma) or gamma < 0:
            raise ValueError('Positive integer arms and nonnegative finite gamma required')
        self.arms, self.gamma = arms, gamma
        self.counts = [0] * arms; self.sums = [0.] * arms; self.history = []

    def select(self):
        total = len(self.history)
        if total < self.arms * 5: return total % self.arms
        scores = [self.sums[k] / self.counts[k] + self.gamma * math.sqrt(math.log(total + 1) / self.counts[k])
                  for k in range(self.arms)]
        return max(range(self.arms), key=lambda k: (scores[k], -k))

    def update(self, arm, reward):
        if type(arm) is not int or not 0 <= arm < self.arms or not math.isfinite(reward) or not 0 <= reward <= 3:
            raise ValueError('Valid arm and finite reward in[0,3]required')
        self.counts[arm] += 1; self.sums[arm] += reward; self.history.append(dict(arm=arm, reward=reward))


class LearningPhaseSearch(PhaseSearch):
    def run(self, uniform=False):
        controller = UCBController(); policy = []
        for order in initial_orders(self.ctx):
            if not self.live(): break
            self.evaluate(order, 'initialization')
        while self.live():
            if self.current is None:
                order = list(range(len(self.ctx.durations))); self.rng.shuffle(order)
                self.evaluate(order, 'feasibility_search'); continue
            arm = len(controller.history) % 4 if uniform else controller.select()
            order = list(self.registry.attempts[self.current]['permutation'])
            before = self.registry.best_value
            if len(order) > 1:
                i, j = self.rng.sample(range(len(order)), 2)
                if arm == 0: order.insert(j, order.pop(i))
                elif arm == 1: order[i], order[j] = order[j], order[i]
                elif arm == 2:
                    low, high = sorted((i, j)); order[low:high + 1] = reversed(order[low:high + 1])
                else: self.rng.shuffle(order)
            accepted = self.evaluate(order, 'shake' if arm == 3 else 'insertion', dict(operator=arm))
            reward = 3 if self.registry.best_value is not None and (before is None or self.registry.best_value < before) else 1 if accepted and arm != 3 else 0
            controller.update(arm, reward)
            policy.append(dict(arm=arm, reward=reward, before=before, after=self.registry.best_value,
                ready_seconds=self.clock() - self.started))
        return dict(controller='uniform_cycle' if uniform else 'UCBx_2026_component_transfer',
            controller_gamma=.5, controller_initial_round_robin=20,
            counts=controller.counts, controller_history=policy, evaluations=self.evaluations,
            phase_calls=self.scanner.calls, registered_attempts=self.registry.attempts,
            best_registered=self.registry.best, budget_seconds=self.deadline - self.started,
            algorithm_wall_seconds=self.clock() - self.started,
            all_setup_registration_cache_and_policy_charged=True,
            full_original_LgMOEA_reproduction=False, same_model_CAS_adaptation=True)


def run_file(path, budget_seconds, seed=0, uniform=False):
    if 'neso_' in str(path).lower(): raise ValueError('Reserved input path')
    if not math.isfinite(budget_seconds) or budget_seconds <= 0 or type(seed) is not int:
        raise ValueError('Positive finite budget and integer seed required')
    before = random.getstate(); started = time.perf_counter(); cpu = time.process_time()
    instance = load_instance(path); ctx = make_context(instance)
    search = LearningPhaseSearch(ctx, started, started + budget_seconds, 't1p1', seed)
    result = search.run(uniform=uniform)
    result.update(input_sha256=instance.input_sha256, seed=seed,
        algorithm_cpu_seconds=time.process_time() - cpu,
        overshoot_seconds=max(0., time.perf_counter() - started - budget_seconds),
        source_publication_doi='10.1016/j.ins.2025.122884',
        reward_mapping='3 for global strict improvement;1 for accepted strict local improvement;0 otherwise',
        operator_mapping=['random insertion', 'random swap', 'random reversal', 'random permutation restart'],
        global_Python_RNG_unchanged=random.getstate() == before)
    assert result['global_Python_RNG_unchanged']
    return result
