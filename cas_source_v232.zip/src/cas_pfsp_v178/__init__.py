"""Explicit CAS transfer of a published 2026 UCB operator-selection mechanism."""
