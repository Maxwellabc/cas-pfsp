"""Measured metrics; normalize the platform-dependent ru_maxrss unit."""
import resource
import sys
import time


def finish_metrics(result, cpu_started, input_sha256):
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    result.update(algorithm_cpu_seconds=time.process_time()-cpu_started,
                  process_peak_rss_native_value=peak,
                  process_peak_rss_native_unit='bytes' if sys.platform == 'darwin' else 'KiB',
                  process_peak_rss_kib_before_export=peak/1024 if sys.platform == 'darwin' else peak,
                  input_sha256=input_sha256)
    return result
