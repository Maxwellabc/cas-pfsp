"""Factorial transfer/DP searches and deterministic calendar baselines."""
