"""Exact profile/complement cumulative encoding of the accepted CAS model.

Private mathematical reference only. Standard interval/cumulative primitives
are not claimed as an algorithmic contribution or a qualified public baseline.
"""
from fractions import Fraction as F
import itertools
import math
import time
from cas_pfsp_v45.model import validate_instance
from cas_pfsp_v113.integer_reference import exact, LIMIT
from cas_pfsp_v114.wide_reference import Built, certificate
from cas_pfsp_v116.model import digit_sum


def build(instance, checkpoint=lambda phase: None):
    checkpoint('model_begin'); validate_instance(instance)
    n, m, h, d = instance.n, instance.m, instance.horizon, instance.durations
    powers = [[[exact(v) for v in op] for op in job] for job in instance.powers]
    renewable, carbon = list(map(exact, instance.renewable)), list(map(exact, instance.carbon))
    dp = math.lcm(1, *(v.denominator for job in powers for op in job for v in op))
    p = [[[int(v*dp) for v in op] for op in job] for job in powers]
    cap = sum(max(op, default=0) for job in p for op in job)
    energy = sum(sum(op) for job in p for op in job)
    cumulative_mass = 2*energy + 2*h*cap
    if max(cumulative_mass, h) > LIMIT:
        raise ValueError('Conservative CP-SAT int64 arithmetic guard exceeded')
    from ortools.sat.python import cp_model
    model = cp_model.CpModel()
    ranks = [model.new_int_var(0, n-1, f'rank_{j}') for j in range(n)]
    model.add_all_different(ranks)
    starts = [[model.new_int_var(0, h, f'start_{j}_{a}') for a in range(m)] for j in range(n)]
    active, active_demands, complement, complement_demands = [], [], [], []
    for j, a in itertools.product(range(n), range(m)):
        checkpoint('operation_profile')
        model.add(starts[j][a] >= sum(d[j][:a]))
        model.add(starts[j][a] <= h-sum(d[j][a:]))
        if a+1 < m: model.add(starts[j][a+1] >= starts[j][a]+d[j][a])
        for offset, power in enumerate(p[j][a]):
            if not power: continue
            # Explicit [0,H-1] domain keeps both complement sizes nonnegative
            # even when the physical input itself is infeasible.
            unit = model.new_int_var(0, h-1, f'unit_{j}_{a}_{offset}')
            model.add(unit == starts[j][a]+offset)
            active.append(model.new_fixed_size_interval_var(unit, 1, f'active_{j}_{a}_{offset}'))
            active_demands.append(power)
            complement.append(model.new_interval_var(0, unit, unit, f'prefix_{j}_{a}_{offset}'))
            complement.append(model.new_interval_var(unit+1, h-unit-1, h, f'suffix_{j}_{a}_{offset}'))
            complement_demands += [power, power]
    for i, j in itertools.combinations(range(n), 2):
        checkpoint('permutation_pair')
        before = model.new_bool_var(f'before_{i}_{j}')
        model.add(ranks[i] < ranks[j]).only_enforce_if(before)
        model.add(ranks[i] > ranks[j]).only_enforce_if(~before)
        for a in range(m):
            model.add(starts[j][a] >= starts[i][a]+d[i][a]).only_enforce_if(before)
            model.add(starts[i][a] >= starts[j][a]+d[j][a]).only_enforce_if(~before)
    terms = []
    for t in range(h):
        checkpoint('calendar_slot')
        r = dp*renewable[t]
        if r >= cap: continue
        floor = r.numerator//r.denominator; fraction = r-floor
        excess = model.new_int_var(0, cap-floor, f'excess_{t}')
        positive = model.new_bool_var(f'positive_deficit_{t}')
        model.add(excess >= positive)
        model.add(excess <= (cap-floor)*positive)
        calendar = model.new_fixed_size_interval_var(t, 1, f'calendar_{t}')
        active.append(calendar); active_demands.append(cap-floor-excess)
        complement.append(calendar)
        # Cumulative demands are single-variable affine expressions. Bind the
        # sum explicitly to a nonnegative variable rather than passing 2 vars.
        reverse = model.new_int_var(0, 2*cap, f'reverse_calendar_demand_{t}')
        model.add(reverse == floor+excess+cap*positive)
        complement_demands.append(reverse)
        if fraction == 0:
            terms.append((carbon[t], excess, cap-floor))
        else:
            whole = model.new_int_var(0, max(0, cap-floor-1), f'whole_deficit_{t}')
            model.add(whole == excess-positive)
            terms.extend([(carbon[t], whole, max(0, cap-floor-1)), (carbon[t]*(1-fraction), positive, 1)])
    model.add_cumulative(active, active_demands, cap)
    model.add_cumulative(complement, complement_demands, energy+cap)
    scale = math.lcm(1, *(c.denominator for c, _, _ in terms))
    digits, base, upper, row_bound = digit_sum(model, [(int(c*scale), v, u) for c, v, u in terms], checkpoint)
    checkpoint('model_validation')
    error = model.validate()
    if error: raise ValueError('CP-SAT model validation: '+error)
    checkpoint('model_complete')
    return Built(model, instance, ranks, starts, digits, base, dp, 4*dp*scale, upper,
        {'gross_upper_bound': cap, 'total_scaled_profile_power': energy,
         'conservative_cumulative_mass': cumulative_mass,
         'profile_intervals': len(active), 'complement_intervals': len(complement),
         'largest_digit_constraint_bound': row_bound, 'objective_bits': upper.bit_length(),
         'objective_digits': len(digits), 'objective_base': base,
         'time_indexed_start_choice_booleans': 0})


def solve(instance, solver_seconds=30., presolve=True):
    """Private complete-policy mathematics; solver portion only, not core timing."""
    if not math.isfinite(solver_seconds) or solver_seconds <= 0:
        raise ValueError('Positive finite solver-time limit required')
    begin = time.perf_counter(); built = build(instance)
    from ortools.sat.python import cp_model
    ready = time.perf_counter(); best = None; stages = []; complete = True
    status_name = 'UNKNOWN'
    for level in reversed(range(len(built.digits))):
        remaining = solver_seconds-(time.perf_counter()-ready)
        if remaining <= 0: complete = False; break
        built.model.minimize(built.digits[level]); solver = cp_model.CpSolver()
        solver.parameters.num_search_workers = 1; solver.parameters.random_seed = 0
        solver.parameters.cp_model_presolve = bool(presolve)
        solver.parameters.max_time_in_seconds = remaining
        solver.parameters.absolute_gap_limit = 0; solver.parameters.relative_gap_limit = 0
        status = solver.solve(built.model); status_name = solver.status_name(status)
        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE, cp_model.INFEASIBLE, cp_model.UNKNOWN):
            raise RuntimeError('Unexpected CP-SAT status: '+status_name)
        stages.append({'digit': level, 'status': status_name, 'value': None})
        if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            current = certificate(built, solver)
            if best is None or current['scaled_integer_objective'] < best['scaled_integer_objective']: best = current
            stages[-1]['value'] = solver.value(built.digits[level])
        if status == cp_model.OPTIMAL:
            built.model.add(built.digits[level] == stages[-1]['value'])
        elif status == cp_model.INFEASIBLE:
            assert best is None
            complete = False; break
        else: complete = False; break
    if best is not None: status_name = 'OPTIMAL' if complete else 'FEASIBLE'
    elif status_name != 'INFEASIBLE': status_name = 'UNKNOWN'
    return {'status': status_name, 'certificate': best, 'presolve': bool(presolve),
        'all_digits_proved_optimal': complete and best is not None, 'stages': stages,
        'power_scale': built.power_scale, 'objective_denominator': built.objective_denominator,
        'objective_base': built.base, 'objective_digits': len(built.digits), 'arithmetic': built.arithmetic,
        'build_seconds_including_imports': ready-begin, 'solver_and_export_seconds': time.perf_counter()-ready,
        'float_bound_used_as_exact_certificate': False, 'end_to_end_wall_budget_qualified': False}
