"""Private qualification of a cumulative standard-reference formulation."""
