"""15-minute coefficient convention,kept separate from frozen unscaled checker.

Evidence: unchanged author loader helper_functions.py listcomp at line54
multiplies grid-carbon input by0.25. It leaves raw job draws and renewable
supply unscaled. Thus its feasible objective is0.25 times the unscaled check.
This does not establish a physical kg/tonne conversion for every public input.
"""
from fractions import Fraction
from .model import check_schedule

PERIOD_HOURS = Fraction(1, 4)


def check_benchmark_schedule(instance, permutation, starts):
    checked = check_schedule(instance, permutation, starts)
    score = PERIOD_HOURS * Fraction(checked['raw_score_fraction'])
    return {**checked, 'period_hours_fraction': str(PERIOD_HOURS),
            'benchmark_score_fraction': str(score), 'benchmark_score_float': float(score),
            'native_loader_scaling_source': 'helper_functions.py:54(compiledco_firstlineno54)',
            'physical_kg_or_tonnes_conversion_established': False}
