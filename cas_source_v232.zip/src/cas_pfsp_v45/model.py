"""Model/data validator independent of author bytecode and random-key decoding.

Time uses zero-based integer intervals [s,s+d). All coefficient arithmetic is
exact rational arithmetic from the public decimal input strings. The returned
score is in the benchmark's unconverted coefficient-product units.
"""
from dataclasses import dataclass
from fractions import Fraction
import csv
import hashlib
from pathlib import Path


@dataclass(frozen=True)
class Instance:
    name: str
    # powers[job][machine][relative processing interval]; empty means d=0.
    powers: tuple
    renewable: tuple
    carbon: tuple
    prices: tuple = ()
    input_sha256: str = ''

    @property
    def n(self):
        return len(self.powers)

    @property
    def m(self):
        return len(self.powers[0])

    @property
    def horizon(self):
        return len(self.carbon)

    @property
    def durations(self):
        return tuple(tuple(len(p) for p in job) for job in self.powers)


def validate_instance(instance):
    if not instance.powers or not instance.powers[0] or not instance.carbon:
        raise ValueError('Empty jobs,machines or horizon')
    if any(len(job) != instance.m for job in instance.powers):
        raise ValueError('Inconsistent machine dimensions')
    if len(instance.renewable) != instance.horizon:
        raise ValueError('Renewable/carbon horizon mismatch')
    if instance.prices and len(instance.prices) != instance.horizon:
        raise ValueError('Price horizon mismatch')
    if any(value < 0 for job in instance.powers for op in job for value in op):
        raise ValueError('Negative processing power')
    if any(value < 0 for value in instance.carbon + instance.renewable):
        raise ValueError('Negative carbon or renewable supply outside this contract')


def load_instance(path):
    """Accept public main and legacy tuning formats;do not infer missing prices."""
    path = Path(path)
    raw = path.read_bytes()
    lines = [row for row in csv.reader(raw.decode('utf-8-sig').splitlines()) if row and any(x.strip() for x in row)]
    if not lines or len(lines[0]) != 12:
        raise ValueError('Expected12field header')
    header = [Fraction(x) for x in lines[0]]
    if any(v.denominator != 1 for v in header[:3]):
        raise ValueError('Non-integer machine/day/job header')
    m, days, n = map(int, header[:3])
    if min(m, days, n) <= 0:
        raise ValueError('Non-positive header dimensions')
    if len(lines) not in (n*m+3, n*m+4):
        raise ValueError('Expected operation rows plus renewable,carbon and optionalprices')
    powers = [[None]*m for _ in range(n)]
    for k, row in enumerate(lines[1:n*m+1]):
        job, machine = divmod(k, m)
        if m > 1:
            if len(row) < 2 or (int(row[0]), int(row[1])) != (job, machine):
                raise ValueError('Incorrect zero-based operation indices')
            fields = row[2:]
            if fields == ['']:
                fields = []
        else:
            fields = row
        powers[job][machine] = tuple(Fraction(x) for x in fields)
    renewable, carbon = [tuple(Fraction(x) for x in row) for row in lines[n*m+1:n*m+3]]
    prices = tuple(Fraction(x) for x in lines[-1]) if len(lines) == n*m+4 else ()
    result = Instance(path.stem, tuple(tuple(job) for job in powers), renewable, carbon, prices,
                      hashlib.sha256(raw).hexdigest())
    validate_instance(result)
    if result.horizon != 96*days:
        raise ValueError('Public format requires96quarter-hour periods per day')
    if sum(len(op) for job in powers for op in job) != header[3]:
        raise ValueError('Header duration sum mismatch')
    if sum(sum(op) for job in powers for op in job) != header[4]:
        raise ValueError('Header raw-power sum mismatch')
    return result


def check_schedule(instance, permutation, starts):
    """Reject invalid schedules before accounting;no late penalty/partial billing."""
    validate_instance(instance)
    n, m, horizon = instance.n, instance.m, instance.horizon
    if len(permutation) != n or any(type(i) is not int for i in permutation) or sorted(permutation) != list(range(n)):
        raise ValueError('Not a permutation of all job indices')
    if len(starts) != n or any(len(row) != m for row in starts):
        raise ValueError('Start matrix has wrong dimensions')
    if any(type(s) is not int for row in starts for s in row):
        raise ValueError('Start times must be integer interval indices')
    durations = instance.durations
    ends = [[starts[j][a]+durations[j][a] for a in range(m)] for j in range(n)]
    for j in range(n):
        for a in range(m):
            if starts[j][a] < 0 or ends[j][a] > horizon:
                raise ValueError('Operation outside planning horizon')
            if a and starts[j][a] < ends[j][a-1]:
                raise ValueError('Within-job precedence violation')
    for a in range(m):
        for previous, following in zip(permutation, permutation[1:]):
            if starts[following][a] < ends[previous][a]:
                raise ValueError('Common permutation or machine non-overlap violation')
    # Shared renewable supply is subtracted once AFTER all machines are summed.
    gross = [Fraction(0) for _ in range(horizon)]
    for j, job in enumerate(instance.powers):
        for a, op in enumerate(job):
            for k, value in enumerate(op):
                gross[starts[j][a]+k] += value
    grid = [max(Fraction(0), demand-supply) for demand, supply in zip(gross, instance.renewable)]
    used = [demand-net for demand, net in zip(gross, grid)]
    score = sum(net*c for net, c in zip(grid, instance.carbon))
    return {'feasible': True, 'raw_score_fraction': str(score), 'raw_score_float': float(score),
            'score_units': 'unconverted_benchmark_coefficient_product',
            'gross_power_fraction': [str(v) for v in gross], 'grid_power_fraction': [str(v) for v in grid],
            'renewable_used_fraction': [str(v) for v in used], 'completion_times': ends,
            'makespan_intervals': max(max(row) for row in ends),
            'physical_kg_or_tonnes_conversion_established': False}
