"""Conservative exact dispatch derived only from constructed kernel profiles.

This candidate does not alter the running/frozen v192 study. It is not a new
metaheuristic; all phase consumption and complete search decisions are inherited.
"""
from pathlib import Path
import math
import time
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v70.runtime import finish_metrics
from cas_pfsp_v76.phase import phase_value
from cas_pfsp_v192.phase import ExactPhaseKernel, ExactBatchScanner
from cas_pfsp_v192.search import AcceleratedWaitSearch


class HybridKernel:
    def __init__(self, ctx):
        self.ctx, self.kernel = ctx, None

    def values(self, shape, phases):
        if self.kernel is None:
            self.kernel = ExactPhaseKernel(self.ctx)
        phases = tuple(phases)
        # Frozen before public quality inspection: conservative work thresholds
        # from the separate constructed profiles, no instance/family overrides.
        threshold = 128 if self.kernel.direct else max(1, len(self.kernel.digits)) * 256
        if len(shape.profile) * len(phases) <= threshold:
            return [phase_value(self.ctx, shape, t) for t in phases], 'small_work_exact_scalar'
        return self.kernel.values(shape, phases)


class HybridWaitSearch(AcceleratedWaitSearch):
    def __init__(self, ctx, started, deadline, seed, **options):
        super().__init__(ctx, started, deadline, seed, **options)
        self.scanner._exact_kernel = HybridKernel(ctx)

    def run(self):
        out = super().run()
        out.update(exact_acceleration_version='v193',
                   dispatch_rule='work<=128_direct_or_256_times_limbs_else_batch',
                   thresholds_chosen_from_constructed_profiles_before_public_quality=True)
        return out


def run_file(input_path, budget_seconds, seed=0, **options):
    p = Path(input_path).resolve()
    if 'neso_' in str(p).lower(): raise ValueError('Reserved path before read')
    if type(budget_seconds) not in (int, float) or not math.isfinite(budget_seconds) or budget_seconds <= 0:
        raise ValueError('Finite positive wall budget required')
    started, cpu = time.perf_counter(), time.process_time()
    physical = load_instance(p); ctx = make_context(physical)
    result = HybridWaitSearch(ctx, started, started + budget_seconds, seed, **options).run()
    return finish_metrics(result, cpu, physical.input_sha256)
