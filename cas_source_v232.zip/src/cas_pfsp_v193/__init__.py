"""Constructed-diagnostic scalar/batch dispatch; public performance unqualified."""
