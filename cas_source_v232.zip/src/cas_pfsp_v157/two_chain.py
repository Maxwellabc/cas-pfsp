"""Joint suffix feasibility bound for legal prefixes on at most two fixed rows.

Uses ordinary longest-path deadline reasoning. Scientific priority,paid complete
search,speed and public solution quality are not established. The predicate is
conditional on a legally reachable prefix and a feasible exterior anchor.
"""
from cas_pfsp_v138.two_chain import ViableChainTiming


class JointViableChainTiming(ViableChainTiming):
    def __init__(self,instance,order,anchor,machine_rows,checkpoint=lambda phase:None):
        checkpoint('joint_viability_prepare_begin')
        super().__init__(instance,order,anchor,machine_rows,checkpoint=checkpoint)
        self.cross_suffix_offsets=None
        if len(self.chains)==2:
            assert all(self.requirements[op][1]==0 for op in self.chains[0]),'No backward cross-chain edges allowed'
            candidates={}
            for op in self.chains[1]:
                checkpoint('joint_cross_operation')
                begin=self.work[op][1]
                candidates[begin]=self.latest_boundary[1][begin]-self.requirements[op][0]
            self.cross_suffix_offsets=[None]*(self.goal[1]+1);bound=None
            for k in reversed(range(self.goal[1]+1)):
                checkpoint('joint_cross_suffix_work')
                if k in candidates:bound=candidates[k] if bound is None else min(bound,candidates[k])
                self.cross_suffix_offsets[k]=bound
        checkpoint('joint_viability_prepare_complete')

    def viable(self,time,work):
        if not super().viable(time,work):return False
        if self.cross_suffix_offsets is None:return True
        bound=self.cross_suffix_offsets[work[1]]
        return bound is None or time<=work[0]+bound

    def summary(self):
        out=super().summary()
        out.update(viability_cut_kind='independent_deadlines_plus_forward_cross_chain_remaining_path_deadlines',
            joint_cross_suffix_offsets=None if self.cross_suffix_offsets is None else self.cross_suffix_offsets[:],
            suffix_feasibility_exactness_claim_scope='legal reachable positive-work prefixes,feasible fixed-exterior anchor,at most two ordered flowshop rows',
            arbitrary_time_work_vectors_recognized_as_reachable=False,
            extra_joint_preprocessing_order='O(D_second+number_of_second_chain_positive_operations)',
            extra_joint_state_check_order='O(1)',
            paid_complete_joint_viability_policy_qualified=False,
            joint_viability_public_gain_or_priority_qualified=False)
        return out
