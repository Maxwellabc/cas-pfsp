"""Complete open iterated insertion search with feasible timing feedback.

Generic ILS, NEH, timing DP, and insertion neighborhoods are prior art.
The no_feedback arm retains every paid physical improvement globally while
removing it from future sequencing scores and sequencing-state targets.
"""
from collections import OrderedDict
import copy
from fractions import Fraction as F
import hashlib
import json
import random
import resource
import time
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v64.registry import PhysicalRegistry, physical_numerator
from .projection import initial_orders, witnesses
from .timing import TimingWork


def rng_sha(rng):
    return hashlib.sha256(repr(rng.getstate()).encode()).hexdigest()


def insertion_orders(order, rng):
    moves = [(i, j) for i in range(len(order)) for j in range(len(order)) if i != j]
    rng.shuffle(moves)
    seen = set()
    for i, j in moves:
        proposed = list(order)
        job = proposed.pop(i)
        proposed.insert(j, job)
        if tuple(proposed) not in seen:
            seen.add(tuple(proposed))
            yield proposed, [i, j]


class OpenSearch:
    def __init__(self, ctx, started, deadline, arm, seed, clock=time.perf_counter,
                 cache_capacity=64, slice_seconds=.05, chain_calls=2, pair_interval=8,
                 max_evaluations=None, state_limit=2_000_000):
        if arm not in ('feedback', 'no_feedback'):
            raise ValueError('Unknown open search arm')
        if deadline <= started or cache_capacity < 1 or slice_seconds <= 0 or chain_calls < 0 or pair_interval < 1:
            raise ValueError('Invalid open search limits')
        if max_evaluations is not None and (type(max_evaluations) is not int or max_evaluations < 1):
            raise ValueError('Positive diagnostic evaluation quota required')
        self.ctx, self.started, self.deadline, self.arm, self.clock = ctx, started, deadline, arm, clock
        self.rng, self.seed = random.Random(seed), seed
        self.registry = PhysicalRegistry(ctx, started, deadline, clock=clock)
        self.timing = TimingWork(ctx, started, deadline, clock=clock, state_limit=state_limit)
        self.cache, self.cache_capacity, self.cache_actions = OrderedDict(), cache_capacity, []
        self.slice_seconds, self.chain_calls, self.pair_interval = slice_seconds, chain_calls, pair_interval
        self.max_evaluations = max_evaluations
        self.evaluations, self.current, self.best_search, self.decisions = [], None, None, []

    def live(self):
        return self.clock() < self.deadline and (self.max_evaluations is None or len(self.evaluations) < self.max_evaluations)

    def register(self, order, starts, value, origin):
        return self.registry.register(order, starts, str(F(value, self.ctx.denominator)), origin)

    def evaluate(self, order, reason, move=None):
        ix = len(self.evaluations)
        row = {'id': ix, 'order': list(order), 'reason': reason, 'move': move,
               'current_before': copy.deepcopy(self.current), 'started_seconds': self.clock() - self.started,
               'rng_before_sha256': rng_sha(self.rng), 'witnesses': [], 'cache_source_evaluation': None,
               'timing_call': None, 'accepted': False, 'decision_ready_seconds': None}
        self.evaluations.append(row)
        target = self.current['starts'] if self.current is not None else None
        try:
            proposed = witnesses(self.ctx, order, target)
        except ValueError as error:
            if str(error) != 'Fixed order has no feasible timing':
                raise
            row.update(status='infeasible_order', returned_seconds=self.clock() - self.started)
            return False
        base = None
        for source, starts in proposed:
            value = physical_numerator(self.ctx, order, starts)
            receipt = self.register(order, starts, value, {'kind': 'witness', 'evaluation': ix, 'source': source})
            row['witnesses'].append({'source': source, 'starts': copy.deepcopy(starts),
                                     'score_numerator': value, 'registration': receipt})
            if receipt['eligible'] and (base is None or value < base['score_numerator']):
                base = {'order': list(order), 'starts': copy.deepcopy(starts), 'score_numerator': value, 'evaluation': ix}
        if base is None:
            row.update(status='no_eligible_witness', returned_seconds=self.clock() - self.started)
            return False
        row['raw_state'] = copy.deepcopy(base)
        refined = copy.deepcopy(base)
        key = tuple(order)
        if self.arm == 'feedback' and key in self.cache:
            old = self.cache[key]
            self.cache.move_to_end(key)
            row['cache_source_evaluation'] = old['evaluation']
            # Paid read/validation/registration, no back-dated availability.
            receipt = self.register(order, old['starts'], old['score_numerator'], {'kind': 'timing_cache', 'evaluation': ix,
                                    'source_evaluation': old['evaluation']})
            row['cache_registration'] = receipt
            if receipt['eligible'] and old['score_numerator'] < refined['score_numerator']:
                refined = copy.deepcopy(old)
                refined['evaluation'] = ix
        if self.clock() < self.deadline:
            call = self.timing.refine(order, refined['starts'], ix,
                lambda s, v, origin: self.register(order, s, v, origin), self.slice_seconds,
                self.chain_calls, self.pair_interval)
            row['timing_call'] = call['id']
            refined = {'order': list(order), 'starts': copy.deepcopy(call['starts']),
                       'score_numerator': call['score_numerator'], 'evaluation': ix}
        row['refined_state'] = copy.deepcopy(refined)
        # The ablation does not use refined timing as a hidden initializer.
        selected = refined if self.arm == 'feedback' else base
        ready = self.clock()
        row['selected_state'] = copy.deepcopy(selected)
        row['decision_ready_seconds'] = ready - self.started
        eligible = ready < self.deadline
        strict = self.current is None or selected['score_numerator'] < self.current['score_numerator']
        accept = bool(eligible and (strict or reason == 'shake'))
        if accept:
            self.current = copy.deepcopy(selected)
        if eligible and (self.best_search is None or selected['score_numerator'] < self.best_search['score_numerator']):
            self.best_search = copy.deepcopy(selected)
        if self.arm == 'feedback' and eligible:
            if key in self.cache:
                old = self.cache[key]
                if refined['score_numerator'] < old['score_numerator']:
                    self.cache[key] = copy.deepcopy(refined)
                self.cache.move_to_end(key)
            else:
                if len(self.cache) >= self.cache_capacity:
                    victim, _ = self.cache.popitem(last=False)
                    self.cache_actions.append({'evaluation': ix, 'evicted_order': list(victim)})
                self.cache[key] = copy.deepcopy(refined)
        row.update(status='evaluated', accepted=accept, strict_search_improvement=bool(accept and strict),
                   current_after=copy.deepcopy(self.current), cache_entries=len(self.cache),
                   returned_seconds=self.clock() - self.started)
        self.decisions.append({'evaluation': ix, 'accepted': accept, 'reason': reason,
                               'ready_seconds': row['decision_ready_seconds']})
        return accept

    def run(self):
        global_rng = random.getstate()
        for order in initial_orders(self.ctx):
            if not self.live():
                break
            self.evaluate(order, 'initialization')
        while self.live():
            if self.current is None:
                order = list(range(len(self.ctx.powers)))
                self.rng.shuffle(order)
                self.evaluate(order, 'feasibility_search')
                continue
            improved = False
            current_order = list(self.current['order'])
            for order, move in insertion_orders(current_order, self.rng):
                if not self.live():
                    break
                if self.evaluate(order, 'insertion', move):
                    improved = True
                    break
            if not self.live():
                break
            if improved:
                continue
            order = list(self.best_search['order'])
            for _ in range(min(3, len(order))):
                if len(order) > 1:
                    i, j = self.rng.sample(range(len(order)), 2)
                    job = order.pop(i)
                    order.insert(j, job)
            self.evaluate(order, 'shake')
        closing = self.clock()
        timing = self.timing.close()
        assert random.getstate() == global_rng
        return {'arm': self.arm, 'seed': self.seed, 'rng_after_sha256': rng_sha(self.rng),
                'evaluations': self.evaluations, 'decisions': self.decisions,
                'registered_attempts': self.registry.attempts, 'best_registered': self.registry.best,
                'current_search_state': self.current, 'best_search_state': self.best_search,
                'cache_capacity': self.cache_capacity, 'cache_actions': self.cache_actions,
                'cache_entries_at_close': len(self.cache), 'timing': timing,
                'timing_slice_seconds': self.slice_seconds, 'chain_calls_per_evaluation': self.chain_calls,
                'pair_interval_evaluations': self.pair_interval,
                'policy_close_seconds': self.clock() - closing,
                'algorithm_wall_seconds': self.clock() - self.started,
                'budget_seconds': self.deadline - self.started, 'max_evaluations': self.max_evaluations,
                'global_Python_rng_unchanged': True, 'donated_initializer_or_external_cache': False,
                'global_or_full_timing_optimum_claim': False,
                'inner_slice_is_kernel_cutoff_registration_and_cleanup_costs_still_charged': True,
                'physical_denominator_for_audit': self.ctx.denominator}


def run_search(input_path, arm, seed, budget_seconds, **options):
    if 'neso_' in str(input_path).lower():
        raise ValueError('Reserved path before read')
    if budget_seconds <= 0:
        raise ValueError('Positive wall budget required')
    started, cpu = time.perf_counter(), time.process_time()
    physical = load_instance(input_path)
    ctx = make_context(physical)
    search = OpenSearch(ctx, started, started + budget_seconds, arm, seed, **options)
    result = search.run()
    result.update(algorithm_cpu_seconds=time.process_time() - cpu,
                  process_peak_rss_kib_before_export=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  input_sha256=physical.input_sha256)
    return result
