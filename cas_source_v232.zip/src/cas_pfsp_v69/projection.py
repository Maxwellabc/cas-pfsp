"""Feasible transplantation on the common-order precedence DAG.

This is a feasibility construction, not an objective projection optimum.
Zero-duration nodes obey the same precedence and horizon inequalities.
"""
from cas_pfsp_v53.minimum_closure import temporal_grid


def matrix(grid, values):
    result = [[0] * len(grid.durations[0]) for _ in grid.durations]
    for (j, a), value in values.items():
        result[j][a] = value
    return result


def transplant(grid, target):
    n, m = len(grid.durations), len(grid.durations[0])
    if len(target) != n or any(len(row) != m for row in target):
        raise ValueError('Rectangular target required')
    if any(type(s) is not int for row in target for s in row):
        raise ValueError('Integer target required')
    starts = {}
    for op in grid.nodes:
        lower = max([0] + [starts[p] + grid.durations[p[0]][p[1]] for p in grid.parents[op]])
        starts[op] = max(lower, min(target[op[0]][op[1]], grid.upper[op]))
        assert grid.lower[op] <= starts[op] <= grid.upper[op]
    return matrix(grid, starts)


def witnesses(ctx, order, target=None):
    grid = temporal_grid(ctx.durations, order, ctx.horizon)
    result = [('earliest', matrix(grid, grid.lower))]
    if target is not None:
        projected = transplant(grid, target)
        if projected != result[0][1]:
            result.append(('transplant', projected))
    return result


def makespan(durations, order):
    """Partial-order PFSP completion, for an internally paid NEH initializer."""
    ends = [0] * len(durations[0])
    for j in order:
        previous = 0
        for a, duration in enumerate(durations[j]):
            ends[a] = max(previous, ends[a]) + duration
            previous = ends[a]
    return max(ends)


def initial_orders(ctx):
    n = len(ctx.durations)
    ranked = sorted(range(n), key=lambda j: (-sum(ctx.durations[j]), j))
    neh = []
    for j in ranked:
        choices = [neh[:p] + [j] + neh[p:] for p in range(len(neh) + 1)]
        neh = min(choices, key=lambda order: (makespan(ctx.durations, order), tuple(order)))
    seen = set()
    for order in (list(range(n)), list(reversed(range(n))), neh, ranked, list(reversed(ranked))):
        key = tuple(order)
        if key not in seen:
            seen.add(key)
            yield order
