"""Small paid timing interventions; no full timing optimum is asserted."""
from collections import OrderedDict
import copy
import itertools
import time
from cas_pfsp_v64.registry import physical_numerator
from cas_pfsp_v66.resumable_descent import FrontierPool
from cas_pfsp_v67.union_descent import ChainCertificateCache


class TimingWork:
    def __init__(self, ctx, started, deadline, clock=time.perf_counter, cursor_capacity=32,
                 chain_capacity=128, state_limit=2_000_000):
        self.ctx, self.started, self.deadline, self.clock = ctx, started, deadline, clock
        self.cursor_capacity, self.cursors = cursor_capacity, OrderedDict()
        self.chains = ChainCertificateCache(ctx, started, chain_capacity, clock=clock)
        self.pool = FrontierPool(ctx, started, state_limit=state_limit, clock=clock)
        self.calls, self.cursor_actions = [], []

    def refine(self, order, initial, evaluation, register, slice_seconds=.05, chain_calls=2, pair_interval=8):
        key = tuple(order)
        if key not in self.cursors:
            if len(self.cursors) >= self.cursor_capacity:
                victim, _ = self.cursors.popitem(last=False)
                self.cursor_actions.append({'evaluation': evaluation, 'evicted_order': list(victim)})
            self.cursors[key] = [0, 0]
        self.cursors.move_to_end(key)
        cursor = self.cursors[key]
        m, n = len(self.ctx.powers[0]), len(self.ctx.powers)
        sequence = [('machine', a) for a in range(m)]
        # Interleave machine and job chains to avoid long machine-only prefixes.
        if m > 1:
            sequence = [x for k in range(max(m, n)) for x in
                        ([('machine', k)] if k < m else []) + ([('job', order[k])] if k < n else [])]
        pair_due = bool(m > 1 and evaluation % pair_interval == pair_interval - 1)
        cutoff = min(self.deadline, self.clock() + slice_seconds)
        current, score = copy.deepcopy(initial), physical_numerator(self.ctx, order, initial)
        row = {'id': len(self.calls), 'evaluation': evaluation, 'order': list(order),
               'initial': copy.deepcopy(initial), 'started_seconds': self.clock() - self.started,
               'kernel_deadline_seconds': cutoff - self.started, 'cursor_before': list(cursor),
               'pair_due': pair_due, 'steps': [], 'events': []}
        self.calls.append(row)

        def retain(starts, value, stage, lookup, kind):
            nonlocal current, score
            if value >= score or self.clock() >= self.deadline:
                return
            assert physical_numerator(self.ctx, order, starts) == value
            event = {'stage': stage, 'lookup': lookup, 'kind': kind,
                     'starts': copy.deepcopy(starts), 'score_numerator': value,
                     'offered_seconds': self.clock() - self.started}
            receipt = register(starts, value, {'kind': 'timing', 'evaluation': evaluation,
                               'timing_call': row['id'], 'event': len(row['events'])})
            event['registration'] = receipt
            row['events'].append(event)
            if receipt['eligible']:
                current, score = copy.deepcopy(starts), value

        for _ in range(chain_calls):
            if self.clock() >= cutoff:
                break
            kind, index = sequence[cursor[0] % len(sequence)]
            cursor[0] += 1
            response = self.chains.response(order, current, kind, index, cutoff)
            row['steps'].append({'kind': 'chain', 'descriptor': [kind, index], 'response': response})
            retain(response['starts'], response['score_numerator'], response['source'], response['id'], 'chain')
        if pair_due and self.clock() < cutoff:
            pairs = list(itertools.combinations(range(m), 2))
            pair = pairs[cursor[1] % len(pairs)]
            cursor[1] += 1
            response = self.pool.response(order, current, pair, (), cutoff,
                lambda s, v, stage, lookup: retain(s, v, stage, lookup, 'projected_pair'))
            row['steps'].append({'kind': 'projected_pair', 'descriptor': list(pair), 'response': response})
        row.update(starts=copy.deepcopy(current), score_numerator=score, cursor_after=list(cursor),
                   returned_seconds=self.clock() - self.started, local_optimum_claim=False)
        return row

    def close(self):
        self.pool.close()
        return {'chain_cache': self.chains.receipt(), 'projected_pool': self.pool.receipt(),
                'cursor_capacity': self.cursor_capacity, 'cursor_actions': self.cursor_actions,
                'calls': self.calls, 'all_work_current_run_only': True}
