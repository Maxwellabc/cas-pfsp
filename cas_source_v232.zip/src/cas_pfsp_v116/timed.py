"""Common-core budget and eligible-incumbent interface for the exact reference.

Backend imports precede the measured core, matching the frozen native/phase
entry points. Input loading, context, model building, callbacks, physical
registration and policy work are charged. This is not a hard return deadline.
"""
from fractions import Fraction as F
from pathlib import Path
import math
import time
from ortools.sat.python import cp_model
from cas_pfsp_v45.model import load_instance
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v64.registry import PhysicalRegistry
from .model import build


class Expired(Exception):
    pass


class Budget:
    def __init__(self, seconds, clock):
        self.raw_clock=clock;self.last=None
        self.started=self.now();self.deadline=self.started+seconds
        self.polls={};self.last_phase=None

    def now(self):
        value=float(self.raw_clock())
        if not math.isfinite(value) or self.last is not None and value<self.last:
            raise ValueError('Finite monotone clock required')
        self.last=value
        return value

    def poll(self, phase):
        self.last_phase=phase;self.polls[phase]=self.polls.get(phase,0)+1
        if self.now()>=self.deadline:raise Expired(phase)


def raw_candidate(built, reader):
    positions=[int(reader.value(v)) for v in built.ranks]
    assert sorted(positions)==list(range(len(positions)))
    order=sorted(range(len(positions)),key=positions.__getitem__)
    starts=[[int(reader.value(v)) for v in row] for row in built.starts]
    integer=sum(int(reader.value(v))*built.base**level for level,v in enumerate(built.digits))
    return order,starts,integer,str(F(integer,built.objective_denominator))


class Collector(cp_model.CpSolverSolutionCallback):
    def __init__(self,built,budget,registry,cache,stage):
        super().__init__();self.built=built;self.budget=budget;self.registry=registry
        self.cache=cache;self.stage=stage;self.events=[];self.skipped_after_deadline=0

    def record(self,reader,kind):
        order,starts,integer,score=raw_candidate(self.built,reader)
        key=(tuple(order),tuple(x for row in starts for x in row),score)
        cached=key in self.cache
        if not cached:
            row=self.registry.register(order,starts,score,{'kind':kind,'digit':self.stage,
                'scaled_integer_objective':str(integer),'objective_denominator':str(self.built.objective_denominator)})
            index=len(self.registry.attempts)-1;self.cache[key]=index
        else:
            index=self.cache[key];row=self.registry.attempts[index]
        event={'kind':kind,'attempt_id':index,'paid_within_run_cache_hit':cached,
            'reference_ready_seconds':self.budget.now()-self.budget.started,
            'referenced_registration_eligible':row['eligible']}
        self.events.append(event)
        return integer,index

    def on_solution_callback(self):
        if self.budget.now()>=self.budget.deadline:
            self.skipped_after_deadline+=1;self.stop_search();return
        self.record(self,'CP_solution_callback')
        if self.budget.now()>=self.budget.deadline:self.stop_search()


def run_budgeted(loader,budget_seconds,presolve=True,clock=time.perf_counter):
    if not math.isfinite(budget_seconds) or budget_seconds<=0:
        raise ValueError('Positive finite core budget required')
    budget=Budget(float(budget_seconds),clock);cpu=time.process_time()
    physical=ctx=registry=built=None;stages=[];cache={};proofs=[]
    reason=None;infeasible_in_budget=False;last_integer=None;setup={}
    try:
        budget.poll('before_input_load');physical=loader()
        setup['input_loaded_seconds']=budget.now()-budget.started
        budget.poll('after_input_load');ctx=make_context(physical)
        setup['context_ready_seconds']=budget.now()-budget.started
        registry=PhysicalRegistry(ctx,budget.started,budget.deadline,clock=budget.now)
        budget.poll('after_context');built=build(physical,checkpoint=budget.poll)
        setup['model_ready_seconds']=budget.now()-budget.started
        for level in reversed(range(len(built.digits))):
            budget.poll('before_digit_objective');built.model.minimize(built.digits[level])
            solver=cp_model.CpSolver();solver.parameters.num_search_workers=1
            solver.parameters.random_seed=0;solver.parameters.cp_model_presolve=bool(presolve)
            solver.parameters.absolute_gap_limit=0;solver.parameters.relative_gap_limit=0
            budget.poll('before_CP_solve');called=budget.now()
            remaining=budget.deadline-called
            if remaining<=0:raise Expired('before_CP_solve')
            solver.parameters.max_time_in_seconds=remaining
            collector=Collector(built,budget,registry,cache,level)
            row={'digit':level,'call_started_seconds':called-budget.started,
                'native_time_limit_seconds':remaining,'native_status':None,
                'returned_seconds':None,'events':collector.events,'proof_used':False,
                'proof_ready_seconds':None,'optimal_digit_value':None}
            stages.append(row)
            status=solver.solve(built.model,collector)
            returned=budget.now();row['returned_seconds']=returned-budget.started
            row['native_status']=solver.status_name(status)
            row['callbacks_skipped_after_deadline']=collector.skipped_after_deadline
            if status not in (cp_model.OPTIMAL,cp_model.FEASIBLE,cp_model.INFEASIBLE,cp_model.UNKNOWN):
                raise RuntimeError('Unexpected CP-SAT status: '+row['native_status'])
            if returned>=budget.deadline:
                reason='budget_after_CP_return';break
            if status==cp_model.INFEASIBLE:
                assert registry.best is None,'A proved feasible prefix cannot become infeasible'
                row['proof_ready_seconds']=budget.now()-budget.started
                row['proof_used']=row['proof_ready_seconds']<=budget_seconds
                infeasible_in_budget=row['proof_used'];reason='proved_infeasible' if infeasible_in_budget else 'late_infeasibility_proof'
                break
            if status not in (cp_model.OPTIMAL,cp_model.FEASIBLE):
                reason='native_unknown';break
            last_integer,_=collector.record(solver,'CP_final_assignment')
            budget.poll('after_final_registration')
            if status!=cp_model.OPTIMAL:
                reason='native_feasible_without_digit_proof';break
            value=int(solver.value(built.digits[level]));row['optimal_digit_value']=value
            built.model.add(built.digits[level]==value)
            row['proof_ready_seconds']=budget.now()-budget.started
            row['proof_used']=row['proof_ready_seconds']<=budget_seconds
            if not row['proof_used']:
                reason='budget_after_digit_proof';break
            proofs.append({'digit':level,'value':value,'ready_seconds':row['proof_ready_seconds']})
        else:
            reason='all_digits_proved'
    except Expired as error:
        reason='budget_at_'+str(error)
    best=registry.best if registry is not None else None
    complete=built is not None and len(proofs)==len(built.digits)
    optimal=False
    if complete:
        assert best is not None and last_integer is not None
        assert F(best['score_fraction'])==F(last_integer,built.objective_denominator)
        optimal=True
    status='OPTIMAL' if optimal else 'FEASIBLE' if best is not None else 'INFEASIBLE' if infeasible_in_budget else 'UNKNOWN'
    elapsed=budget.now()-budget.started
    return {'status':status,'stop_reason':reason,'presolve':bool(presolve),'budget_seconds':budget_seconds,
        'algorithm_wall_seconds':elapsed,'algorithm_cpu_seconds':time.process_time()-cpu,
        'overshoot_seconds':max(0.,elapsed-budget_seconds),'setup':setup,
        'registered_attempts':registry.attempts if registry is not None else [],'best_registered':best,
        'registration_seconds':registry.registration_seconds if registry is not None else 0.,
        'stages':stages,'proved_optimal_prefix':proofs,
        'all_digits_proved_within_budget':optimal,
        'objective_digits':len(built.digits) if built is not None else None,
        'objective_denominator':str(built.objective_denominator) if built is not None else None,
        'input_sha256':physical.input_sha256 if physical is not None else None,
        'checkpoint_counts':budget.polls,'last_checkpoint':budget.last_phase,
        'module_loading_excluded_from_core':True,'input_context_model_callbacks_registration_and_policy_charged':True,
        'JSON_serialization_after_core':True,'eligibility_rule':'available_seconds<=budget_seconds',
        'unpaid_initializer_or_external_cache':False,'hard_return_deadline_guaranteed':False,
        'new_public_quality_or_general_performance_qualified':False}


def run_file(path,budget_seconds,**kwargs):
    path=Path(path).resolve()
    if 'neso_' in str(path).lower():raise ValueError('Reserved path before content access')
    return run_budgeted(lambda:load_instance(path),budget_seconds,**kwargs)
