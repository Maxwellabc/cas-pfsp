"""Core-clock qualification for the exact integer reference."""
