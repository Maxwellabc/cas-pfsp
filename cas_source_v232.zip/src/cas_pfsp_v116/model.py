"""Keep exact renewable fractions without scaling every load by their denominator.

The positive deficit over an integer load is split into integer excess and one
threshold correction. Arbitrarily wide nonnegative integer objectives are
added in small-base digits and minimized lexicographically. This is a standard
arithmetic/reference encoding, not a proposed scheduling heuristic.
"""
from dataclasses import dataclass
from fractions import Fraction as F
import itertools
import math
import time
from cas_pfsp_v45.model import validate_instance
from cas_pfsp_v45.timestep_accounting_r1 import check_benchmark_schedule
from cas_pfsp_v113.integer_reference import exact, LIMIT


@dataclass
class Built:
    model: object
    instance: object
    ranks: list
    starts: list
    digits: list
    base: int
    power_scale: int
    objective_denominator: int
    objective_upper_bound: int
    arithmetic: dict


def digit_sum(model, weighted, checkpoint=lambda phase: None):
    """Unique base-B representation of a nonnegative integer linear sum."""
    weighted = [(int(c), x, int(ub)) for c, x, ub in weighted if c and ub]
    upper = sum(c * ub for c, _, ub in weighted)
    mass = sum(ub for _, _, ub in weighted)
    if 4 * mass > LIMIT:
        raise ValueError('Conservative CP-SAT int64 arithmetic guard exceeded')
    k = max(1, min(20, (LIMIT // max(1, 2 * mass)).bit_length() - 1))
    base = 2**k
    count = max(1, (upper.bit_length() + k - 1) // k)
    digits, carry, carry_ub = [], 0, 0
    largest_row_bound = 0
    for level in range(count):
        checkpoint("objective_digit")
        limb = [(c // (base**level) % base, x, ub) for c, x, ub in weighted]
        bound = carry_ub + sum(c * ub for c, _, ub in limb)
        next_ub = bound // base
        digit = model.new_int_var(0, base - 1, f'objective_digit_{level}')
        next_carry = model.new_int_var(0, next_ub, f'objective_carry_{level+1}')
        model.add(sum(c * x for c, x, _ in limb if c) + carry == digit + base * next_carry)
        largest_row_bound = max(largest_row_bound, bound + base * next_ub + base - 1)
        digits.append(digit); carry, carry_ub = next_carry, next_ub
    assert carry_ub == 0
    if largest_row_bound > 2 * LIMIT:
        raise ValueError('Conservative CP-SAT int64 arithmetic guard exceeded')
    return digits, base, upper, largest_row_bound


def build(instance, checkpoint=lambda phase: None):
    checkpoint("model_begin")
    validate_instance(instance)
    n, m, h, d = instance.n, instance.m, instance.horizon, instance.durations
    powers = [[[exact(v) for v in op] for op in job] for job in instance.powers]
    renewable, carbon = [exact(v) for v in instance.renewable], [exact(v) for v in instance.carbon]
    dp = math.lcm(1, *(v.denominator for job in powers for op in job for v in op))
    p = [[[int(v * dp) for v in op] for op in job] for job in powers]
    cap = sum(max(op, default=0) for job in p for op in job)
    convolution_mass = sum(max(0, h - sum(d[j]) + 1) * sum(p[j][a])
                           for j in range(n) for a in range(m))
    if max(cap, convolution_mass, h) > LIMIT:
        raise ValueError('Conservative CP-SAT int64 arithmetic guard exceeded')
    from ortools.sat.python import cp_model
    model = cp_model.CpModel()
    ranks = [model.new_int_var(0, n - 1, f'rank_{j}') for j in range(n)]
    model.add_all_different(ranks)
    starts = [[model.new_int_var(0, h, f'start_{j}_{a}') for a in range(m)] for j in range(n)]
    choices = {}
    for j, a in itertools.product(range(n), range(m)):
        checkpoint("operation_start_choices")
        lo, hi = sum(d[j][:a]), h - sum(d[j][a:])
        model.add(starts[j][a] >= lo); model.add(starts[j][a] <= hi)
        if a + 1 < m:
            model.add(starts[j][a+1] >= starts[j][a] + d[j][a])
        if d[j][a]:
            at = {s: model.new_bool_var(f'at_{j}_{a}_{s}') for s in range(lo, hi + 1)}
            choices[j, a] = at
            model.add_exactly_one(at.values())
            model.add(starts[j][a] == sum(s * x for s, x in at.items()))
    for i, j in itertools.combinations(range(n), 2):
        checkpoint("permutation_pair")
        before = model.new_bool_var(f'before_{i}_{j}')
        model.add(ranks[i] < ranks[j]).only_enforce_if(before)
        model.add(ranks[i] > ranks[j]).only_enforce_if(~before)
        for a in range(m):
            model.add(starts[j][a] >= starts[i][a] + d[i][a]).only_enforce_if(before)
            model.add(starts[i][a] >= starts[j][a] + d[j][a]).only_enforce_if(~before)
    terms = []
    for t in range(h):
        checkpoint("load_slot")
        load = model.new_int_var(0, cap, f'load_{t}')
        model.add(load == sum(p[j][a][t-s] * x for (j, a), at in choices.items()
            for s, x in at.items() if 0 <= t-s < d[j][a] and p[j][a][t-s]))
        r = dp * renewable[t]
        if r >= cap:
            continue
        floor = r.numerator // r.denominator; f = r - floor
        excess = model.new_int_var(0, cap - floor, f'excess_{t}')
        model.add_max_equality(excess, [0, load - floor])
        if f == 0:
            terms.append((carbon[t], excess, cap - floor))
        else:
            positive = model.new_bool_var(f'positive_deficit_{t}')
            model.add(excess >= 1).only_enforce_if(positive)
            model.add(excess == 0).only_enforce_if(~positive)
            whole = model.new_int_var(0, max(0, cap-floor-1), f'whole_deficit_{t}')
            model.add(whole == excess - positive)
            terms.extend([(carbon[t], whole, max(0, cap-floor-1)),
                          (carbon[t] * (1-f), positive, 1)])
    cost_scale = math.lcm(1, *(c.denominator for c, _, _ in terms))
    weighted = [(int(c * cost_scale), var, ub) for c, var, ub in terms]
    digits, base, upper, max_row = digit_sum(model, weighted, checkpoint)
    checkpoint("model_validation")
    error = model.validate()
    if error:
        raise ValueError('CP-SAT model validation: ' + error)
    checkpoint("model_complete")
    return Built(model, instance, ranks, starts, digits, base, dp, 4*dp*cost_scale, upper,
        {'gross_upper_bound': cap, 'convolution_coefficient_mass': convolution_mass,
         'largest_digit_constraint_bound': max_row, 'objective_bits': upper.bit_length(),
         'objective_digits': len(digits), 'objective_base': base})

