"""Exact two-operation timing diagnostics under the unchanged v45 model."""
