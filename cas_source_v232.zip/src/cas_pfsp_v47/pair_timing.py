"""Restricted exact pair timing repair and a separable supply relaxation.

Pairs must belong to different jobs AND machines,so no direct precedence edge
connects the two variable starts. All other starts and the permutation remain
fixed. Their feasible domains are then a Cartesian product of integer ranges.
This is a research primitive,not an established novel or effective optimizer.
"""
from dataclasses import dataclass
from fractions import Fraction as F
import math

from cas_pfsp_v45.model import validate_instance
from cas_pfsp_v45.timestep_accounting_r1 import check_benchmark_schedule


@dataclass(frozen=True)
class IntegerContext:
    powers: tuple
    renewable: tuple
    carbon: tuple
    denominator: int
    horizon: int
    durations: tuple


def make_context(instance):
    validate_instance(instance)
    power_scale = carbon_scale = 1
    coefficients = instance.renewable + instance.carbon + tuple(
        value for job in instance.powers for op in job for value in op)
    if any(type(value) not in (int, F) for value in coefficients):
        raise TypeError('Use exact integer/Fraction input coefficients')
    for v in instance.renewable + tuple(value for job in instance.powers for op in job for value in op):
        power_scale = math.lcm(power_scale, F(v).denominator)
    for v in instance.carbon:
        carbon_scale = math.lcm(carbon_scale, F(v).denominator)
    powers = tuple(tuple(tuple(int(v*power_scale) for v in op) for op in job) for job in instance.powers)
    return IntegerContext(powers, tuple(int(v*power_scale) for v in instance.renewable),
                          tuple(int(v*carbon_scale) for v in instance.carbon),
                          4*power_scale*carbon_scale, instance.horizon, instance.durations)


def gross_profile(ctx, starts):
    gross = [0]*ctx.horizon
    for j, job in enumerate(ctx.powers):
        for m, op in enumerate(job):
            for r, power in enumerate(op):
                gross[starts[j][m]+r] += power
    return gross


def load_functional(ctx, gross):
    """Cost numerator of a load vector;not a feasibility assertion."""
    return sum(c*max(q-a, 0) for q, a, c in zip(gross, ctx.renewable, ctx.carbon))


def fixed_neighbor_domain(ctx, order, starts, op):
    j, m = op
    pos = order.index(j)
    duration = ctx.durations[j][m]
    lo, hi = 0, ctx.horizon-duration
    if m:
        lo = max(lo, starts[j][m-1]+ctx.durations[j][m-1])
    if m+1 < len(ctx.durations[j]):
        hi = min(hi, starts[j][m+1]-duration)
    if pos:
        previous = order[pos-1]
        lo = max(lo, starts[previous][m]+ctx.durations[previous][m])
    if pos+1 < len(order):
        hi = min(hi, starts[order[pos+1]][m]-duration)
    return range(lo, hi+1)


def marginal(ctx, background, op, start):
    j, m = op
    return sum(ctx.carbon[start+r]*(max(background[start+r]+p-ctx.renewable[start+r], 0)
                                    - max(background[start+r]-ctx.renewable[start+r], 0))
               for r, p in enumerate(ctx.powers[j][m]))


def addition_interaction(ctx, background, u, su, v, sv):
    pu, pv = ctx.powers[u[0]][u[1]], ctx.powers[v[0]][v[1]]
    result = 0
    for t in range(max(su, sv), min(su+len(pu), sv+len(pv))):
        b, a, p, q = background[t], ctx.renewable[t], pu[t-su], pv[t-sv]
        term = max(b+p+q-a, 0)-max(b+p-a, 0)-max(b+q-a, 0)+max(b-a, 0)
        assert term >= 0
        result += ctx.carbon[t]*term
    return result


def prepare_pair(ctx, order, starts, u, v, gross=None):
    if u[0] == v[0] or u[1] == v[1]:
        raise ValueError('Restricted pair requires different jobs and machines')
    if not ctx.powers[u[0]][u[1]] or not ctx.powers[v[0]][v[1]]:
        raise ValueError('Restricted pair excludes zero-duration operations')
    if gross is None:
        gross = gross_profile(ctx, starts)
    background = list(gross)
    for j, m in (u, v):
        for r, p in enumerate(ctx.powers[j][m]):
            background[starts[j][m]+r] -= p
    assert min(background) >= 0
    du = list(fixed_neighbor_domain(ctx, order, starts, u))
    dv = list(fixed_neighbor_domain(ctx, order, starts, v))
    assert starts[u[0]][u[1]] in du and starts[v[0]][v[1]] in dv
    cu = sorted((marginal(ctx, background, u, s), s) for s in du)
    cv = sorted((marginal(ctx, background, v, s), s) for s in dv)
    base = load_functional(ctx, background)
    incumbent = load_functional(ctx, gross)
    lower = base+cu[0][0]+cv[0][0]
    return {'u': tuple(u), 'v': tuple(v), 'background': background, 'base': base,
            'starts_u': cu, 'starts_v': cv, 'incumbent': incumbent,
            'lower_bound': lower, 'gain_upper_bound': incumbent-lower,
            'univariate_marginals_computed': len(cu)+len(cv),
            'incumbent_addition_interaction': addition_interaction(
                ctx, background, u, starts[u[0]][u[1]], v, starts[v[0]][v[1]])}


def exact_pair_repair(ctx, starts, prepared):
    """Return a minimum-cost restricted pair,with sound sorted-cost pruning."""
    u, v = prepared['u'], prepared['v']
    best = prepared['incumbent']
    best_starts = starts[u[0]][u[1]], starts[v[0]][v[1]]
    evaluated = pruned = 0
    for iu, (cost_u, su) in enumerate(prepared['starts_u']):
        if prepared['base']+cost_u+prepared['starts_v'][0][0] >= best:
            pruned += (len(prepared['starts_u'])-iu)*len(prepared['starts_v'])
            break
        for iv, (cost_v, sv) in enumerate(prepared['starts_v']):
            independent = prepared['base']+cost_u+cost_v
            if independent >= best:
                pruned += len(prepared['starts_v'])-iv
                break
            cost = independent+addition_interaction(ctx, prepared['background'], u, su, v, sv)
            evaluated += 1
            if cost < best:
                best, best_starts = cost, (su, sv)
    result = [list(row) for row in starts]
    result[u[0]][u[1]], result[v[0]][v[1]] = best_starts
    domain_size = len(prepared['starts_u'])*len(prepared['starts_v'])
    assert evaluated+pruned == domain_size
    assert prepared['lower_bound'] <= best <= prepared['incumbent']
    return {'starts': result, 'score_numerator': best,
            'score_fraction': str(F(best, ctx.denominator)),
            'gain_numerator': prepared['incumbent']-best,
            'pair_assignments_evaluated': evaluated, 'pair_assignments_pruned': pruned,
            'pair_domain_size': domain_size, 'univariate_marginals_computed': prepared['univariate_marginals_computed']}


def checked_initial_context(instance, order, starts):
    receipt = check_benchmark_schedule(instance, list(order), [list(row) for row in starts])
    ctx = make_context(instance)
    assert F(load_functional(ctx, gross_profile(ctx, starts)), ctx.denominator) == F(receipt['benchmark_score_fraction'])
    return ctx
