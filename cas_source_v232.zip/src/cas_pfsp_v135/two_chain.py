"""Exact finite-horizon timing DP with fixed outside positive starts.

An external feasible anchor and a common permutation are required. All positive
operations on one or two chosen machine rows are free; zero-duration nodes are
free implicitly. A state records processing units completed on each free chain.
This conventional DP primitive does not establish a paid complete algorithm,
public performance, hard return deadlines, or scientific priority.
"""
from fractions import Fraction as F
import itertools
import math
from cas_pfsp_v47.pair_timing import make_context
from cas_pfsp_v64.registry import physical_numerator


class ChainTiming:
    def __init__(self, instance, order, anchor, machine_rows, checkpoint=lambda phase:None):
        self.checkpoint=checkpoint;checkpoint('chain_prepare_begin')
        self.ctx=make_context(instance);self.order=list(order);self.anchor=[list(row) for row in anchor]
        self.anchor_value=physical_numerator(self.ctx,self.order,self.anchor)
        self.n,self.m,self.h=instance.n,instance.m,instance.horizon
        rows=list(machine_rows)
        if not 1<=len(rows)<=2 or any(type(a) is not int for a in rows):
            raise ValueError('One or two integer machine rows required')
        if len(set(rows))!=len(rows):raise ValueError('Duplicate machine row')
        if any(not 0<=a<self.m for a in rows):raise ValueError('Machine row outside model')
        self.rows=tuple(sorted(rows));self.rank={j:i for i,j in enumerate(self.order)}
        self.chains=[[(j,a) for j in self.order if self.ctx.durations[j][a]] for a in self.rows]
        self.free={op for chain in self.chains for op in chain}
        self.fixed=[(j,a) for j in range(self.n) for a in range(self.m)
            if self.ctx.durations[j][a] and (j,a) not in self.free]
        self.domains={}
        for j,a in sorted(self.free):
            checkpoint('chain_prepare_domain');low,high=0,self.h-self.ctx.durations[j][a]
            for u,b in self.fixed:
                checkpoint('chain_fixed_precedence')
                if self.before((u,b),(j,a)):low=max(low,self.anchor[u][b]+self.ctx.durations[u][b])
                if self.before((j,a),(u,b)):high=min(high,self.anchor[u][b]-self.ctx.durations[j][a])
            assert low<=self.anchor[j][a]<=high
            self.domains[j,a]=(low,high)
        self.chain_tables=[];self.work={};self.goal=[]
        for index,chain in enumerate(self.chains):
            checkpoint('chain_prepare_table');table=[];done=0
            for op in chain:
                j,a=op;duration=self.ctx.durations[j][a]
                self.work[op]=(index,done,done+duration)
                for offset in range(duration):table.append((op,offset,offset!=0))
                done+=duration
            table.append((None,None,False));self.chain_tables.append(table);self.goal.append(done)
            assert done<=self.h
        self.goal=tuple(self.goal);self.requirements={}
        for op in sorted(self.free):
            needed=[0]*len(self.rows)
            for other in self.free:
                checkpoint('chain_free_precedence')
                if self.before(other,op):
                    chain,begin,end=self.work[other];needed[chain]=max(needed[chain],end)
            self.requirements[op]=tuple(needed)
        self.background=[0]*self.h
        for j,a in self.fixed:
            checkpoint('chain_fixed_profile')
            for offset,power in enumerate(self.ctx.powers[j][a]):self.background[self.anchor[j][a]+offset]+=power
        self.background_tail=[0]*(self.h+1)
        for t in reversed(range(self.h)):
            self.background_tail[t]=self.background_tail[t+1]+self.ctx.carbon[t]*max(0,self.background[t]-self.ctx.renewable[t])
        self.best_value=self.anchor_value;self.best_starts=[row[:] for row in self.anchor]
        self.layers=[{tuple(0 for a in self.rows):{'cost':0,'parent':None,'starts':[]}}]
        self.frontier_trace=[];self.started=self.complete=False
        self.transitions=self.state_updates=self.materialized=self.improvements=0
        checkpoint('chain_prepare_complete')

    def before(self,u,v):
        return u!=v and self.rank[u[0]]<=self.rank[v[0]] and u[1]<=v[1]

    def point(self,time,work,value):
        starts=[row[:] for row in self.anchor]
        state=work
        for t in reversed(range(1,time+1)):
            record=self.layers[t][state]
            for j,a in record['starts']:starts[j][a]=t-1
            state=record['parent']
        assert state==tuple(0 for a in self.rows)
        previous=None
        for j in self.order:
            for a in range(self.m):
                low=0
                if a:low=max(low,starts[j][a-1]+self.ctx.durations[j][a-1])
                if previous is not None:low=max(low,starts[previous][a]+self.ctx.durations[previous][a])
                if not self.ctx.durations[j][a]:starts[j][a]=low
            previous=j
        assert physical_numerator(self.ctx,self.order,starts)==value
        self.materialized+=1
        return {'permutation':self.order[:],'starts':starts,'score_numerator':value,
            'score_fraction':str(F(value,self.ctx.denominator))}

    def run(self, trace_frontiers=False, on_improvement=lambda point:None):
        if self.started:raise ValueError('A chain DP object is single-use')
        if type(trace_frontiers) is not bool:raise ValueError('Boolean frontier trace option required')
        self.started=True
        def trace(t):
            if trace_frontiers:
                self.frontier_trace.append({'time':t,'states':[{'work':list(k),'prefix_numerator':r['cost']}
                    for k,r in sorted(self.layers[t].items())]})
        trace(0);self.checkpoint('chain_search_begin')
        for t in range(self.h):
            following={}
            for state,record in self.layers[t].items():
                self.checkpoint('chain_frontier_state');choices=[]
                for index,k in enumerate(state):
                    op,offset,active=self.chain_tables[index][k]
                    if active:
                        j,a=op;choices.append([(1,self.ctx.powers[j][a][offset],None)])
                    else:
                        options=[(0,0,None)]
                        if op is not None:
                            low,high=self.domains[op]
                            if low<=t<=high and all(done>=need for done,need in zip(state,self.requirements[op])):
                                j,a=op;options.append((1,self.ctx.powers[j][a][0],op))
                        choices.append(options)
                for chosen in itertools.product(*choices):
                    self.checkpoint('chain_transition');self.transitions+=1
                    target=tuple(k+item[0] for k,item in zip(state,chosen))
                    load=self.background[t]+sum(item[1] for item in chosen)
                    value=record['cost']+self.ctx.carbon[t]*max(0,load-self.ctx.renewable[t])
                    if target not in following or value<following[target]['cost']:
                        following[target]={'cost':value,'parent':state,
                            'starts':[list(item[2]) for item in chosen if item[2] is not None]}
                        self.state_updates+=1
            assert following
            self.layers.append(following);trace(t+1)
            if self.goal in following:
                value=following[self.goal]['cost']+self.background_tail[t+1]
                if value<self.best_value:
                    self.checkpoint('chain_before_physical_candidate');point=self.point(t+1,self.goal,value)
                    on_improvement(point)
                    self.best_value=value;self.best_starts=[row[:] for row in point['starts']];self.improvements+=1
                    self.checkpoint('chain_after_candidate')
            self.checkpoint('chain_layer_complete')
        assert self.goal in self.layers[-1]
        assert self.best_value==self.layers[-1][self.goal]['cost']
        self.checkpoint('chain_search_complete');self.complete=True
        return self.summary()

    def summary(self):
        return {'permutation':self.order[:],'machine_rows':list(self.rows),
            'free_positive':[list(op) for op in sorted(self.free)],'all_zero_duration_nodes_free':True,
            'domains':[{'operation':list(op),'lower':self.domains[op][0],'upper':self.domains[op][1]} for op in sorted(self.free)],
            'chain_operations':[[list(op) for op in chain] for chain in self.chains],
            'chain_work_totals':list(self.goal),'states_per_layer_upper_bound':math.prod(d+1 for d in self.goal),
            'requirements':[{'operation':list(op),'completed_work_required':list(self.requirements[op])} for op in sorted(self.free)],
            'objective_denominator':self.ctx.denominator,'fixed_background_total_numerator':self.background_tail[0],
            'completed_time_layers':len(self.layers)-1,'frontier_sizes':[len(layer) for layer in self.layers],
            'transition_count':self.transitions,'state_updates':self.state_updates,
            'physical_points_materialized':self.materialized,'strict_improvements':self.improvements,
            'best':{'permutation':self.order[:],'starts':[row[:] for row in self.best_starts],
                'score_numerator':self.best_value,'score_fraction':str(F(self.best_value,self.ctx.denominator))},
            'frontier_trace':self.frontier_trace,'neighborhood_proved_optimal':self.complete,
            'all_feasible_schedules_enumerated':False,'external_anchor_mathematical_primitive_only':True,
            'complete_paid_algorithm_or_common_core_budget_qualified':False,
            'positive_global_optimum_claim':False,'public_quality_or_priority_qualified':False}
