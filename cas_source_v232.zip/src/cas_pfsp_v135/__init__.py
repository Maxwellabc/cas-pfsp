"""Exact timing on one or two fixed-order machine chains; private primitive."""
