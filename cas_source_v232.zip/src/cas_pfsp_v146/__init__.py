"""Private constraint-extraction transfer primitives; no paid ALNS policy."""
