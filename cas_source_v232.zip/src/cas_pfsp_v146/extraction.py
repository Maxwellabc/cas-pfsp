"""Explicit order effects of published-style operation constraint extraction.

Assignments are fixed in CAS-PFSP. Outside operation starts are NOT fixed.
The common permutation couples machine orders, so removing all operations
on only some machine rows can leave every job-order relation fixed.
These are transfer primitives, not the original EJOR ALNS or a new algorithm.
"""
from itertools import combinations


def validate(order, durations):
    if not isinstance(durations, (list, tuple)) or not durations:
        raise ValueError('Nonempty duration matrix required')
    n = len(durations)
    if not isinstance(durations[0], (list, tuple)) or not durations[0]:
        raise ValueError('Nonempty machine rows required')
    m = len(durations[0])
    if any(not isinstance(row, (list, tuple)) or len(row) != m or
           any(type(d) is not int or d < 0 for d in row) for row in durations):
        raise ValueError('Rectangular nonnegative integer durations required')
    if not isinstance(order, (list, tuple)) or len(order) != n or any(type(j) is not int for j in order) or sorted(order) != list(range(n)):
        raise ValueError('Complete integer permutation required')
    return n, m


def operation_extraction(order, durations, free_operations, checkpoint=lambda phase: None):
    """Preserve outside same-machine precedences as in source Eq18.

    A nonzero duration at either end forces the same rank orientation.
    Two zero-duration nodes may be tied, so their time inequality alone does
    not force that orientation. The time inequality is still retained.
    """
    n, m = validate(order, durations)
    checkpoint('extraction_begin')
    values = list(free_operations)
    if any(not isinstance(op, (list, tuple)) or len(op) != 2 or
           any(type(k) is not int for k in op) or
           not (0 <= op[0] < n and 0 <= op[1] < m) for op in values):
        raise ValueError('Valid free operation pairs required')
    free = {tuple(op) for op in values}
    if len(free) != len(values):
        raise ValueError('Duplicate free operation')
    time_edges, forced = [], set()
    for machine in range(m):
        outside = [j for j in order if (j, machine) not in free]
        for first, second in combinations(outside, 2):
            checkpoint('extraction_outside_pair')
            time_edges.append([first, second, machine])
            if durations[first][machine] + durations[second][machine] > 0:
                forced.add((first, second))
    checkpoint('extraction_complete')
    return {
        'kind': 'operation_constraint_extraction',
        'anchor_order': list(order), 'free_operations': [list(op) for op in sorted(free)],
        'preserved_operation_precedences': time_edges,
        'forced_rank_pairs': [list(pair) for pair in sorted(forced)],
        'extra_explicit_rank_pairs': [], 'fixed_operation_starts': [],
        'all_operation_starts_remain_variables': True,
        'machine_assignment_decisions_exist': False,
        'complete_paid_ALNS_policy': False,
    }


def machine_extraction(order, durations, free_machines, checkpoint=lambda phase: None):
    n, m = validate(order, durations)
    machines = list(free_machines)
    if any(type(a) is not int or not 0 <= a < m for a in machines) or len(set(machines)) != len(machines):
        raise ValueError('Distinct valid machine indices required')
    result = operation_extraction(order, durations,
        [(j, a) for j in range(n) for a in sorted(machines)], checkpoint)
    result.update(kind='machine_removal_constraint_extraction', free_machines=sorted(machines))
    return result


def job_extraction(order, durations, free_jobs, checkpoint=lambda phase: None):
    """CAS adaptation: remove whole jobs, preserve outside common job order.

    For all-positive durations this is exactly the corresponding operation
    extraction. Explicit rank constraints also preserve the order of two
    outside zero-only jobs; that convention is an additional CAS restriction,
    not a claim that the original time inequalities imply it.
    """
    n, m = validate(order, durations)
    jobs = list(free_jobs)
    if any(type(j) is not int or not 0 <= j < n for j in jobs) or len(set(jobs)) != len(jobs):
        raise ValueError('Distinct valid job indices required')
    free = set(jobs)
    result = operation_extraction(order, durations,
        [(j, a) for j in sorted(jobs) for a in range(m)], checkpoint)
    outside = [j for j in order if j not in free]
    required = list(combinations(outside, 2))
    inferred = {tuple(pair) for pair in result['forced_rank_pairs']}
    extra = []
    for pair in required:
        checkpoint('extraction_outside_job_rank')
        if pair not in inferred:
            extra.append(list(pair))
    result.update(kind='CAS_whole_job_constraint_extraction', free_jobs=sorted(jobs),
                  extra_explicit_rank_pairs=extra,
                  zero_only_outside_job_rank_convention_is_additional_restriction=True)
    checkpoint('job_extraction_complete')
    return result
