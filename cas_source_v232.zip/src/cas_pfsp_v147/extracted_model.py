"""Bind explicit extraction constraints to the unchanged compact CAS model."""
from dataclasses import dataclass
from cas_pfsp_v118.compact_reference import build
from cas_pfsp_v146.extraction import operation_extraction, machine_extraction, job_extraction


@dataclass
class ExtractedModel:
    physical: object
    descriptor: dict


def build_extracted(instance, order, kind, free, checkpoint=lambda phase: None):
    checkpoint('before_extraction')
    methods = {'operation': operation_extraction, 'machine': machine_extraction, 'job': job_extraction}
    if kind not in methods:
        raise ValueError('Extraction kind operation,machine or job required')
    descriptor = methods[kind](order, instance.durations, free, checkpoint)
    checkpoint('before_underlying_compact')
    built = build(instance, checkpoint=checkpoint)
    for i, j, a in descriptor['preserved_operation_precedences']:
        checkpoint('extraction_time_edge')
        built.model.add(built.starts[i][a] + instance.durations[i][a] <= built.starts[j][a])
    for i, j in descriptor['forced_rank_pairs'] + descriptor['extra_explicit_rank_pairs']:
        checkpoint('extraction_rank_edge')
        built.model.add(built.ranks[i] < built.ranks[j])
    checkpoint('extraction_model_validation')
    error = built.model.validate()
    if error:
        raise ValueError('Extracted model validation: ' + error)
    checkpoint('extraction_model_complete')
    return ExtractedModel(built, descriptor)
