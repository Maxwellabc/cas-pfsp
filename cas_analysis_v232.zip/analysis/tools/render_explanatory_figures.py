"""Code-drawn vector problem and search diagrams; finite formulation checks."""
from pathlib import Path
from fractions import Fraction as F
from itertools import permutations,product
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Polygon

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'rebuilt_figures'
PAPER=ROOT

def canvas():
    fig,ax=plt.subplots(figsize=(3.16,2.55))
    fig.subplots_adjust(left=.015,right=.985,bottom=.02,top=.98)
    ax.set_xlim(0,10);ax.set_ylim(0,8);ax.axis('off')
    return fig,ax
def box(ax,x,y,w,h,text,fill='#F4F6F8',size=7.0):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.04,rounding_size=.06',
        linewidth=.65,edgecolor='#333333',facecolor=fill))
    ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size)
def arrow(ax,a,b,label=None,offset=(0,0)):
    ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='-|>',lw=.7,color='#444444',shrinkA=1,shrinkB=1))
    if label:ax.text((a[0]+b[0])/2+offset[0],(a[1]+b[1])/2+offset[1],label,fontsize=6.5,ha='center',va='center')
def save(fig,name):
    for ext in ['pdf','svg','png']:fig.savefig(OUT/(name+'.'+ext),dpi=230)
    (PAPER/'figures'/(name+'.pdf')).write_bytes((OUT/(name+'.pdf')).read_bytes());plt.close(fig)

def diagrams():
    OUT.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7.2,'pdf.fonttype':42,'svg.fonttype':'none'})
    fig,ax=canvas()
    ax.text(5,7.65,r'Common permutation $\pi$: $J_1,J_2,\ldots,J_n$',ha='center',fontsize=7.5)
    for x,label in [(0.35,'Machine 1'),(3.85,'Machine 2'),(7.35,'Machine m')]:
        box(ax,x,5.9,2.3,1.05,label+'\nFixed profiles',size=6.8)
    arrow(ax,(2.7,6.45),(3.8,6.45));arrow(ax,(6.2,6.45),(7.3,6.45),r'$\cdots$',offset=(0,.35))
    ax.text(5,5.4,'Route precedence and nonpreemptive processing',ha='center',fontsize=6.8)
    box(ax,3.1,3.9,3.8,.85,r'Aggregate demand $q_t$')
    for x in [1.5,5,8.5]:
        ax.plot([x,x,5],[5.05,4.95,4.95],color='#777777',lw=.55)
    arrow(ax,(5,4.95),(5,4.78))
    box(ax,.3,2.2,2.55,.9,'Renewable\n'+r'supply $R_t$',fill='#EFF5F3',size=6.8)
    box(ax,3.25,2.05,3.5,1.2,'Shared balance\n'+r'$g_t=[q_t-R_t]_+$',fill='#EAF0F7')
    box(ax,7.2,2.2,2.5,.9,'Grid intensity\n'+r'$c_t$')
    arrow(ax,(5,3.85),(5,3.3));arrow(ax,(2.9,2.65),(3.2,2.65))
    box(ax,3.1,.35,3.8,.95,'Carbon emissions\n'+r'$\Delta\sum c_t g_t$',fill='#EAF0F7',size=6.7)
    arrow(ax,(5,2.0),(5,1.35))
    ax.plot([8.45,8.45,7.0],[2.15,.82,.82],color='#555555',lw=.65)
    arrow(ax,(7,.82),(6.95,.82))
    ax.text(.35,.55,'Shared supply\ncounted once',fontsize=6.5,ha='left',color='#395B72')
    save(fig,'fig01_problem_structure')
    fig,ax=canvas()
    box(ax,1.9,6.9,6.2,.75,'Start clock; fast initialization\n60% of root budget',size=6.7)
    box(ax,1.9,5.6,6.2,.75,'Rank rows at a new anchor\nor reuse cached ordering',size=6.7)
    arrow(ax,(5,6.85),(5,6.4))
    box(ax,2.7,4.3,4.6,.75,'Select an untried group\nof one or two rows',size=6.7)
    arrow(ax,(5,5.55),(5,5.1))
    box(ax,.3,2.7,4.2,.95,'One row\nPrefix-minimum recurrence',fill='#EAF0F7',size=6.5)
    box(ax,5.5,2.7,4.2,.95,'Two rows\nCommon-time work states',fill='#EFF5F3',size=6.5)
    arrow(ax,(3.6,4.25),(2.4,3.7));arrow(ax,(6.4,4.25),(7.6,3.7))
    box(ax,1.9,1.2,6.2,.8,'Physical validation\nRetain a strict improvement',size=6.7)
    arrow(ax,(2.4,2.65),(3.8,2.05));arrow(ax,(7.6,2.65),(6.2,2.05))
    box(ax,2.0,.05,6,.65,'Return best timely feasible schedule',size=6.3)
    arrow(ax,(5,1.15),(5,.75),'stop',offset=(.65,0))
    ax.plot([8.15,9.85,9.85,8.15],[1.6,1.6,5.98,5.98],lw=.7,color='#555555')
    arrow(ax,(8.55,5.98),(8.15,5.98))
    ax.text(9.6,4.25,'continue',rotation=90,fontsize=6.2,ha='center')
    ax.text(.3,4.4,'0.5 s slices',fontsize=6.3)
    save(fig,'fig02_search_flow')

def formulation_checks():
    (ROOT/'qa').mkdir(exist_ok=True)
    fixtures=[dict(d=[[1,1],[2,0]],H=5),dict(d=[[1,2],[1,1]],H=5),dict(d=[[1,0],[0,1],[1,1]],H=3)]
    tested=feasible=physical=0
    for f in fixtures:
        ds=f['d'];H=f['H'];n=len(ds);m=len(ds[0]);ops=list(product(range(n),range(m)))
        for perm in permutations(range(n)):
            rank={j:k for k,j in enumerate(perm)}
            y={(j,k):int(rank[j]<rank[k]) for j in range(n) for k in range(n) if j!=k}
            assert all(y[j,k]+y[k,j]==1 for j,k in y)
            assert all(y[j,k]+y[k,l]-1<=y[j,l] for j,k,l in permutations(range(n),3))
            for values in product(*(range(H-ds[j][a]+1) for j,a in ops)):
                s=dict(zip(ops,values));tested+=1
                route=all(s[j,a+1]>=s[j,a]+ds[j][a] for j in range(n) for a in range(m-1))
                native=route and all(s[perm[k+1],a]>=s[perm[k],a]+ds[perm[k]][a] for k in range(n-1) for a in range(m))
                linear=route and all(s[k,a]>=s[j,a]+ds[j][a]-H*(1-y[j,k]) for j,k in y for a in range(m))
                assert native==linear
                if not native:continue
                feasible+=1
                loads=[];indexed=[]
                for t in range(H):
                    # A positive-duration operation may have a zero-power profile.
                    p=lambda j,a,h:0 if (j+a)%3==0 else F(2+j+a+h,2)
                    q=sum((p(j,a,t-s[j,a]) for j,a in ops if s[j,a]<=t<s[j,a]+ds[j][a]),F(0))
                    xq=sum((p(j,a,t-u)*int(s[j,a]==u) for j,a in ops for u in range(H-ds[j][a]+1) if u<=t<u+ds[j][a]),F(0))
                    assert q==xq;loads.append(q);indexed.append(xq)
                renewable=[F(t%3) for t in range(H)];carbon=[F(1+t%2) for t in range(H)]
                g=[max(0,indexed[t]-renewable[t]) for t in range(H)]
                assert sum(carbon[t]*g[t]/4 for t in range(H))==sum(carbon[t]*max(0,loads[t]-renewable[t])/4 for t in range(H))
                physical+=1
    result=dict(status='passed',fixtures=fixtures,permutation_start_assignments=tested,feasible_assignments=feasible,
        objectives_and_time_indexed_loads_checked=physical,model_scope='Equivalent formulation of the accepted deterministic model; no new optimization runs',
        includes_zero_duration_and_positive_duration_zero_power=True,optimizer_calls=0,protected270_contents_read=False)
    (ROOT/'qa/formulation_QA_rebuilt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':diagrams();formulation_checks()
