"""Retrospective statistics and vector plots; never imports or calls an optimizer.

Run from any directory. The input is a copy of the already audited 720-cell
record, not benchmark input contents. All paired comparisons use exact
rational objectives before any floating-point resampling or plotting.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter, defaultdict
from datetime import datetime, timezone
import csv, hashlib, json, math, os
os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/cas_v231_matplotlib')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P = Path(__file__).resolve().parents[1]
D, S, V = P/'data', P/'sections', P/'figures'
METHODS = ['serial_rows','no_serial','no_pair','lexicographic',
           'fast_wait','local_wait_raw','adaptive_cp_alns','lg_ucb26']
CONTROLS = METHODS[4:]
DELETIONS = METHODS[1:4]
COMPARATORS = CONTROLS + DELETIONS
FAMILIES = ['M5T1','M5T3','M10T1','M10T3','M15T1','M15T3']
LABEL = dict(zip(METHODS, ['SR','No serial','No pair','Lexicographic',
                         'Fast-wait','Raw wait','ALNS/CP','UCB transfer']))
COLORS = ['#156b69','#6d9f67','#4c78a8','#9b7aa8',
          '#ca8b2c','#777777','#b65050','#8b6546']
BOOTSTRAPS, PERMUTATIONS, SEED = 50000, 50000, 2026102731

def avg(xs): return sum(xs, F(0))/len(xs)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def ranks(xs):
    return [1 + sum(y < x for y in xs) + F(sum(y == x for y in xs)-1, 2) for x in xs]

def signed_rank(ds):
    nz = [x for x in ds if x]
    rs = ranks([abs(x) for x in nz])
    ws = [int(2*x) for x in rs]
    plus = sum(w for d,w in zip(nz,ws) if d > 0)
    total, observed = sum(ws), abs(2*plus-sum(ws))
    # Enumerate the exact sign-flip distribution with a subset-sum recurrence.
    counts = [1]
    for w in ws:
        new = [0]*(len(counts)+w)
        for j,n in enumerate(counts):
            new[j] += n
            new[j+w] += n
        counts = new
    tail = sum(n for j,n in enumerate(counts) if abs(2*j-total) >= observed)
    return dict(nonzero=len(nz), zero=len(ds)-len(nz),
                W_plus_fraction=str(F(plus,2)), W_minus_fraction=str(F(total-plus,2)),
                p_fraction=str(F(tail,2**len(nz))),
                rank_biserial_fraction=str(F(2*plus-total,total) if total else F(0)))

def sign_p(ds):
    w,l = sum(x>0 for x in ds), sum(x<0 for x in ds)
    if w+l == 0: return F(1)
    return min(F(1), F(2*sum(math.comb(w+l,j) for j in range(min(w,l)+1)),2**(w+l)))

def holm(values):
    order=sorted(range(len(values)),key=lambda j:values[j]); out=[None]*len(values); largest=F(0)
    for i,j in enumerate(order):
        largest=max(largest,min(F(1),(len(values)-i)*values[j])); out[j]=largest
    return out

def chi7_survival(x):
    z=x/2; result=math.erfc(math.sqrt(z)); a=.5
    for _ in range(3):
        result += math.exp(a*math.log(z)-z-math.lgamma(a+1)); a+=1
    return result

def ptex(value):
    value=float(F(value))
    if value < .0001:
        exponent=math.floor(math.log10(value))
        return f'${value/10**exponent:.2f}\\!\\times\\!10^{{{exponent}}}$'
    return f'{value:.4f}'

def table(caption,label,spec,header,body,small='footnotesize'):
    return ('\\begin{table}[tbp]\\centering\\'+small+'\\setlength{\\tabcolsep}{3.5pt}\n'
            '\\caption{'+caption+'}\\label{'+label+'}\n'
            '\\begin{tabular}{@{}'+spec+'@{}}\\toprule\n'+header+'\n'+
            '\n'.join(body)+'\n\\bottomrule\\end{tabular}\\end{table}\n')

def save(fig,name):
    fig.savefig(V/(name+'.pdf'), metadata={'CreationDate':None,'ModDate':None})
    fig.savefig(V/(name+'.png'),dpi=220)
    plt.close(fig)

def figure_style():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7.1,
      'axes.labelsize':7.2,'xtick.labelsize':6.6,'ytick.labelsize':6.8,
      'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,
      'pdf.fonttype':42,'ps.fonttype':42,'lines.linewidth':1.15,
      'figure.figsize':(3.16,2.55),'savefig.facecolor':'white'})

def main():
    source=D/'audited_cohort_C_v218.json'; audit=json.loads(source.read_text()); rows=audit['rows']
    assert len(rows)==720 and not audit['technical_failures']
    assert all(r['audit_passed'] and r['best_fraction'] is not None for r in rows)
    by=defaultdict(list)
    for r in rows: by[r['case'],r['method']].append(r)
    cases=sorted({r['case'] for r in rows},key=lambda c:(FAMILIES.index(by[c,'serial_rows'][0]['family']),c))
    family={c:by[c,'serial_rows'][0]['family'] for c in cases}
    means={(c,m):avg([F(r['best_fraction']) for r in by[c,m]]) for c in cases for m in METHODS}
    refs={c:min(F(r['best_fraction']) for m in METHODS for r in by[c,m]) for c in cases}
    gaps={(c,m):[100*(F(r['best_fraction'])/refs[c]-1) for r in by[c,m]] for c in cases for m in METHODS}
    rankrows=[ranks([means[c,m] for m in METHODS]) for c in cases]
    meanr=[avg([row[j] for row in rankrows]) for j in range(8)]
    tie_sum=sum(t**3-t for c in cases for t in Counter(means[c,m] for m in METHODS).values())
    correction=1-F(tie_sum,30*(8**3-8))
    raw=F(12*30,8*9)*(sum(x*x for x in meanr)-F(8*9*9,4))
    statistic=raw/correction
    rng=np.random.default_rng(SEED)
    rankmatrix=np.array([[float(x) for x in row] for row in rankrows])
    exceed=0
    for _ in range(PERMUTATIONS//1000):
        shuffled=np.take_along_axis(np.broadcast_to(rankmatrix,(1000,30,8)),rng.random((1000,30,8)).argsort(axis=2),axis=2)
        sim=12*30/(8*9)*(np.sum(np.mean(shuffled,axis=1)**2,axis=1)-8*9*9/4)/float(correction)
        exceed+=int(np.sum(sim>=float(statistic)-1e-12))
    # Every bootstrap draw keeps the six-family mix and each instance's paired methods.
    idx=np.column_stack([rng.choice([i for i,c in enumerate(cases) if family[c]==f],size=(BOOTSTRAPS,5),replace=True) for f in FAMILIES])
    comparisons=[]; bootstrap_means=[]
    for m in COMPARATORS:
        gs=[100*(means[c,m]-means[c,'serial_rows'])/means[c,m] for c in cases]
        ds=[100*(means[c,m]-means[c,'serial_rows'])/refs[c] for c in cases]
        fm={f:avg([g for c,g in zip(cases,gs) if family[c]==f]) for f in FAMILIES}
        rootdiff=[F(br['best_fraction'])-F(sr['best_fraction'])
          for c in cases for br,sr in zip(sorted(by[c,m],key=lambda r:r['seed']),sorted(by[c,'serial_rows'],key=lambda r:r['seed']))]
        boot=np.mean(np.array([float(x) for x in gs])[idx],axis=1)
        bootstrap_means.append(boot)
        lo,hi=np.quantile(boot,[.025,.975],method='linear')
        leave={f:avg([g for c,g in zip(cases,gs) if family[c]!=f]) for f in FAMILIES}
        result=dict(method=m,label=LABEL[m],mean_gain_percent_fraction=str(avg(gs)),
          gains_percent_fraction=[str(x) for x in gs],normalised_differences_fraction=[str(x) for x in ds],
          confidence_interval_percent=[float(lo),float(hi)],family_gains_fraction={f:str(v) for f,v in fm.items()},
          leave_one_family_out_fraction={f:str(v) for f,v in leave.items()},
          wins=sum(g>0 for g in gs),ties=sum(g==0 for g in gs),losses=sum(g<0 for g in gs),
          root_wins=sum(g>0 for g in rootdiff),root_ties=sum(g==0 for g in rootdiff),root_losses=sum(g<0 for g in rootdiff),
          signed_rank=signed_rank(ds),sign_p_fraction=str(sign_p(gs)),family_sign_p_fraction=str(sign_p(list(fm.values()))))
        comparisons.append(result)
    for field,outfield in [('signed_rank','signed_rank_holm_fraction'),('sign_p_fraction','sign_holm_fraction'),('family_sign_p_fraction','family_sign_holm_fraction')]:
        ps=[F(v[field]['p_fraction'] if field=='signed_rank' else v[field]) for v in comparisons]
        for row,p in zip(comparisons,holm(ps)):row[outfield]=str(p)
    summaries=[]; famstats=[]
    for j,m in enumerate(METHODS):
        es=[x for c in cases for x in gaps[c,m]];ts=[r['wall_seconds'] for c in cases for r in by[c,m]]
        variance=avg([sum((v-avg(gaps[c,m]))**2 for v in gaps[c,m])/2 for c in cases])
        summaries.append(dict(method=m,label=LABEL[m],min_gap=float(min(es)),mean_gap=float(avg(es)),max_gap=float(max(es)),
          variance=float(variance),time_min=min(ts),time_mean=float(np.mean(ts)),time_max=max(ts),mean_rank=float(meanr[j])))
        for f in FAMILIES:
            cs=[c for c in cases if family[c]==f]
            famstats.append(dict(family=f,method=m,min_gap=float(avg([min(gaps[c,m]) for c in cs])),
              mean_gap=float(avg([avg(gaps[c,m]) for c in cs])),time_mean=float(np.mean([r['wall_seconds'] for c in cs for r in by[c,m]]))))
    result=dict(created_utc=datetime.now(timezone.utc).isoformat(),status='complete',
      audited_source_sha256=sha(source),optimizer_calls_added=0,protected270_contents_read=False,cohorts_pooled=False,
      retrospective=True,analysis_unit='30 exact three-root instance means; no root pseudoreplication',
      families=FAMILIES,cases=cases,methods=METHODS,seed=SEED,
      bootstrap=dict(replicates=BOOTSTRAPS,stratification='Five paired instance blocks sampled with replacement within each of six fixed families',
        interval='Pointwise percentile 95%; no multiplicity correction; conditional on the observed three-root means'),
      friedman=dict(statistic_fraction=str(statistic),tie_correction_fraction=str(correction),df=7,
        chi_square_p=chi7_survival(float(statistic)),permutations=PERMUTATIONS,exceedances=exceed,
        monte_carlo_p=(exceed+1)/(PERMUTATIONS+1)),
      rank_rows_fraction=[[str(x) for x in row] for row in rankrows],
      summaries=summaries,family_statistics=famstats,comparisons=comparisons)
    (D/'statistical_analysis_v231.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    np.savez_compressed(D/'resampling_v231.npz',indices=idx.astype(np.int16),
                        means=np.column_stack(bootstrap_means))
    with (D/'statistical_comparisons_v231.csv').open('w') as f:
        fields=['method','mean_gain_percent','ci_low','ci_high','signed_rank_p','signed_rank_holm_p','sign_p','sign_holm_p','rank_biserial','wins','ties','losses','root_wins','root_ties','root_losses']
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in comparisons:w.writerow(dict(method=r['method'],mean_gain_percent=float(F(r['mean_gain_percent_fraction'])),
          ci_low=r['confidence_interval_percent'][0],ci_high=r['confidence_interval_percent'][1],
          signed_rank_p=float(F(r['signed_rank']['p_fraction'])),signed_rank_holm_p=float(F(r['signed_rank_holm_fraction'])),
          sign_p=float(F(r['sign_p_fraction'])),sign_holm_p=float(F(r['sign_holm_fraction'])),
          rank_biserial=float(F(r['signed_rank']['rank_biserial_fraction'])),**{k:r[k] for k in fields[-6:]}))
    write_tables(result,by,gaps)
    draw_figures(result)
    print(json.dumps({'friedman':result['friedman'],'comparisons':[{k:r[k] for k in ['method','confidence_interval_percent','signed_rank_holm_fraction','sign_holm_fraction']} for r in comparisons]},indent=2))

def write_tables(result,by,gaps):
    body=[]
    for r in result['summaries']:
        vals=[r[k] for k in ['min_gap','mean_gap','max_gap','variance','time_min','time_mean','time_max','mean_rank']]
        body.append(r['label']+' & '+' & '.join(f'{v:.3f}' for v in vals)+r'\\')
    header=r'& \multicolumn{3}{c}{Objective gap (\%)} & Repeat & \multicolumn{3}{c}{Actual return (s)} & Mean\\'+'\n'+r'\cmidrule(lr){2-4}\cmidrule(lr){6-8}'+'\n'+r'Method & Min & Mean & Max & $\bar v$ & Min & Mean & Max & rank\\\midrule'
    (S/'overall_statistics.tex').write_text(table('Joint quality, variability, time and rank summary for all eight methods. Objective gaps use the best observed root on the same instance; $\\bar v$ is the average within-instance sample variance in percentage points squared. Rank uses the 30 instance means. Every method has 90/90 timely feasible outcomes.','tab:richoverall','lrrrrrrrr',header,body))
    # Two panels retain legible type while making several algorithms' metrics adjacent.
    parts=[]
    for panel,ms in [('(a) Initializer controls',['serial_rows','fast_wait','local_wait_raw']),('(b) Literature controls',['serial_rows','adaptive_cp_alns','lg_ucb26'])]:
        header=r'& '+' & '.join(r'\multicolumn{3}{c}{'+LABEL[m]+'}' for m in ms)+r'\\'+'\n'+r'\cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(lr){8-10}'+'\n'+r'Family & Min & Mean & Time & Min & Mean & Time & Min & Mean & Time\\\midrule'
        body=[]
        for fam in FAMILIES:
            vals=[]
            for m in ms:
                r=next(x for x in result['family_statistics'] if x['family']==fam and x['method']==m)
                vals += [f"{r['min_gap']:.2f}",f"{r['mean_gap']:.2f}",f"{r['time_mean']:.3f}"]
            body.append(fam+' & '+' & '.join(vals)+r'\\')
        parts.append(r'\textnormal{'+panel+'}'+r'\par\smallskip'+'\n'+r'\begin{tabular}{@{}lrrrrrrrrr@{}}\toprule'+'\n'+header+'\n'+'\n'.join(body)+r'\bottomrule\end{tabular}')
    (S/'family_statistics.tex').write_text(r'\begin{table}[tbp]\centering\footnotesize\setlength{\tabcolsep}{3.6pt}'+'\n'+r'\caption{Multiple algorithms and metrics by family. Min is the family average of each instance\textquotesingle s best-root gap (\%); Mean averages all 15 root gaps (\%); Time is the mean actual return in seconds. All gaps use the same best-observed-root reference.}\label{tab:richfamily}'+'\n'+ '\n\\par\\medskip\n'.join(parts)+'\n'+r'\end{table}'+'\n')
    header=r'& \multicolumn{2}{c}{Gain (\%)} & \multicolumn{2}{c}{Holm-adjusted $p$} & Effect\\'+'\n'+r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}'+'\n'+r'Comparator & Mean & 95\% interval & Signed rank & Sign test & $r_{rb}$\\\midrule'
    body=[]
    for r in result['comparisons']:
        lo,hi=r['confidence_interval_percent']
        body.append(r['label']+f" & {float(F(r['mean_gain_percent_fraction'])):.4f} & [{lo:.3f}, {hi:.3f}] & "+ptex(r['signed_rank_holm_fraction'])+' & '+ptex(r['sign_holm_fraction'])+f" & {float(F(r['signed_rank']['rank_biserial_fraction'])):.3f}"+r'\\')
    (S/'statistical_inference_table.tex').write_text(table('Retrospective paired comparisons with SR. The confidence intervals are pointwise family-stratified bootstrap intervals; each test column separately adjusts all seven comparisons. Positive gains and rank-biserial effects favour SR.','tab:inference','lrlrrr',header,body))
    ms=['serial_rows']+DELETIONS
    header='& '+' & '.join(r'\multicolumn{3}{c}{'+LABEL[m]+'}' for m in ms)+r'\\'+'\n'+r'\cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(lr){8-10}\cmidrule(lr){11-13}'+'\n'+r'Family & Min & Mean & Time & Min & Mean & Time & Min & Mean & Time & Min & Mean & Time\\\midrule'
    body=[]
    for fam in FAMILIES:
        vals=[]
        for m in ms:
            r=next(x for x in result['family_statistics'] if x['family']==fam and x['method']==m)
            vals.extend([f"{r['min_gap']:.2f}",f"{r['mean_gap']:.2f}",f"{r['time_mean']:.3f}"])
        body.append(fam+' & '+' & '.join(vals)+r'\\')
    (S/'ablation_cross_statistics.tex').write_text(table('Ablation quality and consumed time by family. Min and Mean are objective gaps (\\%) defined as in Table~\\ref{tab:richfamily}; Time is seconds. Values compare complete policies under the common five-second cap.','tab:ablationcross','l'+'r'*12,header,body,small='scriptsize'))
    header=r'& \multicolumn{3}{c}{Exact signed-rank calculation} & \multicolumn{2}{c}{Unadjusted two-sided $p$}\\'+'\n'+r'\cmidrule(lr){2-4}\cmidrule(lr){5-6}'+'\n'+r'Comparator & Nonzero & $W^+$ & $W^-$ & Signed rank & Sign test\\\midrule'
    body=[]
    for r in result['comparisons']:
        sr=r['signed_rank']
        body.append(r['label']+f" & {sr['nonzero']} & {float(F(sr['W_plus_fraction'])):.1f} & {float(F(sr['W_minus_fraction'])):.1f} & "+ptex(sr['p_fraction'])+' & '+ptex(r['sign_p_fraction'])+r'\\')
    (S/'supplement_statistical_detail.tex').write_text(table('Finite paired-test ingredients for cohort C. Zero instance-mean differences are discarded; all remaining roots were first averaged within their instance. The main paper reports the separately Holm-adjusted values.','supp:pairedtests','lrrrrr',header,body))
    header=r'& \multicolumn{2}{c}{Leave-one-family-out gain (\%)} & \multicolumn{2}{c}{Six-family sign check}\\'+'\n'+r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}'+'\n'+r'Comparator & Min & Max & Positive/zero/negative & Holm $p$\\\midrule'
    body=[]
    for r in result['comparisons']:
        vs=[F(v) for v in r['leave_one_family_out_fraction'].values()]
        fs=[F(v) for v in r['family_gains_fraction'].values()]
        body.append(r['label']+f" & {float(min(vs)):.4f} & {float(max(vs)):.4f} & {sum(v>0 for v in fs)}/{sum(v==0 for v in fs)}/{sum(v<0 for v in fs)} & "+ptex(r['family_sign_holm_fraction'])+r'\\')
    (S/'supplement_family_sensitivity.tex').write_text(table('Sensitivity to family composition and coarser statistical units. Each omission retains 25 instances. The six-family sign test gives no adjusted rejection at 0.05.','supp:familytests','lrrcr',header,body))
    # Upgrade the complete per-method supplementary tables to grouped headers.
    f=S/'supplement_complete.tex'; text=f.read_text()
    old=r'Input & Best & Mean & Worst & Var. (kg$^2$) & $t_{min}$ & $t_{mean}$ & $t_{max}$\\\midrule'
    new=r'& \multicolumn{4}{c}{Carbon objective (kg CO$_2$eq)} & \multicolumn{3}{c}{Actual return (s)}\\'+'\n'+r'\cmidrule(lr){2-5}\cmidrule(lr){6-8}'+'\n'+r'Input & Min & Mean & Max & Var. (kg$^2$) & Min & Mean & Max\\\midrule'
    text=text.replace(old,new)
    text=text.replace(r'& \multicolumn{4}{c}{Carbon objective (kg CO$_2$eq)} & \multicolumn{3}{c}{Actual return (s)}\\',r'& \multicolumn{3}{c}{Carbon objective (kg CO$_2$eq)} & Variance & \multicolumn{3}{c}{Actual return (s)}\\')
    text=text.replace(r'\cmidrule(lr){2-5}\cmidrule(lr){6-8}',r'\cmidrule(lr){2-4}\cmidrule(lr){6-8}')
    text=text.replace(r'Input & Min & Mean & Max & Var. (kg$^2$)',r'Input & Min & Mean & Max & (kg$^2$)')
    f.write_text(text)

def draw_figures(result):
    figure_style(); comparisons=result['comparisons']; summaries=result['summaries']
    # Family profiles: symbols encode policies; connecting lines are visual guides.
    ms=['serial_rows']+CONTROLS
    fig,ax=plt.subplots();fig.subplots_adjust(left=.16,right=.98,bottom=.21,top=.76)
    for j,m in enumerate(ms):
        vals=[next(x['mean_gap'] for x in result['family_statistics'] if x['family']==f and x['method']==m) for f in FAMILIES]
        ax.plot(range(6),vals,marker=['o','s','^','D','v'][j],markersize=3.6,
                color=['#156b69','#777777','#b58238','#4c78a8','#9a5e54'][j],
                linestyle=['-','--',':','-.','--'][j],label=LABEL[m])
    ax.set_xticks(range(6),['5/1','5/3','10/1','10/3','15/1','15/3'])
    ax.set(xlabel='Family (machines / days)',ylabel='Mean observed gap (%)',ylim=(-.2,10))
    ax.grid(axis='y',alpha=.18)
    ax.legend(ncol=3,loc='lower center',bbox_to_anchor=(.47,1.02),frameon=False,
              fontsize=6.1,handlelength=1.3,columnspacing=.7)
    save(fig,'fig11_family_gap')
    # Runtime/quality cross-section. Leader lines separate near-coincident policies.
    fig,ax=plt.subplots();fig.subplots_adjust(left=.17,right=.98,bottom=.20,top=.97)
    positions={'serial_rows':(4.37,.24),'no_serial':(4.20,1.75),'no_pair':(3.62,1.25),'lexicographic':(4.83,.38),
      'fast_wait':(4.50,2.65),'local_wait_raw':(4.23,3.38),'adaptive_cp_alns':(4.22,4.78),'lg_ucb26':(4.08,4.04)}
    for j,r in enumerate(summaries):
        ax.scatter(r['time_mean'],r['mean_gap'],s=24,color=COLORS[j],edgecolor='white',linewidth=.35,zorder=3)
        ax.annotate(r['label'],(r['time_mean'],r['mean_gap']),xytext=positions[r['method']],fontsize=6.8,
          arrowprops=dict(arrowstyle='-',lw=.45,color=COLORS[j]),va='center')
    ax.axvline(5,color='.6',ls='--',lw=.7);ax.set(xlim=(3.45,5.28),ylim=(0,5.2),xlabel='Mean actual return time (s)',ylabel='Mean observed objective gap (%)');ax.grid(alpha=.18);save(fig,'fig12_quality_time')
    # Gain forest, including interventions and retained negative confidence limits.
    fig,ax=plt.subplots();fig.subplots_adjust(left=.30,right=.97,bottom=.21,top=.97)
    for i,r in enumerate(comparisons):
        mu=float(F(r['mean_gain_percent_fraction']));lo,hi=r['confidence_interval_percent']
        color='#156b69' if r['method'] in CONTROLS else '#9a572f'
        ax.plot([lo,hi],[i,i],color=color,lw=1.4);ax.scatter(mu,i,color=color,s=18,zorder=3)
    ax.axvline(0,color='.45',lw=.7,ls='--');ax.set_yticks(range(7),[r['label'] for r in comparisons]);ax.invert_yaxis()
    ax.set(xlabel='Mean gain of SR (%)',xlim=(-.5,4.8));ax.grid(axis='x',alpha=.18);save(fig,'fig13_gain_intervals')
    # All wins/ties/losses; ties are zero differences in exact rational means.
    fig,ax=plt.subplots();fig.subplots_adjust(left=.30,right=.98,bottom=.21,top=.92)
    for i,r in enumerate(comparisons):
        left=0
        for key,color in [('wins','#267e79'),('ties','#b7b7b7'),('losses','#b95b51')]:
            width=r[key];ax.barh(i,width,left=left,color=color,height=.65)
            if width:ax.text(left+width/2,i,str(width),ha='center',va='center',fontsize=6.4,color='white' if key!='ties' else 'black')
            left+=width
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=c,label=l) for c,l in [('#267e79','Win'),('#b7b7b7','Tie'),('#b95b51','Loss')]],ncol=3,loc='lower center',bbox_to_anchor=(.42,1.0),frameon=False,fontsize=6.4,handlelength=1,columnspacing=.8)
    ax.set_yticks(range(7),[r['label'] for r in comparisons]);ax.invert_yaxis();ax.set(xlim=(0,30),xlabel='Instances (three-root means)');ax.set_xticks([0,10,20,30]);save(fig,'fig14_instance_wtl')
    # Grouped signed bars retain direction and permit grayscale comparison.
    ds=[r for r in comparisons if r['method'] in DELETIONS]
    fig,ax=plt.subplots();fig.subplots_adjust(left=.21,right=.98,bottom=.21,top=.84)
    for j,r in enumerate(ds):
        vals=[float(F(r['family_gains_fraction'][f])) for f in FAMILIES]
        ax.barh(np.arange(6)+(j-1)*.23,vals,height=.21,
                color=['#667f8e','#b7b7b7','#e1e1e1'][j],edgecolor='#414141',
                linewidth=.35,hatch=['','///','...'][j],
                label=['No serial','No pair','Lexicog.'][j])
    ax.axvline(0,color='.25',lw=.65);ax.set_yticks(range(6),FAMILIES);ax.invert_yaxis()
    ax.set(xlabel='Mean gain of SR (%)',xlim=(-1.02,1.23));ax.grid(axis='x',alpha=.16)
    ax.set_axisbelow(True)
    ax.legend(ncol=3,loc='lower center',bbox_to_anchor=(.43,1.01),frameon=False,
              fontsize=6.1,handlelength=1.1,columnspacing=.7)
    save(fig,'fig15_ablation_families')
    # Leave-one-family-out sensitivity, not a confidence interval.
    fig,ax=plt.subplots();fig.subplots_adjust(left=.30,right=.98,bottom=.22,top=.97)
    for i,r in enumerate(ds):
        vals=[float(F(r['leave_one_family_out_fraction'][f])) for f in FAMILIES]
        ax.plot([min(vals),max(vals)],[i,i],color='#9a572f',lw=1)
        ax.scatter(vals,[i]*6,color='#a6a6a6',s=19,marker='|',linewidth=1,zorder=3)
        ax.scatter(float(F(r['mean_gain_percent_fraction'])),i,color='#156b69',s=25,zorder=4)
    ax.axvline(0,color='.5',lw=.7,ls='--');ax.set_yticks(range(3),[r['label'] for r in ds]);ax.invert_yaxis()
    ax.set(xlabel='Mean gain of SR (%)',ylim=(2.6,-.6));ax.grid(axis='x',alpha=.18)
    ax.text(.03,.98,'Dot: all families\nTicks: one family omitted',transform=ax.transAxes,ha='left',va='top',fontsize=6.5)
    save(fig,'fig16_leave_family_out')

if __name__=='__main__':main()
